import Foundation

// ضع هذا أعلى الملف أو أسفله
enum StreamEvent {
    case token(String)
    case done
    case error(String)
}

extension APIManager {
    /// نقطة دخول للبث الحقيقي
    func sendMessageStream(
        from chat: ChatDTO,
        settings: AppSettings,
        onEvent: @escaping (StreamEvent) -> Void
    ) {
        let cleanChat = ChatDTO(
            id: chat.id,
            title: chat.title,
            messages: sanitizedMessages(chat.messages),
            createdAt: chat.createdAt,
            updatedAt: chat.updatedAt,
            order: chat.order
        )
        
        switch settings.provider {
        case .gemini:
            streamGemini(chat: cleanChat, settings: settings, onEvent: onEvent)
            
        case .openrouter:
            streamOpenAIStyle(
                url: URL(string: "https://openrouter.ai/api/v1/chat/completions")!,
                apiKey: nextKey(from: settings.openrouterApiKeys,
                                strategy: settings.apiKeyRetryStrategy,
                                bucket: "openrouter"),
                body: openAIStyleBody(for: cleanChat,
                                      model: settings.model,
                                      temperature: settings.temperature,
                                      customPrompt: settings.customPrompt,
                                      stream: true),
                extraHeaders: [
                    "HTTP-Referer": "https://chatzeus.app",
                    "X-Title": "ChatZEUS"
                ],
                onEvent: onEvent
            )
            
        case .custom:
            guard let p = resolveCustomProvider(settings: settings) else {
                onEvent(.error("❌ لم يتم ضبط مزوّد مخصّص")); return
            }
            streamOpenAIStyle(
                url: p.baseUrl.appendingPathComponent("chat/completions"),
                apiKey: nextKey(from: p.apiKeys,
                                strategy: settings.apiKeyRetryStrategy,
                                bucket: p.id),
                body: openAIStyleBody(for: cleanChat,
                                      model: settings.model,
                                      temperature: settings.temperature,
                                      customPrompt: settings.customPrompt,
                                      stream: true),
                extraHeaders: [:],
                onEvent: onEvent
            )
        }
    }
}

// MARK: - Gemini SSE
extension APIManager {
    func streamGemini(
        chat: ChatDTO,
        settings: AppSettings,
        onEvent: @escaping (StreamEvent) -> Void
    ) {
        guard let key = nextKey(from: settings.geminiApiKeys,
                                strategy: settings.apiKeyRetryStrategy,
                                bucket: "gemini")
        else { onEvent(.error("❌ لا توجد مفاتيح Gemini نشطة")); return }
        
        let body = geminiBody(for: chat,
                              model: settings.model,
                              temperature: settings.temperature,
                              customPrompt: settings.customPrompt)
        
        // endpoint البث الحقيقي
        var comps = URLComponents(string: "https://generativelanguage.googleapis.com/v1beta/models/\(settings.model):streamGenerateContent")!
        comps.queryItems = [
            URLQueryItem(name: "alt", value: "sse"),
            URLQueryItem(name: "key", value: key)
        ]
        var req = URLRequest(url: comps.url!)
        req.httpMethod = "POST"
        req.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        // iOS 15+: تدفّق أسطر SSE فعلي
        Task.detached {
            do {
                let (bytes, _) = try await URLSession.shared.bytes(for: req)
                for try await line in bytes.lines {
                    guard line.hasPrefix("data:") else { continue }
                    let payload = String(line.dropFirst(5)).trimmingCharacters(in: .whitespaces)
                    if payload == "[DONE]" { onEvent(.done); break }
                    guard let d = payload.data(using: .utf8),
                          let json = try? JSONSerialization.jsonObject(with: d) as? [String: Any]
                    else { continue }
                    
                    // استخراج التوكين المتزايد من حدث Gemini
                    if let candidates = json["candidates"] as? [[String: Any]],
                       let content = candidates.first?["content"] as? [String: Any],
                       let parts = content["parts"] as? [[String: Any]],
                       let piece = parts.first?["text"] as? String, !piece.isEmpty {
                        onEvent(.token(piece))
                    }
                    
                    // في بعض الأحيان يرسل finishReason في حدث أخير
                    if let candidates = json["candidates"] as? [[String: Any]],
                       let finish = candidates.first?["finishReason"] as? String,
                       !finish.isEmpty {
                        onEvent(.done); break
                    }
                }
            } catch {
                onEvent(.error("❌ خطأ في بث Gemini: \(error.localizedDescription)"))
            }
        }
    }
}

// MARK: - OpenRouter/Custom (OpenAI-style) SSE
extension APIManager {
    func streamOpenAIStyle(
        url: URL,
        apiKey: String?,
        body: [String: Any],
        extraHeaders: [String: String] = [:],
        onEvent: @escaping (StreamEvent) -> Void
    ) {
        guard let key = apiKey else { onEvent(.error("❌ لا توجد مفاتيح نشطة")); return }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        req.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        extraHeaders.forEach { req.setValue($0.value, forHTTPHeaderField: $0.key) }
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        Task.detached {
            do {
                let (bytes, _) = try await URLSession.shared.bytes(for: req)
                for try await line in bytes.lines {
                    guard line.hasPrefix("data:") else { continue }
                    let payload = String(line.dropFirst(5)).trimmingCharacters(in: .whitespaces)
                    if payload == "[DONE]" { onEvent(.done); break }
                    guard let d = payload.data(using: .utf8),
                          let json = try? JSONSerialization.jsonObject(with: d) as? [String: Any]
                    else { continue }
                    
                    // استخراج من شكل OpenAI: choices[].delta.content
                    if let choices = json["choices"] as? [[String: Any]],
                       let delta = choices.first?["delta"] as? [String: Any],
                       let piece = delta["content"] as? String, !piece.isEmpty {
                        onEvent(.token(piece))
                    }
                }
            } catch {
                onEvent(.error("❌ خطأ في بث OpenAI-style: \(error.localizedDescription)"))
            }
        }
    }
}

// MARK: - Helper: تكوين Body متوافق مع OpenAI-style (لـ OpenRouter/Custom)
private extension APIManager {
    func openAIStyleBody(
        for chat: ChatDTO,
        model: String,
        temperature: Double,
        customPrompt: String?,
        stream: Bool
    ) -> [String: Any] {
        var msgs: [[String: Any]] = []
        if let p = customPrompt, !p.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            msgs.append(["role": "system", "content": p])
        }
        for m in chat.messages {
            var text = m.content
            for a in m.attachments {
                if a.dataType == "text", let t = a.content {
                    text += "\n\n--- محتوى الملف: \(a.name) ---\n\(t)\n--- نهاية الملف ---"
                } else if a.dataType == "image" {
                    // ملاحظة: معظم مقدمي OpenAI-style لا يدعمون الصور هنا؛ نضع إشارة فقط
                    text += "\n\n[صورة مرفقة: \(a.name)]"
                }
            }
            msgs.append(["role": (m.role == .user ? "user" : "assistant"), "content": text])
        }
        return [
            "model": model,
            "messages": msgs,
            "temperature": temperature,
            "stream": stream,
            "max_tokens": 4096
        ]
    }
}
