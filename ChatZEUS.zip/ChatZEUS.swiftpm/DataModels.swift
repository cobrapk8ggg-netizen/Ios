
import Foundation
import SwiftUI

// MARK: - 2. النماذج ومدراء البيانات

struct Website: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
    var url: String
    var dateAdded: Date = Date()
    
    var domain: String {
        guard let url = URL(string: url), let host = url.host else { return "" }
        return host.replacingOccurrences(of: "www.", with: "")
    }
}

class WebsitesManager: ObservableObject {
    @Published var websites: [Website] = []
    private let key = "saved_websites"
    private let lastURLKey = "last_opened_url"
    
    init() { loadWebsites() }
    
    func loadWebsites() {
        if let data = UserDefaults.standard.data(forKey: key),
           let decoded = try? JSONDecoder().decode([Website].self, from: data) {
            websites = decoded
        }
    }
    
    func saveWebsites() {
        if let encoded = try? JSONEncoder().encode(websites) {
            UserDefaults.standard.set(encoded, forKey: key)
        }
    }
    
    func addWebsite(_ website: Website) {
        websites.insert(website, at: 0)
        saveWebsites()
    }
    
    func deleteWebsite(_ website: Website) {
        websites.removeAll { $0.id == website.id }
        saveWebsites()
    }
    
    func saveLastURL(_ urlString: String) {
        UserDefaults.standard.set(urlString, forKey: lastURLKey)
    }
    
    func getAllowedDomains() -> [String] {
        return websites.map { $0.domain }
    }
}

struct HistoryItem: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    let title: String
    let url: String
    let date: Date
}

class HistoryManager: ObservableObject {
    @Published var history: [HistoryItem] = []
    private let historyKey = "browser_history_data"
    
    init() { loadHistory() }
    
    func loadHistory() {
        if let data = UserDefaults.standard.data(forKey: historyKey),
           let decoded = try? JSONDecoder().decode([HistoryItem].self, from: data) {
            history = decoded.sorted(by: { $0.date > $1.date })
        }
    }
    
    func saveHistory() {
        if let encoded = try? JSONEncoder().encode(history) {
            UserDefaults.standard.set(encoded, forKey: historyKey)
        }
    }
    
    func addToHistory(title: String, url: String) {
        if let first = history.first, first.url == url, Date().timeIntervalSince(first.date) < 60 {
            return
        }
        if url.isEmpty || url == "about:blank" || url == "zeus://home" || title.isEmpty { return }
        
        let newItem = HistoryItem(title: title, url: url, date: Date())
        history.insert(newItem, at: 0)
        
        if history.count > 1000 {
            history = Array(history.prefix(1000))
        }
        saveHistory()
    }
    
    func deleteItem(_ item: HistoryItem) {
        history.removeAll { $0.id == item.id }
        saveHistory()
    }
    
    func clearAll() {
        history.removeAll()
        saveHistory()
    }
}

// MARK: - NEW: مدير السكربتات ونماذج الكونسول

struct UserScript: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
    var domain: String 
    var code: String
    var isActive: Bool
    var dateCreated: Date = Date()
}

struct ConsoleLog: Identifiable, Equatable {
    var id: UUID = UUID()
    let type: String 
    let message: String
    let timestamp: Date = Date()
}

class ScriptManager: ObservableObject {
    @Published var scripts: [UserScript] = []
    private let scriptsKey = "user_custom_scripts"
    
    init() { loadScripts() }
    
    func loadScripts() {
        if let data = UserDefaults.standard.data(forKey: scriptsKey),
           let decoded = try? JSONDecoder().decode([UserScript].self, from: data) {
            scripts = decoded
        }
    }
    
    func saveScripts() {
        if let encoded = try? JSONEncoder().encode(scripts) {
            UserDefaults.standard.set(encoded, forKey: scriptsKey)
        }
    }
    
    func addOrUpdateScript(_ script: UserScript) {
        if let index = scripts.firstIndex(where: { $0.id == script.id }) {
            scripts[index] = script
        } else {
            scripts.append(script)
        }
        saveScripts()
    }
    
    func deleteScript(_ script: UserScript) {
        scripts.removeAll { $0.id == script.id }
        saveScripts()
    }
    
    func toggleScript(_ script: UserScript) {
        if let index = scripts.firstIndex(where: { $0.id == script.id }) {
            scripts[index].isActive.toggle()
            saveScripts()
        }
    }
    
    func generateInjectionCode() -> String {
        guard let jsonData = try? JSONEncoder().encode(scripts.filter { $0.isActive }),
              let jsonString = String(data: jsonData, encoding: .utf8) else { return "" }
        
        return """
        (function() {
            var scripts = \(jsonString);
            var currentHref = window.location.href;
            
            function runUserScripts() {
                scripts.forEach(function(script) {
                    if (script.domain === '*' || currentHref.includes(script.domain)) {
                        try {
                             setTimeout(function() {
                                 try {
                                     eval(script.code);
                                     console.log('✅ Executed Script: ' + script.name);
                                 } catch(e) {
                                     console.error('❌ Script Runtime Error (' + script.name + '): ' + e.message);
                                 }
                             }, 100);
                        } catch(e) {
                            console.error('❌ Script Load Error (' + script.name + '): ' + e.message);
                        }
                    }
                });
            }
        
            if (document.readyState === 'complete' || document.readyState === 'interactive') {
                runUserScripts();
            } else {
                document.addEventListener('DOMContentLoaded', runUserScripts);
            }
        })();
        """
    }
}

// MARK: - Search Engine Helpers
enum SearchEngine: String, CaseIterable, Codable {
    case google = "Google"
    case duckDuckGo = "DuckDuckGo"
    case bing = "Bing"
    
    var urlTemplate: String {
        switch self {
        case .google: return "https://www.google.com/search?q="
        case .duckDuckGo: return "https://duckduckgo.com/?q="
        case .bing: return "https://www.bing.com/search?q="
        }
    }
    
    var color: String {
        switch self {
        case .google: return "4285F4"
        case .duckDuckGo: return "DE5833"
        case .bing: return "008373"
        }
    }
    
    var icon: String {
        switch self {
        case .google: return "globe"
        case .duckDuckGo: return "target" // Using target as approximation
        case .bing: return "magnifyingglass.circle"
        }
    }
}
