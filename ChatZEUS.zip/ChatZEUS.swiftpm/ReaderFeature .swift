import SwiftUI

// MARK: - واجهة القارئ (Reader Mode UI)
struct ReaderView: View {
    let title: String
    let content: [String]
    @Binding var isVisible: Bool
    
    // حفظ الإعدادات في ذاكرة الجهاز
    @AppStorage("reader_fontSize") private var fontSize: Double = 20
    @AppStorage("reader_isDarkMode") private var isDarkMode: Bool = true
    @AppStorage("reader_textOpacity") private var textOpacity: Double = 1.0 // التحكم بالشفافية
    @AppStorage("reader_blacklist") private var blacklistData: String = "" // الكلمات المحظورة (مخزنة كنص مفصول بفاصلة)
    
    @State private var showSettings: Bool = false
    @State private var showCopyAlert: Bool = false
    @State private var newForbiddenWord: String = ""
    
    // متغيرات التمرير
    @State private var isHeaderVisible: Bool = true
    @State private var lastOffset: CGFloat = 0
    @State private var headerOffset: CGFloat = 0 
    
    // تحويل نص القائمة المحظورة إلى مصفوفة
    var blockedWords: [String] {
        blacklistData.components(separatedBy: ",").filter { !$0.isEmpty }
    }
    
    var body: some View {
        ZStack(alignment: .top) {
            Color(isDarkMode ? .black : .white)
                .edgesIgnoringSafeArea(.all)
            
            ScrollView {
                ZStack {
                    GeometryReader { proxy in
                        let offset = proxy.frame(in: .named("scroll")).minY
                        Color.clear.preference(key: ScrollOffsetPreferenceKey.self, value: offset)
                    }
                    
                    VStack(alignment: .trailing, spacing: 25) { 
                        Spacer().frame(height: 75)
                        
                        Text(title)
                            .font(.system(size: CGFloat(fontSize) + 6, weight: .bold, design: .serif))
                            .foregroundColor(isDarkMode ? .white : .black)
                            .multilineTextAlignment(.center)
                            .frame(maxWidth: .infinity)
                            .padding(.bottom, 10)
                            .textSelection(.enabled)
                        
                        Divider()
                            .background(isDarkMode ? Color.gray.opacity(0.3) : Color.black.opacity(0.1))
                        
                        // عرض المحتوى مع فلترة الكلمات المحظورة وتطبيق الشفافية
                        ForEach(content, id: \.self) { paragraph in
                            if shouldShowParagraph(paragraph) {
                                Text(paragraph)
                                    .font(.system(size: CGFloat(fontSize), weight: .regular, design: .serif))
                                    .foregroundColor(isDarkMode ? Color(white: 0.9) : Color.black)
                                    .opacity(textOpacity) // تطبيق الشفافية هنا
                                    .lineSpacing(10)
                                    .multilineTextAlignment(.trailing)
                                    .frame(maxWidth: .infinity, alignment: .trailing)
                                    .textSelection(.enabled)
                            }
                        }
                    }
                    .padding(25)
                    .padding(.bottom, 60)
                }
            }
            .coordinateSpace(name: "scroll")
            .onPreferenceChange(ScrollOffsetPreferenceKey.self) { value in
                let delta = value - lastOffset
                if value > -10 {
                    withAnimation { headerOffset = 0; isHeaderVisible = true }
                } else if delta < -10 {
                    withAnimation { headerOffset = -400; isHeaderVisible = false; showSettings = false }
                } else if delta > 15 {
                    withAnimation { headerOffset = 0; isHeaderVisible = true }
                }
                lastOffset = value
            }
            
            // الشريط العلوي المطور
            VStack(spacing: 0) {
                VStack(spacing: 0) {
                    HStack(spacing: 15) {
                        Button(action: { withAnimation { showSettings.toggle() } }) {
                            Image(systemName: "slider.horizontal.3")
                                .font(.system(size: 18))
                                .foregroundColor(isDarkMode ? .white : .black)
                                .padding(10)
                        }
                        
                        Button(action: { copyAllContent() }) {
                            Image(systemName: "doc.on.doc")
                                .font(.system(size: 16))
                                .foregroundColor(isDarkMode ? .white : .black)
                                .padding(10)
                        }
                        
                        Spacer()
                        Text("وضع القراءة")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.gray)
                        Spacer()
                        
                        Button(action: { isVisible = false }) {
                            Image(systemName: "xmark")
                                .font(.system(size: 16, weight: .bold))
                                .foregroundColor(isDarkMode ? .white : .black)
                                .padding(10)
                        }
                    }
                    .padding(.horizontal).padding(.top, 5).padding(.bottom, 10)
                    .background(isDarkMode ? Color.black : Color(white: 0.95))
                    
                    if showSettings {
                        VStack(spacing: 20) {
                            // التحكم بالحجم
                            HStack {
                                Text("حجم الخط").font(.caption).bold()
                                Slider(value: $fontSize, in: 14...40, step: 1)
                            }
                            
                            // التحكم بالشفافية (التعتيم)
                            HStack {
                                Text("شفافية النص").font(.caption).bold()
                                Slider(value: $textOpacity, in: 0.1...1.0)
                            }
                            
                            // إدارة الكلمات المحظورة
                            VStack(alignment: .trailing, spacing: 10) {
                                Text("إضافة للقائمة السوداء").font(.caption).bold()
                                HStack {
                                    Button(action: addWordToBlacklist) {
                                        Image(systemName: "plus.circle.fill").foregroundColor(.blue).font(.title3)
                                    }
                                    TextField("كلمة أو جملة لحظرها...", text: $newForbiddenWord)
                                        .textFieldStyle(RoundedBorderTextFieldStyle())
                                        .multilineTextAlignment(.trailing)
                                        .foregroundColor(.black)
                                }
                                
                                // عرض الكلمات المحظورة حالياً لحذفها
                                ScrollView(.horizontal, showsIndicators: false) {
                                    HStack {
                                        ForEach(blockedWords, id: \.self) { word in
                                            HStack {
                                                Text(word).font(.caption2)
                                                Button(action: { removeWord(word) }) {
                                                    Image(systemName: "xmark.circle.fill").font(.caption2)
                                                }
                                            }
                                            .padding(6)
                                            .background(Color.red.opacity(0.2))
                                            .cornerRadius(8)
                                        }
                                    }
                                }
                            }
                            
                            // الوضع الليلي
                            HStack(spacing: 50) {
                                Button(action: { isDarkMode = false }) {
                                    Circle().fill(Color.white).frame(width: 30, height: 30)
                                        .overlay(Circle().stroke(Color.blue, lineWidth: !isDarkMode ? 2 : 0))
                                }
                                Button(action: { isDarkMode = true }) {
                                    Circle().fill(Color.black).frame(width: 30, height: 30)
                                        .overlay(Circle().stroke(Color.blue, lineWidth: isDarkMode ? 2 : 0))
                                }
                            }
                        }
                        .padding(20)
                        .background(isDarkMode ? Color(white: 0.1) : Color.white)
                        .transition(.move(edge: .top).combined(with: .opacity))
                    }
                }
                .background(isDarkMode ? Color.black : Color(white: 0.95))
                .offset(y: headerOffset)
                Spacer()
            }
            .edgesIgnoringSafeArea(.top)
        }
        .environment(\.layoutDirection, .leftToRight)
    }
    
    // منطق فحص الفقرة هل تحتوي كلمة محظورة
    private func shouldShowParagraph(_ text: String) -> Bool {
        if text.trimmingCharacters(in: .whitespaces).isEmpty { return false }
        for word in blockedWords {
            if text.localizedCaseInsensitiveContains(word) { return false }
        }
        return true
    }
    
    private func addWordToBlacklist() {
        let trimmed = newForbiddenWord.trimmingCharacters(in: .whitespaces)
        if !trimmed.isEmpty && !blockedWords.contains(trimmed) {
            if blacklistData.isEmpty {
                blacklistData = trimmed
            } else {
                blacklistData += "," + trimmed
            }
            newForbiddenWord = ""
        }
    }
    
    private func removeWord(_ word: String) {
        let updatedList = blockedWords.filter { $0 != word }
        blacklistData = updatedList.joined(separator: ",")
    }
    
    private func copyAllContent() {
        let visibleContent = content.filter { shouldShowParagraph($0) }
        let fullText = title + "\n\n" + visibleContent.joined(separator: "\n\n")
        UIPasteboard.general.string = fullText
        withAnimation { showCopyAlert = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { withAnimation { showCopyAlert = false } }
    }
}

// MARK: - مفتاح التمرير
struct ScrollOffsetPreferenceKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}

// MARK: - محرك استخراج نصوص القارئ المعدل (بدون حد أدنى للطول للكلمات الهامة)
struct ReaderEngine {
    static func getReaderExtractionScript() -> String {
        return """
        (function() {
            try {
                function isHidden(el) {
                    const style = window.getComputedStyle(el);
                    return (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0' || el.offsetHeight === 0);
                }
                
                function extractContent() {
                    const selectors = ['article', 'main', '.post-content', '.entry-content', '#article-body', '.chapter-content'];
                    let mainElement = null;
                    for (let s of selectors) {
                        let el = document.querySelector(s);
                        if (el && el.innerText.length > 100) { mainElement = el; break; }
                    }
                    if (!mainElement) mainElement = document.body;
                    
                    let extractedParagraphs = [];
                    let seenTexts = new Set(); 
                    // استهداف الفقرات والعناوين وحتى العناصر النصية القصيرة
                    const tags = mainElement.querySelectorAll('p, h2, h3, div');
                    
                    tags.forEach(el => {
                        if (isHidden(el)) return;
                        
                        // تجاهل الحاويات الكبيرة التي تحتوي على عناصر فرعية تم معالجتها بالفعل
                        if (el.tagName === 'DIV' && el.querySelector('p')) return;
                        
                        let text = el.innerText.replace(/\\s+/g, ' ').trim();
                        
                        // تم تقليل الحد الأدنى للطول من 20 إلى 2 ليلتقط كلمات مثل "ظلام..." 
                        // مع استبعاد النصوص المتكررة جداً
                        if (text.length >= 2 && !seenTexts.has(text)) {
                            extractedParagraphs.push(text);
                            seenTexts.add(text);
                        }
                    });
                    return extractedParagraphs;
                }
                
                const title = (document.querySelector('h1') ? document.querySelector('h1').innerText : document.title).trim();
                const content = extractContent();
                window.webkit.messageHandlers.readerObserver.postMessage({ title: title, content: content });
            } catch (e) { console.error(e); }
        })();
        """
    }
}
