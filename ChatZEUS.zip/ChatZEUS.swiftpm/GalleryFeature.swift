import SwiftUI
import Kingfisher
import UIKit

// MARK: - مفاتيح التخزين (Storage Keys)
enum StorageKeys {
    static let imageScale = "gallery_image_scale"
    static let scrollDistance = "gallery_scroll_distance"
}

// MARK: - واجهة الإعدادات (Settings View)
struct GallerySettingsView: View {
    @AppStorage(StorageKeys.imageScale) var imageScale: Double = 1.0
    @AppStorage(StorageKeys.scrollDistance) var scrollDistance: Double = 300.0
    
    @Binding var isPresented: Bool
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("إعدادات وضع القراءة")) {
                    VStack(alignment: .leading) {
                        Text("عرض الصورة: \(Int(imageScale * 100))%")
                        Slider(value: $imageScale, in: 0.2...1.0, step: 0.05) {
                            Text("Image Width")
                        } minimumValueLabel: {
                            Image(systemName: "photo")
                        } maximumValueLabel: {
                            Image(systemName: "photo.fill")
                        }
                    }
                    .padding(.vertical, 5)
                    
                    VStack(alignment: .leading) {
                        Text("مسافة التمرير عند النقر: \(Int(scrollDistance)) نقطة")
                        Slider(value: $scrollDistance, in: 100...1000, step: 50) {
                            Text("Scroll Distance")
                        } minimumValueLabel: {
                            Image(systemName: "arrow.up.arrow.down")
                        } maximumValueLabel: {
                            Image(systemName: "arrow.up.arrow.down.circle.fill")
                        }
                    }
                    .padding(.vertical, 5)
                }
                
                Section(footer: Text("يتم حفظ الإعدادات تلقائياً. عند فتح صورة، سيتم إخفاء شريط الحالة لتوفير تجربة قراءة كاملة.")) {
                    EmptyView()
                }
            }
            .navigationBarTitle("إعدادات العرض", displayMode: .inline)
            .navigationBarItems(trailing: Button("إغلاق") {
                isPresented = false
            })
        }
    }
}

// MARK: - أداة الوصول للتحكم بالتمرير (Scroll Helper)
struct ScrollViewFinder: UIViewRepresentable {
    @Binding var uiScrollView: UIScrollView?
    
    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }
    
    func updateUIView(_ uiView: UIView, context: Context) {
        DispatchQueue.main.async {
            if let scrollView = uiView.superview?.superview?.superview as? UIScrollView {
                self.uiScrollView = scrollView
            } else {
                self.findScrollView(in: uiView)
            }
        }
    }
    
    private func findScrollView(in view: UIView) {
        var current: UIView? = view
        while let view = current {
            if let scrollView = view as? UIScrollView {
                self.uiScrollView = scrollView
                return
            }
            current = view.superview
        }
    }
}

// MARK: - واجهة معرض الصور (Gallery UI)
struct GalleryView: View {
    let images: [String]
    @Binding var isVisible: Bool
    
    @AppStorage(StorageKeys.imageScale) var imageScale: Double = 1.0
    @AppStorage(StorageKeys.scrollDistance) var scrollDistance: Double = 300.0
    
    @State private var showSettings = false
    @State private var uiScrollView: UIScrollView?
    @State private var selectedIndex: Int? = nil
    
    // متغير للتحكم في حالة شريط النظام
    @State private var isStatusBarHidden = false
    
    let columns = [
        GridItem(.flexible(), spacing: 2),
        GridItem(.flexible(), spacing: 2),
        GridItem(.flexible(), spacing: 2)
    ]
    
    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 0) {
                // Header - تم تعديل الأماكن هنا
                HStack {
                    // زر الإعدادات أصبح على اليسار
                    Button(action: { showSettings = true }) {
                        Image(systemName: "gearshape.fill")
                            .foregroundColor(.white)
                            .font(.title2)
                    }
                    
                    Spacer()
                    
                    Text("\(images.count) صور")
                        .foregroundColor(.white)
                        .font(.headline)
                    
                    Spacer()
                    
                    // زر الإغلاق أصبح على اليمين
                    Button(action: { isVisible = false }) {
                        Image(systemName: "xmark")
                            .foregroundColor(.white)
                            .font(.title2)
                    }
                }
                .padding()
                .background(Color(white: 0.05))
                
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 2) {
                        ForEach(0..<images.count, id: \.self) { index in
                            Button(action: { 
                                selectedIndex = index
                                withAnimation { isStatusBarHidden = true }
                            }) {
                                KFImage(URL(string: images[index]))
                                    .placeholder { Color.gray.opacity(0.3) }
                                    .resizable()
                                    .scaledToFill()
                                    .frame(height: UIScreen.main.bounds.width / 3)
                                    .clipped()
                            }
                        }
                    }
                    .padding(.horizontal, 2)
                }
            }
            
            // وضع القراءة (Webtoon Reader Mode)
            if let index = selectedIndex {
                ZStack {
                    Color.black.edgesIgnoringSafeArea(.all)
                    
                    GeometryReader { geometry in
                        ScrollViewReader { proxy in
                            ScrollView {
                                LazyVStack(spacing: 0) {
                                    ForEach(0..<images.count, id: \.self) { i in
                                        KFImage(URL(string: images[i]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: geometry.size.width * CGFloat(imageScale))
                                            .frame(maxWidth: .infinity)
                                            .id(i)
                                    }
                                }
                                .background(ScrollViewFinder(uiScrollView: $uiScrollView))
                            }
                            .simultaneousGesture(
                                SpatialTapGesture()
                                    .onEnded { event in
                                        let yLocation = event.location.y
                                        let screenHeight = geometry.size.height
                                        
                                        if yLocation < screenHeight / 2 {
                                            scroll(direction: -1)
                                        } else {
                                            scroll(direction: 1)
                                        }
                                    }
                            )
                            .onAppear {
                                proxy.scrollTo(index, anchor: .top)
                            }
                        }
                    }
                    
                    VStack {
                        HStack {
                            Spacer()
                            Button(action: { 
                                selectedIndex = nil
                                withAnimation { isStatusBarHidden = false }
                            }) {
                                Image(systemName: "xmark.circle.fill")
                                    .font(.system(size: 35))
                                    .foregroundColor(.white.opacity(0.8))
                                    .padding()
                            }
                        }
                        Spacer()
                    }
                }
                .transition(.move(edge: .bottom))
                .zIndex(10)
            }
        }
        // تطبيق إخفاء شريط الحالة بناءً على المتغير
        .statusBar(hidden: isStatusBarHidden)
        .sheet(isPresented: $showSettings) {
            GallerySettingsView(isPresented: $showSettings)
        }
    }
    
    private func scroll(direction: CGFloat) {
        guard let scrollView = uiScrollView else { return }
        
        let currentOffset = scrollView.contentOffset.y
        let maxOffset = scrollView.contentSize.height - scrollView.bounds.height
        let minOffset: CGFloat = 0
        
        let newOffset = currentOffset + (direction * CGFloat(scrollDistance))
        let clampedOffset = min(max(newOffset, minOffset), maxOffset)
        
        scrollView.setContentOffset(CGPoint(x: 0, y: clampedOffset), animated: true)
    }
}

// MARK: - محرك استخراج الصور
struct GalleryEngine {
    static func getImageExtractionScript() -> String {
        return """
        (function() {
            try {
                let images = [];
                document.querySelectorAll('img').forEach(img => {
                    if (img.src && img.naturalWidth > 150 && img.naturalHeight > 150) {
                        images.push(img.src);
                    }
                });
                document.querySelectorAll('*').forEach(el => {
                    const bg = window.getComputedStyle(el).backgroundImage;
                    if (bg && bg !== 'none' && bg.startsWith('url(')) {
                        let url = bg.slice(4, -1).replace(/["']/g, "");
                        images.push(url);
                    }
                });
                const uniqueImages = [...new Set(images)];
                if (uniqueImages.length > 0) {
                    window.webkit.messageHandlers.galleryObserver.postMessage({
                        images: uniqueImages
                    });
                } else {
                    alert('لا توجد صور كبيرة في هذه الصفحة');
                }
            } catch (e) {
                console.error(e);
            }
        })();
        """
    }
}
