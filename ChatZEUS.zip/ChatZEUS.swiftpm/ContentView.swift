import SwiftUI
import WebKit

struct WebView: UIViewRepresentable {
    let url: URL
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    func makeUIView(context: Context) -> WKWebView {
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        
        let config = WKWebViewConfiguration()
        config.defaultWebpagePreferences = prefs
        config.allowsInlineMediaPlayback = true
        
        let webView = WKWebView(frame: .zero, configuration: config)
        
        // استخدام User Agent الخاص بمتصفح آيفون الحقيقي لتجاوز الحماية
        webView.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1"
        
        webView.allowsBackForwardNavigationGestures = true
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        
        return webView
    }
    
    func updateUIView(_ webView: WKWebView, context: Context) {
        if webView.url == nil {
            let request = URLRequest(url: url)
            webView.load(request)
        }
    }
    
    class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        var parent: WebView
        
        init(_ parent: WebView) {
            self.parent = parent
        }
        
        // 1. إدارة النوافذ المنبثقة
        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if let url = navigationAction.request.url {
                let urlString = url.absoluteString
                
                // السماح بالروابط الداخلية (about) والموقع الأصلي وكلاود فلير
                if url.scheme == "about" || urlString.contains("olympustaff.com") || urlString.contains("cloudflare") || urlString.contains("challenge") {
                    webView.load(navigationAction.request)
                }
            }
            return nil
        }
        
        // 2. فلترة الروابط واتخاذ القرار
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else {
                decisionHandler(.cancel)
                return
            }
            
            // --- التعديل هنا: السماح بجميع روابط about مثل srcdoc و blank ---
            if url.scheme == "about" {
                decisionHandler(.allow)
                return
            }
            // -------------------------------------------------------------
            
            if let host = url.host {
                // السماح للموقع + نطاقات الحماية
                if host.contains("olympustaff.com") || host.contains("cloudflare") || host.contains("challenge") {
                    decisionHandler(.allow)
                    return
                }
            }
            
            print("تم حظر الرابط الخارجي: \(url.absoluteString)")
            decisionHandler(.cancel)
        }
    }
}

struct ContentView: View {
    var body: some View {
        WebView(url: URL(string: "https://olympustaff.com")!)
            .edgesIgnoringSafeArea(.all)
    }
}
