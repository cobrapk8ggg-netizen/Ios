import SwiftUI
@preconcurrency import WebKit
import Kingfisher // 👈 مكتبة الصور

// MARK: - 1. المحرك الذكي لحظر الإعلانات (The Smart Engine)
// هذا الجزء يعمل كـ "مكتبة" داخلية متكاملة

struct SmartRules {
    // قائمة النطاقات المحظورة (تمثل عينة من EasyList)
    static let domains: Set<String> = [
        "doubleclick.net", "googleadservices.com", "googlesyndication.com",
        "google-analytics.com", "googletagmanager.com", "facebook.net",
        "scorecardresearch.com", "adnxs.com", "advertising.com",
        "adsystem.com", "admob.com", "inmobi.com", "mopub.com",
        "applovin.com", "unity3d.com", "chartbeat.com", "taboola.com",
        "outbrain.com", "popads.net", "popcash.net", "propellerads.com",
        "adcash.com", "exoclick.com", "clickadu.com", "hilltopads.net",
        "juicyads.com", "trafficjunky.com", "mgid.com", "revcontent.com",
        "criteo.com", "serving-sys.com", "spotxchange.com", "adsrvr.org",
        "pubmatic.com", "rubiconproject.com", "openx.net", "bidswitch.net",
        "casalemedia.com", "lijit.com", "sovrn.com", "ads.twitter.com",
        "amazon-adsystem.com", "smartadserver.com", "truste.com"
    ]
    
    // عناصر CSS المزعجة (لافتات الكوكيز، الإعلانات العائمة)
    static let cssSelectors: [String] = [
        // الإعلانات العامة
        ".ad", ".ads", ".advertisement", ".banner", "#ad", "#ads",
        "[id^='google_ads']", "[class*='adsbygoogle']",
        // النوافذ المنبثقة المزعجة
        "[class*='popup']", "[id*='popup']", ".modal-overlay",
        // لافتات الكوكيز والخصوصية (Annoyances)
        "#onetrust-banner-sdk", ".cookie-banner", "#cookie-notice",
        ".fc-ab-root", // Anti-Adblock messages
        // أدوات تعقب
        "iframe[src*='doubleclick']", "iframe[src*='ads']"
    ]
}

class AdBlockManager {
    static let shared = AdBlockManager()
    
    // تجميع القواعد لمتصفح WebKit (الحظر من الشبكة)
    func createContentBlockerRules() -> String {
        var rules: [[String: Any]] = []
        
        // 1. حظر الموارد (Script, Image, Popup)
        for domain in SmartRules.domains {
            rules.append([
                "trigger": [
                    "url-filter": ".*\(domain).*",
                    "resource-type": ["script", "image", "raw", "document", "popup", "style-sheet"]
                ],
                "action": [
                    "type": "block"
                ]
            ])
        }
        
        // 2. إخفاء العناصر (Cosmetic Filtering)
        // هذا يجعل WebKit يخفي العنصر تماماً حتى لو تم تحميله
        for selector in SmartRules.cssSelectors {
            rules.append([
                "trigger": [
                    "url-filter": ".*"
                ],
                "action": [
                    "type": "css-display-none",
                    "selector": selector
                ]
            ])
        }
        
        // 3. قاعدة خاصة لمنع ملفات الفيديو الإعلانية
        rules.append([
            "trigger": [
                "url-filter": ".*(ad|ads|preroll|midroll).*mp4",
                "resource-type": ["media"]
            ],
            "action": [ "type": "block" ]
        ])
        
        if let jsonData = try? JSONSerialization.data(withJSONObject: rules, options: []),
           let jsonString = String(data: jsonData, encoding: .utf8) {
            return jsonString
        }
        return "[]"
    }
    
    // السكريبت الذكي (Smart Injection)
    // يقوم بوظيفة المكتبات المتقدمة: خداع المواقع وتنظيف الصفحة
    func getSmartInjectionScript() -> String {
        return """
        (function() {
            console.log('🛡️ Smart AdBlock Engine v3.0');
            
            // 1. تدمير النوافذ المنبثقة (Pop-up Killer)
            window.open = function() { console.log('🚫 Pop-up Killed'); return null; };
            
            // 2. خداع كاشفات مانع الإعلانات (Anti-Adblock Killer)
            // نوهم الموقع أن الإعلانات تم تحميلها
            Object.defineProperty(window, 'google_ad_status', { get: function() { return 1; } });
            window.canRunAds = true;
            window.isAdBlockActive = false;
            
            // 3. تنظيف دوري للصفحة (DOM Cleaner)
            function cleanPage() {
                // إزالة الإطارات الفارغة أو الإعلانية
                document.querySelectorAll('iframe').forEach(el => {
                    if (el.src.includes('ads') || el.src.includes('google') || el.offsetWidth < 10) {
                        el.remove();
                    }
                });
                
                // إزالة الطبقات التي تغطي الشاشة (Overlays)
                document.querySelectorAll('div[style*="position: fixed"]').forEach(el => {
                   if (el.style.zIndex > 900 && el.innerHTML.length < 300) {
                       el.remove(); // غالباً إعلان أو طلب تسجيل دخول إجباري
                   }
                });
                
                // إزالة لافتات الفيديو العائمة
                document.querySelectorAll('[class*="float"]').forEach(el => el.remove());
            }
            
            // مراقب التغييرات (MutationObserver) - يراقب أي عنصر جديد يضاف للصفحة
            var observer = new MutationObserver(function(mutations) {
                cleanPage();
            });
            
            observer.observe(document, { childList: true, subtree: true });
            
            // التشغيل الأولي
            document.addEventListener('DOMContentLoaded', cleanPage);
            setInterval(cleanPage, 3000); // تنظيف احتياطي كل 3 ثواني
            
        })();
        """
    }
}

// MARK: - 2. النماذج ومدراء البيانات

struct Website: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
    var url: String
    var dateAdded: Date = Date()
    
    var domain: String {
        guard let url = URL(string: url),
              let host = url.host else { return "" }
        return host.replacingOccurrences(of: "www.", with: "")
    }
}

class WebsitesManager: ObservableObject {
    @Published var websites: [Website] = []
    private let key = "saved_websites"
    private let lastURLKey = "last_opened_url"
    
    init() { loadWebsites() }
    
    func loadWebsites() {
        if let data = UserDefaults.standard.data(forKey: key),
           let decoded = try? JSONDecoder().decode([Website].self, from: data) {
            websites = decoded
        }
    }
    
    func saveWebsites() {
        if let encoded = try? JSONEncoder().encode(websites) {
            UserDefaults.standard.set(encoded, forKey: key)
        }
    }
    
    func addWebsite(_ website: Website) {
        websites.insert(website, at: 0)
        saveWebsites()
    }
    
    func deleteWebsite(_ website: Website) {
        websites.removeAll { $0.id == website.id }
        saveWebsites()
    }
    
    func saveLastURL(_ urlString: String) {
        UserDefaults.standard.set(urlString, forKey: lastURLKey)
    }
    
    func getLastURL() -> String? {
        return UserDefaults.standard.string(forKey: lastURLKey)
    }
    
    func getAllowedDomains() -> [String] {
        return websites.map { $0.domain }
    }
}

class WebViewModel: ObservableObject {
    @Published var isLoading: Bool = false
    @Published var canGoBack: Bool = false
    @Published var canGoForward: Bool = false
    @Published var currentURL: String = ""
    @Published var adsBlocked: Int = 0
    
    var webView: WKWebView?
    var websitesManager: WebsitesManager?
    
    func goBack() { webView?.goBack() }
    func goForward() { webView?.goForward() }
    func reload() { webView?.reload() }
    func loadUrl(url: URL) {
        webView?.load(URLRequest(url: url))
        websitesManager?.saveLastURL(url.absoluteString)
    }
}

// MARK: - 3. متصفح الويب (WebView)

struct WebView: UIViewRepresentable {
    let url: URL
    @ObservedObject var viewModel: WebViewModel
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self, viewModel: viewModel)
    }
    
    func makeUIView(context: Context) -> WKWebView {
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        
        let config = WKWebViewConfiguration()
        config.defaultWebpagePreferences = prefs
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = [] // السماح بتشغيل الفيديو تلقائياً (مثل يوتيوب)
        
        // 1. تجميع قواعد الحظر القوية
        let rules = AdBlockManager.shared.createContentBlockerRules()
        WKContentRuleListStore.default().compileContentRuleList(
            forIdentifier: "SmartBlockList",
            encodedContentRuleList: rules
        ) { list, error in
            if let list = list {
                DispatchQueue.main.async {
                    config.userContentController.add(list)
                }
            }
        }
        
        // 2. حقن السكريبت الذكي
        let scriptSource = AdBlockManager.shared.getSmartInjectionScript()
        let script = WKUserScript(source: scriptSource, injectionTime: .atDocumentStart, forMainFrameOnly: false)
        config.userContentController.addUserScript(script)
        
        // 3. تحسين العرض (Viewport)
        let viewportScript = WKUserScript(
            source: "var meta = document.createElement('meta'); meta.name = 'viewport'; meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no'; document.getElementsByTagName('head')[0].appendChild(meta);",
            injectionTime: .atDocumentEnd,
            forMainFrameOnly: true
        )
        config.userContentController.addUserScript(viewportScript)
        
        let webView = WKWebView(frame: .zero, configuration: config)
        viewModel.webView = webView
        
        webView.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
        
        webView.allowsBackForwardNavigationGestures = true
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        
        // إضافة Refresh Control
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(context.coordinator, action: #selector(Coordinator.reloadWebView), for: .valueChanged)
        webView.scrollView.refreshControl = refreshControl
        
        return webView
    }
    
    func updateUIView(_ webView: WKWebView, context: Context) {
        if webView.url == nil {
            webView.load(URLRequest(url: url))
        }
    }
    
    class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        var parent: WebView
        var viewModel: WebViewModel
        
        init(_ parent: WebView, viewModel: WebViewModel) {
            self.parent = parent
            self.viewModel = viewModel
        }
        
        @objc func reloadWebView() {
            parent.viewModel.reload()
        }
        
        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            DispatchQueue.main.async {
                self.viewModel.isLoading = true
                self.viewModel.canGoBack = webView.canGoBack
                self.viewModel.canGoForward = webView.canGoForward
            }
        }
        
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            DispatchQueue.main.async {
                self.viewModel.isLoading = false
                webView.scrollView.refreshControl?.endRefreshing()
                self.viewModel.canGoBack = webView.canGoBack
                self.viewModel.canGoForward = webView.canGoForward
                if let url = webView.url {
                    self.viewModel.currentURL = url.absoluteString
                    self.viewModel.websitesManager?.saveLastURL(url.absoluteString)
                }
            }
        }
        
        // سياسة الحظر والتنقل
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else { return decisionHandler(.cancel) }
            
            // السماح بالروابط الداخلية والآمنة
            if ["about", "blob", "data"].contains(url.scheme) { return decisionHandler(.allow) }
            
            if let host = url.host?.lowercased() {
                // التحقق إذا كان الرابط هو رابط إعلاني معروف
                if SmartRules.domains.contains(where: { host.contains($0) }) {
                    print("🛑 Blocked Nav to Ad: \(host)")
                    DispatchQueue.main.async { self.viewModel.adsBlocked += 1 }
                    return decisionHandler(.cancel)
                }
                
                // القائمة البيضاء (مواقعك + مواقع آمنة)
                let allowed = ["vercel", "github", "google", "youtube", "apple"] + (viewModel.websitesManager?.getAllowedDomains() ?? [])
                if allowed.contains(where: { host.contains($0) }) {
                    return decisionHandler(.allow)
                }
            }
            
            // منع فتح نوافذ جديدة (Popups)
            if navigationAction.targetFrame == nil {
                print("🚫 Blocked Popup Window")
                webView.load(navigationAction.request) // إجبار التحميل في نفس النافذة
                return decisionHandler(.cancel)
            }
            
            // السماح بباقي التصفح بشكل افتراضي (لتحسين التجربة)
            decisionHandler(.allow)
        }
        
        // منع النوافذ المنبثقة من نوع createWebView
        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            return nil
        }
    }
}

// MARK: - 4. واجهات المستخدم (UI)

struct WebsitesBarView: View {
    @ObservedObject var websitesManager: WebsitesManager
    @ObservedObject var viewModel: WebViewModel
    @Binding var isVisible: Bool
    @State private var showAddSheet = false
    
    var body: some View {
        VStack(spacing: 0) {
            // الهيدر
            HStack {
                Button(action: { withAnimation(.spring()) { isVisible = false } }) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 24))
                        .foregroundColor(.white.opacity(0.7))
                }
                
                Button(action: { showAddSheet = true }) {
                    Image(systemName: "plus.circle.fill")
                        .font(.system(size: 24))
                        .foregroundColor(.blue)
                }
                
                Spacer()
                
                VStack(alignment: .trailing) {
                    Text("مواقعي").font(.headline).foregroundColor(.white)
                    if viewModel.adsBlocked > 0 {
                        Text("تم حظر \(viewModel.adsBlocked) إعلان")
                            .font(.caption2)
                            .foregroundColor(.green)
                    }
                }
            }
            .padding(15)
            
            Divider().background(Color.white.opacity(0.1))
            
            if websitesManager.websites.isEmpty {
                VStack(spacing: 15) {
                    Image(systemName: "globe").font(.system(size: 50)).foregroundColor(.white.opacity(0.3))
                    Text("لا توجد مواقع").foregroundColor(.gray)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ScrollView {
                    VStack(spacing: 0) {
                        ForEach(websitesManager.websites) { website in
                            WebsiteRowView(website: website, viewModel: viewModel)
                                .onTapGesture {
                                    if let url = URL(string: website.url) {
                                        viewModel.loadUrl(url: url)
                                        withAnimation(.spring()) { isVisible = false }
                                    }
                                }
                                .contextMenu {
                                    Button(role: .destructive) { websitesManager.deleteWebsite(website) } label: {
                                        Label("حذف", systemImage: "trash")
                                    }
                                }
                        }
                    }
                    .padding(.top, 5)
                }
            }
        }
        .frame(width: 280)
        .background(Color(hex: "1a1a1a"))
        .edgesIgnoringSafeArea(.vertical)
        .sheet(isPresented: $showAddSheet) {
            AddWebsiteView(websitesManager: websitesManager)
        }
    }
}

struct WebsiteRowView: View {
    let website: Website
    @ObservedObject var viewModel: WebViewModel
    
    var isCurrentSite: Bool {
        viewModel.currentURL.contains(extractDomain(from: website.url))
    }
    
    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(LinearGradient(colors: [Color.blue.opacity(0.8), Color.purple.opacity(0.6)], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 45, height: 45)
                
                // 👈 استخدام Kingfisher القوي هنا
                KFImage(URL(string: "https://www.google.com/s2/favicons?domain=\(website.url)&sz=128"))
                    .placeholder {
                        Text(String(website.name.prefix(1)).uppercased())
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                    }
                    .resizable()
                    .fade(duration: 0.25)
                    .cacheOriginalImage()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 28, height: 28)
                    .clipShape(Circle())
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text(website.name).font(.system(size: 15, weight: .semibold)).foregroundColor(.white).lineLimit(1)
                Text(extractDomain(from: website.url)).font(.system(size: 12)).foregroundColor(.white.opacity(0.5)).lineLimit(1)
            }
            
            Spacer()
            
            if isCurrentSite {
                Circle().fill(Color.green).frame(width: 8, height: 8)
            }
        }
        .padding(.horizontal, 15)
        .padding(.vertical, 12)
        .background(isCurrentSite ? Color.white.opacity(0.1) : Color.clear)
        .cornerRadius(10)
        .padding(.horizontal, 10)
    }
    
    func extractDomain(from urlString: String) -> String {
        guard let url = URL(string: urlString), let host = url.host else { return urlString }
        return host.replacingOccurrences(of: "www.", with: "")
    }
}

struct AddWebsiteView: View {
    @ObservedObject var websitesManager: WebsitesManager
    @Environment(\.dismiss) var dismiss
    @State private var name = ""
    @State private var url = ""
    
    var body: some View {
        NavigationView {
            Form {
                TextField("الاسم", text: $name)
                TextField("الرابط", text: $url).keyboardType(.URL)
                Button("إضافة") {
                    let finalUrl = url.lowercased().hasPrefix("http") ? url : "https://\(url)"
                    if !name.isEmpty, URL(string: finalUrl) != nil {
                        websitesManager.addWebsite(Website(name: name, url: finalUrl))
                        dismiss()
                    }
                }
                .disabled(name.isEmpty || url.isEmpty)
            }
            .navigationTitle("إضافة موقع")
        }
    }
}

// MARK: - 5. الواجهة الرئيسية

struct ContentView: View {
    @StateObject var viewModel = WebViewModel()
    @StateObject var websitesManager = WebsitesManager()
    @State private var isToolbarHidden = true
    @State private var showWebsitesBar = false
    @State private var initialURL: String = UserDefaults.standard.string(forKey: "last_opened_url") ?? "https://vercel.com/"
    
    let homeUrl = "https://vercel.com/"
    
    var body: some View {
        ZStack(alignment: .trailing) {
            
            VStack(spacing: 0) {
                if viewModel.isLoading {
                    ProgressView().progressViewStyle(LinearProgressViewStyle(tint: .blue)).frame(height: 2)
                }
                WebView(url: URL(string: initialURL)!, viewModel: viewModel)
            }
            .edgesIgnoringSafeArea(.all)
            .onAppear { viewModel.websitesManager = websitesManager }
            
            if showWebsitesBar {
                WebsitesBarView(websitesManager: websitesManager, viewModel: viewModel, isVisible: $showWebsitesBar)
                    .transition(.move(edge: .trailing))
                    .frame(maxWidth: .infinity, alignment: .trailing)
                    .zIndex(5)
            }
            
            // Toolbar
            VStack(spacing: 20) {
                Button(action: {
                    withAnimation(.spring()) {
                        showWebsitesBar.toggle()
                        if showWebsitesBar { isToolbarHidden = true }
                    }
                }) {
                    ZStack {
                        Image(systemName: "globe").font(.title3).foregroundColor(showWebsitesBar ? .blue : .primary)
                        if viewModel.adsBlocked > 0 {
                            Circle().fill(Color.red).frame(width: 8, height: 8).offset(x: 10, y: -10)
                        }
                    }
                }
                
                Divider().frame(width: 30).background(Color.gray.opacity(0.3))
                
                Button(action: { viewModel.reload() }) { Image(systemName: "arrow.clockwise").font(.headline) }
                Button(action: { if let url = URL(string: homeUrl) { viewModel.loadUrl(url: url) } }) { Image(systemName: "house.fill").font(.title3).foregroundColor(.blue) }
                Button(action: { viewModel.goBack() }) { Image(systemName: "chevron.backward").font(.headline) }.disabled(!viewModel.canGoBack)
                Button(action: { viewModel.goForward() }) { Image(systemName: "chevron.forward").font(.headline) }.disabled(!viewModel.canGoForward)
            }
            .padding(15)
            .background(.ultraThinMaterial)
            .cornerRadius(20, corners: [.topLeft, .bottomLeft])
            .shadow(radius: 5)
            .offset(x: isToolbarHidden ? 80 : 0)
            .gesture(DragGesture().onChanged { if $0.translation.width > 5 { withAnimation { isToolbarHidden = true } } })
            .zIndex(4)
            
            if isToolbarHidden {
                Color.clear.frame(width: 25).contentShape(Rectangle())
                    .gesture(DragGesture().onChanged { if $0.translation.width < -10 { withAnimation { isToolbarHidden = false } } })
                    .zIndex(10)
            }
        }
    }
}

// Helpers
extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}

extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default: (a, r, g, b) = (1, 1, 1, 0)
        }
        self.init(.sRGB, red: Double(r) / 255, green: Double(g) / 255, blue: Double(b) / 255, opacity: Double(a) / 255)
    }
}
