import SwiftUI
@preconcurrency import WebKit

// 1. نموذج الموقع
struct Website: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
    var url: String
    var favicon: String? // يمكن إضافة رابط صورة مصغرة
    var dateAdded: Date = Date()
    
    // للحصول على النطاق
    var domain: String {
        guard let url = URL(string: url),
              let host = url.host else { return "" }
        return host.replacingOccurrences(of: "www.", with: "")
    }
}

// 2. مدير المواقع (للحفظ والاسترجاع)
class WebsitesManager: ObservableObject {
    @Published var websites: [Website] = []
    
    private let key = "saved_websites"
    private let lastURLKey = "last_opened_url"
    
    init() {
        loadWebsites()
    }
    
    func loadWebsites() {
        if let data = UserDefaults.standard.data(forKey: key),
           let decoded = try? JSONDecoder().decode([Website].self, from: data) {
            websites = decoded
        }
    }
    
    func saveWebsites() {
        if let encoded = try? JSONEncoder().encode(websites) {
            UserDefaults.standard.set(encoded, forKey: key)
        }
    }
    
    func addWebsite(_ website: Website) {
        websites.insert(website, at: 0)
        saveWebsites()
    }
    
    func deleteWebsite(_ website: Website) {
        websites.removeAll { $0.id == website.id }
        saveWebsites()
    }
    
    // حفظ آخر رابط تم فتحه
    func saveLastURL(_ urlString: String) {
        UserDefaults.standard.set(urlString, forKey: lastURLKey)
    }
    
    // استرجاع آخر رابط
    func getLastURL() -> String? {
        return UserDefaults.standard.string(forKey: lastURLKey)
    }
    
    // الحصول على جميع النطاقات المحفوظة
    func getAllowedDomains() -> [String] {
        return websites.map { $0.domain }
    }
}

// 3. نموذج إدارة الحالة
class WebViewModel: ObservableObject {
    @Published var isLoading: Bool = false
    @Published var canGoBack: Bool = false
    @Published var canGoForward: Bool = false
    @Published var currentURL: String = ""
    
    var webView: WKWebView?
    var websitesManager: WebsitesManager?
    
    func goBack() { webView?.goBack() }
    func goForward() { webView?.goForward() }
    func reload() { webView?.reload() }
    func loadUrl(url: URL) {
        webView?.load(URLRequest(url: url))
        websitesManager?.saveLastURL(url.absoluteString)
    }
}

// 4. الويب فيو
struct WebView: UIViewRepresentable {
    let url: URL
    @ObservedObject var viewModel: WebViewModel
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self, viewModel: viewModel)
    }
    
    func makeUIView(context: Context) -> WKWebView {
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        
        let config = WKWebViewConfiguration()
        config.defaultWebpagePreferences = prefs
        config.allowsInlineMediaPlayback = true
        
        let source = """
        var meta = document.createElement('meta');
        meta.name = 'viewport';
        meta.content = 'width=device-width, initial-scale=0.7, maximum-scale=0.7, user-scalable=no';
        var head = document.getElementsByTagName('head')[0];
        head.appendChild(meta);
        """
        
        let script = WKUserScript(source: source, injectionTime: .atDocumentEnd, forMainFrameOnly: true)
        config.userContentController.addUserScript(script)
        
        let webView = WKWebView(frame: .zero, configuration: config)
        viewModel.webView = webView
        
        webView.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1"
        
        webView.allowsBackForwardNavigationGestures = true
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(context.coordinator, action: #selector(Coordinator.reloadWebView), for: .valueChanged)
        webView.scrollView.refreshControl = refreshControl
        webView.scrollView.bounces = true
        
        return webView
    }
    
    func updateUIView(_ webView: WKWebView, context: Context) {
        if webView.url == nil {
            let request = URLRequest(url: url)
            webView.load(request)
        }
    }
    
    class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        var parent: WebView
        var viewModel: WebViewModel
        
        init(_ parent: WebView, viewModel: WebViewModel) {
            self.parent = parent
            self.viewModel = viewModel
        }
        
        @objc func reloadWebView() {
            parent.viewModel.reload()
        }
        
        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            DispatchQueue.main.async {
                self.viewModel.isLoading = true
                self.viewModel.canGoBack = webView.canGoBack
                self.viewModel.canGoForward = webView.canGoForward
            }
        }
        
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            DispatchQueue.main.async {
                self.viewModel.isLoading = false
                webView.scrollView.refreshControl?.endRefreshing()
                self.viewModel.canGoBack = webView.canGoBack
                self.viewModel.canGoForward = webView.canGoForward
                if let url = webView.url {
                    self.viewModel.currentURL = url.absoluteString
                    // حفظ الرابط الحالي
                    self.viewModel.websitesManager?.saveLastURL(url.absoluteString)
                }
            }
        }
        
        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            DispatchQueue.main.async {
                self.viewModel.isLoading = false
                webView.scrollView.refreshControl?.endRefreshing()
            }
        }
        
        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if let url = navigationAction.request.url {
                webView.load(navigationAction.request)
            }
            return nil
        }
        
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else {
                decisionHandler(.cancel)
                return
            }
            
            if url.scheme == "about" {
                decisionHandler(.allow)
                return
            }
            
            if let host = url.host?.lowercased() {
                // القائمة الافتراضية
                let defaultDomains: [String] = [
                    "vercel.com", "vercel.app", "assets.vercel.com",
                    "github.com", "githubusercontent", "github.io",
                    "google", "gstatic", "googleapis", "cloudflare"
                ]
                
                // النطاقات المحفوظة من المواقع
                let savedDomains = viewModel.websitesManager?.getAllowedDomains() ?? []
                
                // دمج القوائم
                let allAllowedDomains = defaultDomains + savedDomains
                
                // التحقق من السماح
                for domain in allAllowedDomains {
                    if host.contains(domain.lowercased()) {
                        decisionHandler(.allow)
                        return
                    }
                }
            }
            
            // حظر أي شيء آخر
            print("Blocked external link: \(url.absoluteString)")
            decisionHandler(.cancel)
        }
    }
}

// 5. شريط المواقع
struct WebsitesBarView: View {
    @ObservedObject var websitesManager: WebsitesManager
    @ObservedObject var viewModel: WebViewModel
    @Binding var isVisible: Bool
    @State private var showAddSheet = false
    
    var body: some View {
        VStack(spacing: 0) {
            // الهيدر
            HStack {
                // زر الإغلاق (على اليسار)
                Button(action: {
                    withAnimation(.spring()) {
                        isVisible = false
                    }
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 24))
                        .foregroundColor(.white.opacity(0.7))
                }
                
                // زر الإضافة
                Button(action: { showAddSheet = true }) {
                    Image(systemName: "plus.circle.fill")
                        .font(.system(size: 24))
                        .foregroundColor(.blue)
                }
                
                Spacer()
                
                Text("مواقعي")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(.white)
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 15)
            
            Divider()
                .background(Color.white.opacity(0.1))
            
            // قائمة المواقع
            if websitesManager.websites.isEmpty {
                VStack(spacing: 15) {
                    Image(systemName: "globe")
                        .font(.system(size: 50))
                        .foregroundColor(.white.opacity(0.3))
                    
                    Text("لا توجد مواقع محفوظة")
                        .font(.system(size: 16))
                        .foregroundColor(.white.opacity(0.5))
                    
                    Text("اضغط على + لإضافة موقع جديد")
                        .font(.system(size: 14))
                        .foregroundColor(.white.opacity(0.3))
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ScrollView {
                    VStack(spacing: 0) {
                        ForEach(websitesManager.websites) { website in
                            WebsiteRowView(website: website, viewModel: viewModel)
                                .contentShape(Rectangle())
                                .onTapGesture {
                                    if let url = URL(string: website.url) {
                                        viewModel.loadUrl(url: url)
                                        withAnimation(.spring()) {
                                            isVisible = false
                                        }
                                    }
                                }
                                .contextMenu {
                                    Button(role: .destructive) {
                                        websitesManager.deleteWebsite(website)
                                    } label: {
                                        Label("حذف", systemImage: "trash")
                                    }
                                }
                        }
                    }
                    .padding(.top, 5)
                }
            }
        }
        .frame(width: 280)
        .background(Color(hex: "1a1a1a"))
        .edgesIgnoringSafeArea(.vertical)
        .sheet(isPresented: $showAddSheet) {
            AddWebsiteView(websitesManager: websitesManager)
        }
    }
}

// 6. صف الموقع
struct WebsiteRowView: View {
    let website: Website
    @ObservedObject var viewModel: WebViewModel
    
    var isCurrentSite: Bool {
        viewModel.currentURL.contains(extractDomain(from: website.url))
    }
    
    var body: some View {
        HStack(spacing: 12) {
            // أيقونة الموقع مع صورة حقيقية
            ZStack {
                Circle()
                    .fill(LinearGradient(
                        colors: [Color.blue.opacity(0.8), Color.purple.opacity(0.6)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ))
                    .frame(width: 45, height: 45)
                
                // محاولة تحميل favicon حقيقي
                AsyncImage(url: URL(string: "https://www.google.com/s2/favicons?domain=\(website.url)&sz=128")) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 28, height: 28)
                            .clipShape(Circle())
                    case .failure(_), .empty:
                        // في حالة الفشل، عرض الحرف الأول
                        Text(String(website.name.prefix(1)).uppercased())
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                    @unknown default:
                        Text(String(website.name.prefix(1)).uppercased())
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                    }
                }
            }
            
            // معلومات الموقع
            VStack(alignment: .leading, spacing: 4) {
                Text(website.name)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.white)
                    .lineLimit(1)
                
                Text(extractDomain(from: website.url))
                    .font(.system(size: 12))
                    .foregroundColor(.white.opacity(0.5))
                    .lineLimit(1)
            }
            
            Spacer()
            
            // مؤشر الموقع الحالي
            if isCurrentSite {
                Circle()
                    .fill(Color.green)
                    .frame(width: 8, height: 8)
            }
        }
        .padding(.horizontal, 15)
        .padding(.vertical, 12)
        .background(
            isCurrentSite ?
            Color.white.opacity(0.1) :
                Color.clear
        )
        .cornerRadius(10)
        .padding(.horizontal, 10)
    }
    
    func extractDomain(from urlString: String) -> String {
        guard let url = URL(string: urlString),
              let host = url.host else { return urlString }
        return host.replacingOccurrences(of: "www.", with: "")
    }
}

// 7. شاشة إضافة موقع
struct AddWebsiteView: View {
    @ObservedObject var websitesManager: WebsitesManager
    @Environment(\.dismiss) var dismiss
    
    @State private var name = ""
    @State private var url = ""
    @State private var showError = false
    
    var body: some View {
        NavigationView {
            Form {
                Section {
                    TextField("اسم الموقع", text: $name)
                        .textInputAutocapitalization(.words)
                    
                    TextField("رابط الموقع", text: $url)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.URL)
                        .autocorrectionDisabled()
                } header: {
                    Text("معلومات الموقع")
                }
                
                Section {
                    Button("إضافة الموقع") {
                        addWebsite()
                    }
                    .frame(maxWidth: .infinity)
                    .disabled(name.isEmpty || url.isEmpty)
                }
            }
            .navigationTitle("إضافة موقع جديد")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("إلغاء") {
                        dismiss()
                    }
                }
            }
            .alert("خطأ", isPresented: $showError) {
                Button("حسناً", role: .cancel) { }
            } message: {
                Text("الرجاء إدخال رابط صحيح")
            }
        }
    }
    
    func addWebsite() {
        var finalUrl = url.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if !finalUrl.hasPrefix("http://") && !finalUrl.hasPrefix("https://") {
            finalUrl = "https://" + finalUrl
        }
        
        guard URL(string: finalUrl) != nil else {
            showError = true
            return
        }
        
        let website = Website(name: name, url: finalUrl)
        websitesManager.addWebsite(website)
        dismiss()
    }
}

// 8. الواجهة الرئيسية
struct ContentView: View {
    @StateObject var viewModel = WebViewModel()
    @StateObject var websitesManager = WebsitesManager()
    
    @State private var isToolbarHidden = true
    @State private var showWebsitesBar = false
    
    // قراءة الرابط المحفوظ
    @State private var initialURL: String = UserDefaults.standard.string(forKey: "last_opened_url") ?? "https://vercel.com/"
    
    let homeUrl = "https://vercel.com/"
    let toolbarWidth: CGFloat = 55
    
    var body: some View {
        ZStack(alignment: .trailing) { // التراصف لليمين مهم هنا
            
            // 1. الموقع
            VStack(spacing: 0) {
                if viewModel.isLoading {
                    ProgressView()
                        .progressViewStyle(LinearProgressViewStyle(tint: .blue))
                        .frame(height: 2)
                        .zIndex(2)
                }
                
                WebView(url: URL(string: initialURL)!, viewModel: viewModel)
            }
            .edgesIgnoringSafeArea(.all)
            .onAppear {
                viewModel.websitesManager = websitesManager
            }
            
            // 2. شريط المواقع (من اليمين)
            if showWebsitesBar {
                WebsitesBarView(
                    websitesManager: websitesManager,
                    viewModel: viewModel,
                    isVisible: $showWebsitesBar
                )
                .transition(.move(edge: .trailing))
                .frame(maxWidth: .infinity, alignment: .trailing)
                .zIndex(5)
            }
            
            // 3. شريط الأدوات العامودي
            VStack(spacing: 20) {
                
                // زر المواقع
                Button(action: {
                    withAnimation(.spring()) {
                        showWebsitesBar.toggle()
                        if showWebsitesBar {
                            isToolbarHidden = true
                        }
                    }
                }) {
                    Image(systemName: "globe")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(showWebsitesBar ? .blue : .primary)
                }
                
                Divider()
                    .frame(width: 30)
                    .background(Color.gray.opacity(0.3))
                
                // زر التحديث
                Button(action: { viewModel.reload() }) {
                    Image(systemName: "arrow.clockwise")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.primary)
                }
                
                // زر الرئيسية
                Button(action: {
                    if let url = URL(string: homeUrl) { viewModel.loadUrl(url: url) }
                }) {
                    Image(systemName: "house.fill")
                        .font(.system(size: 20))
                        .foregroundColor(.blue)
                }
                
                // زر الرجوع
                Button(action: { viewModel.goBack() }) {
                    Image(systemName: "chevron.backward")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(viewModel.canGoBack ? .primary : .gray.opacity(0.3))
                }
                .disabled(!viewModel.canGoBack)
                
                // زر التقدم
                Button(action: { viewModel.goForward() }) {
                    Image(systemName: "chevron.forward")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(viewModel.canGoForward ? .primary : .gray.opacity(0.3))
                }
                .disabled(!viewModel.canGoForward)
                
            }
            .padding(.vertical, 20)
            .padding(.horizontal, 10)
            .background(.ultraThinMaterial)
            .cornerRadius(20, corners: [.topLeft, .bottomLeft])
            .shadow(color: Color.black.opacity(0.15), radius: 5, x: -2, y: 0)
            .offset(x: isToolbarHidden ? toolbarWidth + 20 : 0)
            .gesture(
                DragGesture(minimumDistance: 5)
                    .onChanged { value in
                        // إخفاء الشريط بالسحب من اليسار لليمين
                        if value.translation.width > 5 {
                            withAnimation(.spring()) {
                                isToolbarHidden = true
                            }
                        }
                    }
            )
            .zIndex(4)
            .padding(.trailing, 0)
            
            // 4. منطقة الحافة اليمنى للسحب (Edge Gesture)
            // هذه الطبقة تظهر فقط عند إخفاء الشريط لتفعيل السحب من الحافة
            if isToolbarHidden {
                Color.clear
                    .frame(width: 25) // عرض المنطقة الحساسة (25 نقطة من الحافة اليمنى)
                    .contentShape(Rectangle()) // يجعل المنطقة الفارغة قابلة للمس
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                // التحقق أن السحب من اليمين لليسار
                                if value.translation.width < -10 {
                                    withAnimation(.spring()) {
                                        isToolbarHidden = false
                                    }
                                }
                            }
                    )
                    .zIndex(10) // طبقة عليا لتستقبل اللمس فوق الويب فيو
            }
        }
    }
}

// أدوات التشكيل
extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners
    
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}

// دعم الألوان Hex
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3:
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6:
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8:
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (1, 1, 1, 0)
        }
        
        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue:  Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}
