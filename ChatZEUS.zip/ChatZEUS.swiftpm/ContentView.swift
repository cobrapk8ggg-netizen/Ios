import SwiftUI
import SpriteKit
import GameplayKit
import UIKit
import CoreGraphics

// ==========================================
// 1. إعدادات التصادم (Physics Categories)
// ==========================================
struct PhysicsCategory {
    static let none: UInt32 = 0
    static let bird: UInt32 = 0b1       // 1
    static let obstacle: UInt32 = 0b10  // 2
    static let ground: UInt32 = 0b100   // 4
    static let scoreGap: UInt32 = 0b1000 // 8
    static let bonus: UInt32 = 0b10000   // 16
}

// ==========================================
// 2. كائن الطائر المخصص (Bird Node)
// ==========================================
class BirdNode: SKShapeNode {
    var wing: SKShapeNode!
    var trail: SKEmitterNode?
    
    override init() {
        super.init()
        // الجسم
        let birdPath = CGPath(ellipseIn: CGRect(x: -20, y: -15, width: 40, height: 30), transform: nil)
        self.path = birdPath
        self.fillColor = .systemYellow
        self.strokeColor = .black
        self.lineWidth = 2
        
        // العين
        let eye = SKShapeNode(circleOfRadius: 8)
        eye.position = CGPoint(x: 10, y: 8)
        eye.fillColor = .white
        eye.strokeColor = .black
        eye.lineWidth = 2
        addChild(eye)
        
        let pupil = SKShapeNode(circleOfRadius: 3)
        pupil.position = CGPoint(x: 12, y: 8)
        pupil.fillColor = .black
        pupil.lineWidth = 0
        addChild(pupil)
        
        // المنقار
        let beakPath = CGMutablePath()
        beakPath.move(to: CGPoint(x: 15, y: 0))
        beakPath.addLine(to: CGPoint(x: 32, y: -5))
        beakPath.addLine(to: CGPoint(x: 15, y: -10))
        beakPath.closeSubpath()
        let beak = SKShapeNode(path: beakPath)
        beak.fillColor = .orange
        beak.strokeColor = .black
        beak.lineWidth = 2
        beak.zPosition = -1
        addChild(beak)
        
        // الجناح
        let wingPath = CGPath(ellipseIn: CGRect(x: -12, y: -8, width: 24, height: 16), transform: nil)
        wing = SKShapeNode(path: wingPath)
        wing.position = CGPoint(x: -5, y: -5)
        wing.fillColor = .white
        wing.strokeColor = .black
        wing.lineWidth = 2
        addChild(wing)
        
        // الفيزياء
        self.physicsBody = SKPhysicsBody(circleOfRadius: 14)
        self.physicsBody?.categoryBitMask = PhysicsCategory.bird
        self.physicsBody?.collisionBitMask = PhysicsCategory.ground | PhysicsCategory.obstacle
        self.physicsBody?.contactTestBitMask = PhysicsCategory.ground | PhysicsCategory.obstacle | PhysicsCategory.scoreGap | PhysicsCategory.bonus
        self.physicsBody?.isDynamic = false
        self.physicsBody?.restitution = 0.0
        self.physicsBody?.mass = 0.1
        self.physicsBody?.allowsRotation = false
    }
    
    required init?(coder aDecoder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    func setupTrail(targetNode: SKNode) {
        // إزالة الأثر القديم إن وجد
        trail?.removeFromParent()
        
        trail = SKEmitterNode()
        if let t = trail {
            t.particleTexture = nil // مربعات صغيرة للأداء
            t.particleBirthRate = 80
            t.particleLifetime = 0.4
            t.particleColor = .yellow
            t.particleColorBlendFactor = 1.0
            t.particleAlpha = 0.5
            t.particleScale = 5.0 // حجم الجسيمات (لأن التكتشر nil)
            t.particleSpeed = 20
            t.emissionAngle = .pi
            t.emissionAngleRange = .pi / 4
            t.position = CGPoint(x: -20, y: 0)
            
            // جعل الأثر يتبع الطائر لكن يرسم على المشهد الرئيسي ليبقى خلفه
            t.targetNode = targetNode
            addChild(t)
        }
    }
    
    func flap() {
        let flapUp = SKAction.move(by: CGVector(dx: 0, dy: 6), duration: 0.08)
        let flapDown = SKAction.move(by: CGVector(dx: 0, dy: -6), duration: 0.08)
        wing.run(SKAction.sequence([flapUp, flapDown]))
        
        // تأثير توهج عند الرفرفة
        let glow = SKShapeNode(circleOfRadius: 25)
        glow.fillColor = .yellow.withAlphaComponent(0.3)
        glow.strokeColor = .clear
        glow.position = self.position
        glow.zPosition = -1
        if let parent = self.parent {
            parent.addChild(glow)
            glow.run(SKAction.sequence([
                SKAction.group([
                    SKAction.scale(to: 1.5, duration: 0.2),
                    SKAction.fadeOut(withDuration: 0.2)
                ]),
                SKAction.removeFromParent()
            ]))
        }
    }
}

// ==========================================
// 3. مشهد اللعبة (Game Scene)
// ==========================================
class GameScene: SKScene, SKPhysicsContactDelegate {
    
    // --- العناصر الأساسية ---
    var bird: BirdNode!
    var groundNode: SKShapeNode!
    
    // --- الحاويات (Layers) ---
    var skyNode = SKNode()
    var celestialContainer = SKNode()
    var farBuildings = SKNode()
    var midBuildings = SKNode()
    var cloudsContainer = SKNode()
    var pipesContainer = SKNode()
    var movingGroundContainer = SKNode()
    var weatherContainer = SKNode()
    var effectsContainer = SKNode()
    var lightningOverlay: SKShapeNode!
    
    // --- عناصر السماء ---
    var sunNode: SKNode!
    var moonNode: SKNode!
    var starsContainer = SKNode()
    
    // --- متغيرات اللعب ---
    var isGameStarted = false
    var isGameOver = false
    var score = 0
    var highScore = 0
    var combo = 0 // نظام الكومبو الجديد
    
    // --- نظام المراحل اللانهائي ---
    var currentLevel = 1
    var pipeSpeed: CGFloat = 3.2
    var lastPipeHeight: CGFloat = 0
    var pipeSpawnInterval: TimeInterval = 2.0
    
    // Haptics
    let impactFeedback = UIImpactFeedbackGenerator(style: .light)
    let heavyFeedback = UIImpactFeedbackGenerator(style: .heavy)
    let notificationFeedback = UINotificationFeedbackGenerator()
    
    // Callbacks to SwiftUI
    var scoreUpdater: ((Int) -> Void)?
    var gameStateUpdater: ((String) -> Void)?
    var levelUpdater: ((Int, String) -> Void)?
    var highScoreUpdater: ((Int) -> Void)?
    var comboUpdater: ((Int) -> Void)?
    
    override func didMove(to view: SKView) {
        // تأكد من أن حجم المشهد صحيح لتجنب الحسابات الخاطئة
        guard self.size.width > 0 && self.size.height > 0 else { return }
        
        self.physicsWorld.contactDelegate = self
        self.physicsWorld.gravity = CGVector(dx: 0, dy: -8.5)
        
        highScore = UserDefaults.standard.integer(forKey: "HighScoreInfinite")
        updateMainThread { [weak self] in
            guard let self = self else { return }
            self.highScoreUpdater?(self.highScore)
        }
        
        setupLayers()
        createSkyArt()
        startCityBackground()
        createGround()
        setupBird()
        
        for _ in 0...4 { spawnCloud(forceVisible: true) }
        startCloudSpawning()
        
        lastPipeHeight = self.size.height / 2
        resetGameVars()
        
        impactFeedback.prepare()
        heavyFeedback.prepare()
    }
    
    // دالة مساعدة لتحديث الواجهة بأمان
    func updateMainThread(_ block: @escaping () -> Void) {
        if Thread.isMainThread {
            block()
        } else {
            DispatchQueue.main.async(execute: block)
        }
    }
    
    func resetGameVars() {
        score = 0
        combo = 0
        currentLevel = 1
        pipeSpeed = 3.2
        pipeSpawnInterval = 2.2
        
        weatherContainer.removeAllChildren()
        weatherContainer.removeAllActions()
        lightningOverlay.alpha = 0
        lightningOverlay.removeAllActions()
        
        removeAction(forKey: "pipeSpawner")
        
        // مدة صفر للتهيئة الأولية لتجنب الشاشة السوداء
        animateEnvironmentChange(toLevel: 1, duration: 0.0)
        
        updateMainThread { [weak self] in
            guard let self = self else { return }
            self.gameStateUpdater?("START")
            self.scoreUpdater?(0)
            self.comboUpdater?(0)
            self.levelUpdater?(1, self.getLevelName(1))
        }
    }
    
    func setupLayers() {
        // تنظيف الطبقات القديمة إذا وجدت
        removeAllChildren()
        
        // إعادة تهيئة الطبقات
        skyNode = SKNode(); skyNode.zPosition = -100
        celestialContainer = SKNode(); celestialContainer.zPosition = -90
        farBuildings = SKNode(); farBuildings.zPosition = -80
        midBuildings = SKNode(); midBuildings.zPosition = -40
        cloudsContainer = SKNode(); cloudsContainer.zPosition = -60
        pipesContainer = SKNode(); pipesContainer.zPosition = 0
        movingGroundContainer = SKNode(); movingGroundContainer.zPosition = 10
        weatherContainer = SKNode(); weatherContainer.zPosition = 30
        effectsContainer = SKNode(); effectsContainer.zPosition = 100
        
        addChild(skyNode)
        addChild(celestialContainer)
        addChild(farBuildings)
        addChild(cloudsContainer)
        addChild(midBuildings)
        addChild(pipesContainer)
        addChild(movingGroundContainer)
        addChild(weatherContainer)
        addChild(effectsContainer)
        
        lightningOverlay = SKShapeNode(rect: self.frame)
        lightningOverlay.fillColor = .white
        lightningOverlay.strokeColor = .clear
        lightningOverlay.alpha = 0
        lightningOverlay.zPosition = 40
        addChild(lightningOverlay)
    }
    
    // ==========================================
    // 4. التصميم الفني للسماء (Art) - آمن جداً
    // ==========================================
    func createSkyArt() {
        // الشمس
        sunNode = SKNode()
        let sunDisk = SKShapeNode(circleOfRadius: 45)
        sunDisk.fillColor = .yellow
        sunDisk.strokeColor = .orange
        sunDisk.lineWidth = 3
        
        let sunGlow = SKShapeNode(circleOfRadius: 65)
        sunGlow.fillColor = SKColor.yellow.withAlphaComponent(0.3)
        sunGlow.strokeColor = .clear
        
        // أشعة الشمس
        let raysNode = SKNode()
        for i in 0..<12 {
            let angle = CGFloat(i) * (.pi / 6)
            let ray = SKShapeNode(rectOf: CGSize(width: 40, height: 4))
            ray.fillColor = SKColor.orange.withAlphaComponent(0.5)
            ray.strokeColor = .clear
            ray.position = CGPoint(x: cos(angle) * 70, y: sin(angle) * 70)
            ray.zRotation = angle
            raysNode.addChild(ray)
        }
        raysNode.run(SKAction.repeatForever(SKAction.rotate(byAngle: 2 * .pi, duration: 10)))
        sunNode.addChild(raysNode)
        
        sunNode.addChild(sunGlow)
        sunNode.addChild(sunDisk)
        sunNode.position = CGPoint(x: size.width * 0.2, y: size.height * 0.85)
        celestialContainer.addChild(sunNode)
        
        // القمر
        moonNode = SKNode()
        let moonDisk = SKShapeNode(circleOfRadius: 35)
        moonDisk.fillColor = SKColor(white: 0.95, alpha: 1.0)
        moonDisk.strokeColor = .clear
        
        for (x, y, r) in [(8, 8, 6), (-10, -5, 4), (-5, 12, 8)] {
            let crater = SKShapeNode(circleOfRadius: CGFloat(r))
            crater.fillColor = SKColor(white: 0.85, alpha: 1.0)
            crater.strokeColor = .clear
            crater.position = CGPoint(x: x, y: y)
            moonDisk.addChild(crater)
        }
        moonNode.addChild(moonDisk)
        moonNode.position = CGPoint(x: size.width * 0.8, y: -150)
        celestialContainer.addChild(moonNode)
        
        // النجوم
        for _ in 0...50 {
            let star = SKShapeNode(rectOf: CGSize(width: 3, height: 3))
            star.fillColor = .white
            star.strokeColor = .clear
            star.alpha = 0
            star.position = CGPoint(x: CGFloat.random(in: 0...size.width),
                                    y: CGFloat.random(in: size.height*0.3...size.height))
            starsContainer.addChild(star)
            
            let twinkle = SKAction.sequence([
                SKAction.fadeAlpha(to: 0.2, duration: Double.random(in: 1...3)),
                SKAction.fadeAlpha(to: 0.8, duration: Double.random(in: 1...3))
            ])
            star.run(SKAction.repeatForever(twinkle))
        }
        celestialContainer.addChild(starsContainer)
    }
    
    // ==========================================
    // 5. نظام المراحل اللانهائي
    // ==========================================
    
    func getLevelName(_ level: Int) -> String {
        let themeIndex = (level - 1) % 7
        switch themeIndex {
        case 0: return "النهار ☀️"
        case 1: return "الغروب 🌅"
        case 2: return "الليل 🌙"
        case 3: return "العاصفة ⛈️"
        case 4: return "سايبربانك 🤖"
        case 5: return "الشتاء ❄️"
        case 6: return "المريخ 🪐"
        default: return "مجهول"
        }
    }
    
    func checkLevelUp() {
        let newLevel = (score / 10) + 1
        if newLevel != currentLevel {
            currentLevel = newLevel
            
            pipeSpeed = min(6.0, 3.2 + CGFloat(currentLevel) * 0.2)
            pipeSpawnInterval = max(1.4, 2.2 - Double(currentLevel) * 0.1)
            
            // ✅ الإصلاح: نمرر true لنخبر الدالة أن هذا انتقال مستوى
            startSpawningPipes(isLevelUp: true)
            
            animateEnvironmentChange(toLevel: currentLevel, duration: 2.0)
            
            updateMainThread { [weak self] in
                guard let self = self else { return }
                self.levelUpdater?(self.currentLevel, self.getLevelName(self.currentLevel))
            }
            notificationFeedback.notificationOccurred(.warning)
            
            showFloatingText(text: "🎯 المرحلة \(currentLevel)",
                             position: CGPoint(x: size.width/2, y: size.height/2),
                             color: .white, scale: 1.8)
        }
    }
    
    func animateEnvironmentChange(toLevel level: Int, duration: TimeInterval) {
        let themeIndex = (level - 1) % 7
        
        var skyColor: SKColor = .cyan
        var sunPos = CGPoint(x: size.width * 0.2, y: -150)
        var moonPos = CGPoint(x: size.width * 0.8, y: -150)
        var starAlpha: CGFloat = 0.0
        var weatherType: String = "none"
        
        switch themeIndex {
        case 0:
            skyColor = SKColor(red: 0.4, green: 0.7, blue: 1.0, alpha: 1.0)
            sunPos = CGPoint(x: size.width * 0.2, y: size.height * 0.85)
            
        case 1:
            skyColor = SKColor(red: 0.9, green: 0.5, blue: 0.3, alpha: 1.0)
            sunPos = CGPoint(x: size.width * 0.5, y: -150)
            starAlpha = 0.3
            
        case 2:
            skyColor = SKColor(red: 0.05, green: 0.05, blue: 0.2, alpha: 1.0)
            moonPos = CGPoint(x: size.width * 0.8, y: size.height * 0.8)
            starAlpha = 1.0
            
        case 3:
            skyColor = SKColor(red: 0.15, green: 0.15, blue: 0.2, alpha: 1.0)
            weatherType = "rain"
            
        case 4:
            skyColor = SKColor(red: 0.2, green: 0.0, blue: 0.3, alpha: 1.0)
            moonPos = CGPoint(x: size.width * 0.5, y: size.height * 0.6)
            starAlpha = 0.5
            
        case 5:
            skyColor = SKColor(red: 0.8, green: 0.85, blue: 0.9, alpha: 1.0)
            weatherType = "snow"
            sunPos = CGPoint(x: size.width * 0.8, y: size.height * 0.8)
            
        case 6:
            skyColor = SKColor(red: 0.6, green: 0.2, blue: 0.1, alpha: 1.0)
            weatherType = "dust"
            sunPos = CGPoint(x: size.width * 0.1, y: size.height * 0.7)
            
        default: break
        }
        
        if duration == 0 {
            self.backgroundColor = skyColor
            sunNode.position = sunPos
            moonNode.position = moonPos
        } else {
            run(SKAction.colorize(with: skyColor, colorBlendFactor: 1.0, duration: duration))
            sunNode.run(SKAction.move(to: sunPos, duration: duration))
            moonNode.run(SKAction.move(to: moonPos, duration: duration))
        }
        
        for star in starsContainer.children {
            if duration == 0 {
                star.alpha = starAlpha
            } else {
                star.run(SKAction.fadeAlpha(to: starAlpha, duration: duration))
            }
        }
        
        updateWeather(type: weatherType)
        updateBuildingsAppearance(themeIndex: themeIndex)
    }
    
    // ==========================================
    // 6. نظام الطقس
    // ==========================================
    
    func updateWeather(type: String) {
        weatherContainer.removeAllChildren()
        weatherContainer.removeAllActions()
        lightningOverlay.removeAllActions()
        lightningOverlay.alpha = 0
        
        if type == "rain" {
            let spawn = SKAction.run { [weak self] in self?.spawnRainDrop() }
            let wait = SKAction.wait(forDuration: 0.02)
            weatherContainer.run(SKAction.repeatForever(SKAction.sequence([spawn, wait])))
            startLightning()
            
        } else if type == "snow" {
            let spawn = SKAction.run { [weak self] in self?.spawnSnowFlake() }
            let wait = SKAction.wait(forDuration: 0.1)
            weatherContainer.run(SKAction.repeatForever(SKAction.sequence([spawn, wait])))
            
        } else if type == "dust" {
            let spawn = SKAction.run { [weak self] in self?.spawnDust() }
            let wait = SKAction.wait(forDuration: 0.05)
            weatherContainer.run(SKAction.repeatForever(SKAction.sequence([spawn, wait])))
        }
    }
    
    func spawnRainDrop() {
        let drop = SKShapeNode(rectOf: CGSize(width: 2, height: 15))
        drop.fillColor = .white.withAlphaComponent(0.6)
        drop.strokeColor = .clear
        let startX = CGFloat.random(in: 0...size.width)
        drop.position = CGPoint(x: startX, y: size.height + 20)
        drop.zRotation = 0.2
        weatherContainer.addChild(drop)
        
        let duration = Double.random(in: 0.5...0.8)
        let move = SKAction.moveBy(x: -50, y: -size.height - 50, duration: duration)
        drop.run(SKAction.sequence([move, SKAction.removeFromParent()]))
    }
    
    func spawnSnowFlake() {
        let flake = SKShapeNode(circleOfRadius: CGFloat.random(in: 2...4))
        flake.fillColor = .white
        flake.strokeColor = .clear
        let startX = CGFloat.random(in: 0...size.width)
        flake.position = CGPoint(x: startX, y: size.height + 20)
        weatherContainer.addChild(flake)
        
        let duration = Double.random(in: 3.0...6.0)
        let moveY = SKAction.moveBy(x: 0, y: -size.height - 50, duration: duration)
        let sway = SKAction.sequence([
            SKAction.moveBy(x: 20, y: 0, duration: 1.5),
            SKAction.moveBy(x: -20, y: 0, duration: 1.5)
        ])
        flake.run(SKAction.group([moveY, SKAction.repeatForever(sway)]))
        flake.run(SKAction.sequence([SKAction.wait(forDuration: duration), SKAction.removeFromParent()]))
    }
    
    func spawnDust() {
        let dust = SKShapeNode(circleOfRadius: 2)
        dust.fillColor = .orange.withAlphaComponent(0.6)
        dust.strokeColor = .clear
        dust.position = CGPoint(x: size.width + 10, y: CGFloat.random(in: 0...size.height))
        weatherContainer.addChild(dust)
        
        let duration = Double.random(in: 1.0...2.0)
        let move = SKAction.moveBy(x: -size.width - 20, y: CGFloat.random(in: -50...50), duration: duration)
        dust.run(SKAction.sequence([move, SKAction.removeFromParent()]))
    }
    
    func startLightning() {
        let wait = SKAction.wait(forDuration: Double.random(in: 2.0...6.0))
        let flash = SKAction.run { [weak self] in
            guard let self = self else { return }
            self.lightningOverlay.alpha = 0.8
            self.lightningOverlay.run(SKAction.fadeOut(withDuration: 0.15))
            self.notificationFeedback.notificationOccurred(.error)
        }
        let loop = SKAction.sequence([wait, flash, SKAction.run { [weak self] in self?.startLightning() }])
        lightningOverlay.run(loop)
    }
    
    // ==========================================
    // 7. المدينة الحية
    // ==========================================
    
    func startCityBackground() {
        for i in 0...6 { spawnBuilding(layer: farBuildings, x: CGFloat(i)*80, isFar: true) }
        for i in 0...4 { spawnBuilding(layer: midBuildings, x: CGFloat(i)*120, isFar: false) }
        
        let spawnLoop = SKAction.run { [weak self] in
            guard let self = self else { return }
            let w = self.size.width
            if w > 0 {
                self.spawnBuilding(layer: self.farBuildings, x: w, isFar: true)
                if Bool.random() {
                    self.spawnBuilding(layer: self.midBuildings, x: w, isFar: false)
                }
            }
        }
        run(SKAction.repeatForever(SKAction.sequence([spawnLoop, SKAction.wait(forDuration: 1.5)])))
    }
    
    func spawnBuilding(layer: SKNode, x: CGFloat, isFar: Bool) {
        let w = CGFloat.random(in: isFar ? 40...80 : 60...100)
        let h = CGFloat.random(in: isFar ? 100...250 : 150...350)
        
        let building = SKShapeNode(rectOf: CGSize(width: w, height: h))
        building.name = "building"
        building.position = CGPoint(x: x + w/2, y: h/2 + (isFar ? 30 : 60))
        
        updateSingleBuildingColor(building, isFar: isFar, themeIndex: (currentLevel - 1) % 7)
        
        let winSize: CGFloat = isFar ? 4 : 6
        let gap: CGFloat = isFar ? 10 : 14
        let rows = Int(h/gap) - 2
        let cols = Int(w/gap) - 1
        
        for r in 0..<rows {
            for c in 0..<cols {
                if Bool.random() {
                    let win = SKShapeNode(rectOf: CGSize(width: winSize, height: winSize))
                    win.name = "window"
                    let px = (CGFloat(c)*gap) - w/2 + gap
                    let py = (CGFloat(r)*gap) - h/2 + gap
                    win.position = CGPoint(x: px, y: py)
                    building.addChild(win)
                }
            }
        }
        
        layer.addChild(building)
        
        let speed: CGFloat = isFar ? 20.0 : 50.0
        let dist = self.size.width + w*2 + x
        let dur = Double(dist) / Double(speed)
        
        let move = SKAction.moveBy(x: -dist - size.width, y: 0, duration: dur)
        building.run(SKAction.sequence([move, SKAction.removeFromParent()]))
    }
    
    func updateBuildingsAppearance(themeIndex: Int) {
        [farBuildings, midBuildings].forEach { layer in
            layer.children.forEach { node in
                if let b = node as? SKShapeNode {
                    let isFar = layer == farBuildings
                    updateSingleBuildingColor(b, isFar: isFar, themeIndex: themeIndex)
                }
            }
        }
    }
    
    func updateSingleBuildingColor(_ b: SKShapeNode, isFar: Bool, themeIndex: Int) {
        var baseColor: SKColor = .gray
        var strokeColor: SKColor = .darkGray
        var winColor: SKColor = .white
        
        switch themeIndex {
        case 4:
            baseColor = SKColor(red: 0.1, green: 0.05, blue: 0.2, alpha: 1.0)
            strokeColor = .cyan
            winColor = Bool.random() ? .magenta : .cyan
        case 6:
            baseColor = SKColor(red: 0.4, green: 0.2, blue: 0.1, alpha: 1.0)
            strokeColor = .black
            winColor = .orange
        case 2, 3:
            baseColor = SKColor(white: isFar ? 0.2 : 0.3, alpha: 1.0)
            strokeColor = .black
            winColor = .yellow
        case 5:
            baseColor = SKColor(white: 0.8, alpha: 1.0)
            strokeColor = .white
            winColor = .cyan
        default:
            baseColor = SKColor(white: isFar ? 0.5 : 0.6, alpha: 1.0)
            strokeColor = SKColor(white: 0.4, alpha: 1.0)
            winColor = SKColor(white: 0.9, alpha: 0.6)
        }
        
        b.fillColor = baseColor
        b.strokeColor = strokeColor
        b.lineWidth = themeIndex == 4 ? 2 : 1
        
        b.children.forEach { c in
            if c.name == "window", let w = c as? SKShapeNode {
                w.fillColor = winColor
                w.strokeColor = .clear
            }
        }
    }
    
    // ==========================================
    // 8. السحب
    // ==========================================
    func startCloudSpawning() {
        let act = SKAction.run { [weak self] in self?.spawnCloud() }
        let wait = SKAction.wait(forDuration: 3.5, withRange: 1.0)
        run(SKAction.repeatForever(SKAction.sequence([act, wait])))
    }
    
    func spawnCloud(forceVisible: Bool = false) {
        let node = SKNode()
        let count = Int.random(in: 3...6)
        let sizeBase = CGFloat.random(in: 30...50)
        
        let theme = (currentLevel - 1) % 7
        var color = SKColor(white: 1.0, alpha: 0.8)
        if theme == 1 { color = SKColor(red: 1.0, green: 0.9, blue: 0.8, alpha: 0.8) }
        if theme == 3 { color = SKColor(white: 0.3, alpha: 0.8) }
        
        for i in 0..<count {
            let p = SKShapeNode(circleOfRadius: sizeBase * CGFloat.random(in: 0.8...1.2))
            p.fillColor = color
            p.strokeColor = .clear
            p.position = CGPoint(x: CGFloat(i)*sizeBase*0.5, y: CGFloat.random(in: -10...10))
            node.addChild(p)
        }
        
        let startX = forceVisible ? CGFloat.random(in: 0...size.width) : size.width + 200
        let startY = CGFloat.random(in: size.height*0.6...size.height*0.95)
        node.position = CGPoint(x: startX, y: startY)
        cloudsContainer.addChild(node)
        
        let dur = Double.random(in: 20...40)
        let move = SKAction.moveBy(x: -size.width - 400, y: 0, duration: dur)
        node.run(SKAction.sequence([move, SKAction.removeFromParent()]))
    }
    
    // ==========================================
    // 9. الأنابيب الذكية - تم إصلاح مشكلة الاندماج
    // ==========================================
    
    // ✅ تم إضافة معامل لتحديد هل هذا بدء للعبة أم انتقال مستوى
    func startSpawningPipes(isLevelUp: Bool = false) {
        removeAction(forKey: "pipeSpawner")
        
        // إذا كان انتقال مستوى، لا ننشئ أنبوباً فوراً لتجنب التداخل
        if !isLevelUp {
            spawnPipe()
        }
        
        let wait = SKAction.wait(forDuration: pipeSpawnInterval)
        let spawn = SKAction.run { [weak self] in
            guard let self = self, !self.isGameOver else { return }
            self.spawnPipe()
        }
        let sequence = SKAction.sequence([wait, spawn])
        run(SKAction.repeatForever(sequence), withKey: "pipeSpawner")
    }
    
    func spawnPipe() {
        guard size.height > 200 else { return }
        
        let w: CGFloat = 64
        let capH: CGFloat = 26
        let gap = max(130, 180 - CGFloat(currentLevel)*5)
        
        let minH: CGFloat = 60
        let maxAvail = max(minH + 10, size.height - gap - minH - 120)
        
        let delta: CGFloat = 180
        var minNext = max(minH, lastPipeHeight - delta)
        var maxNext = min(maxAvail, lastPipeHeight + delta)
        
        if minNext > maxNext {
            let temp = minNext
            minNext = maxNext
            maxNext = temp
        }
        
        if maxNext <= minNext { maxNext = minNext + 50 }
        
        var h = CGFloat.random(in: minNext...maxNext)
        h = max(minH, min(h, maxAvail))
        lastPipeHeight = h
        
        let theme = (currentLevel - 1) % 7
        var pColor = SKColor.green
        var pStroke = SKColor.black
        
        switch theme {
        case 1: pColor = .orange
        case 3: pColor = .gray
        case 4: pColor = .magenta; pStroke = .cyan
        case 5: pColor = .white; pStroke = .lightGray
        case 6: pColor = .red
        default: pColor = SKColor(red: 0.2, green: 0.8, blue: 0.2, alpha: 1.0)
        }
        
        func makePipe(height: CGFloat, isTop: Bool) -> SKNode {
            let n = SKNode()
            let safeHeight = max(10, height)
            
            let b = SKShapeNode(rectOf: CGSize(width: w-4, height: safeHeight))
            b.fillColor = pColor
            b.strokeColor = pStroke
            b.lineWidth = theme == 4 ? 3 : 2
            
            let c = SKShapeNode(rectOf: CGSize(width: w, height: capH))
            c.fillColor = pColor
            c.strokeColor = pStroke
            c.lineWidth = theme == 4 ? 3 : 2
            
            if theme == 4 {
                b.glowWidth = 5
                c.glowWidth = 5
            }
            
            if isTop {
                b.position = CGPoint(x: 0, y: safeHeight/2 + capH/2)
                c.position = CGPoint(x: 0, y: capH/2)
            } else {
                b.position = CGPoint(x: 0, y: -safeHeight/2 - capH/2)
                c.position = CGPoint(x: 0, y: -capH/2)
            }
            n.addChild(b)
            n.addChild(c)
            
            let totalH = safeHeight + capH
            let offset = isTop ? totalH/2 : -totalH/2
            let pb = SKPhysicsBody(rectangleOf: CGSize(width: w, height: totalH), center: CGPoint(x: 0, y: offset))
            pb.categoryBitMask = PhysicsCategory.obstacle
            pb.collisionBitMask = PhysicsCategory.bird
            pb.contactTestBitMask = PhysicsCategory.bird
            pb.isDynamic = false
            n.physicsBody = pb
            return n
        }
        
        let bot = makePipe(height: h, isTop: false)
        bot.position = CGPoint(x: size.width + w, y: 100 + h)
        
        let topH = size.height - h - gap - 100
        let top = makePipe(height: topH, isTop: true)
        top.position = CGPoint(x: size.width + w, y: size.height - topH)
        
        let scoreN = SKNode()
        scoreN.position = CGPoint(x: size.width + w, y: size.height/2)
        let sb = SKPhysicsBody(rectangleOf: CGSize(width: 20, height: size.height))
        sb.categoryBitMask = PhysicsCategory.scoreGap
        sb.contactTestBitMask = PhysicsCategory.bird
        sb.collisionBitMask = 0
        sb.isDynamic = false
        scoreN.physicsBody = sb
        
        pipesContainer.addChild(bot)
        pipesContainer.addChild(top)
        pipesContainer.addChild(scoreN)
        
        if Int.random(in: 0...2) == 0 {
            let star = SKShapeNode(rectOf: CGSize(width: 24, height: 24), cornerRadius: 4)
            star.fillColor = .yellow
            star.strokeColor = .orange
            star.position = CGPoint(x: size.width + w, y: bot.position.y - h/2 + gap/2 - capH)
            star.run(SKAction.repeatForever(SKAction.rotate(byAngle: 2 * .pi, duration: 2)))
            
            let spb = SKPhysicsBody(rectangleOf: CGSize(width: 24, height: 24))
            spb.categoryBitMask = PhysicsCategory.bonus
            spb.contactTestBitMask = PhysicsCategory.bird
            spb.collisionBitMask = 0
            spb.isDynamic = false
            star.physicsBody = spb
            pipesContainer.addChild(star)
            
            let mvS = SKAction.moveBy(x: -(size.width + w*4), y: 0, duration: 3.5)
            star.run(SKAction.sequence([mvS, SKAction.removeFromParent()]))
        }
        
        let dist = size.width + w*4
        let dur = Double(dist) / Double(pipeSpeed * 60)
        let mv = SKAction.moveBy(x: -dist, y: 0, duration: dur)
        let rem = SKAction.removeFromParent()
        let seq = SKAction.sequence([mv, rem])
        
        bot.run(seq)
        top.run(seq)
        scoreN.run(seq)
    }
    
    // ==========================================
    // 10. الأرضية
    // ==========================================
    func createGround() {
        let h: CGFloat = 80
        groundNode = SKShapeNode(rectOf: CGSize(width: size.width, height: h))
        groundNode.position = CGPoint(x: size.width/2, y: h/2)
        groundNode.fillColor = .clear
        groundNode.strokeColor = .clear
        
        let pb = SKPhysicsBody(rectangleOf: CGSize(width: size.width, height: h))
        pb.categoryBitMask = PhysicsCategory.ground
        pb.collisionBitMask = PhysicsCategory.bird
        pb.isDynamic = false
        groundNode.physicsBody = pb
        addChild(groundNode)
        
        for i in 0...1 {
            let r = SKShapeNode(rect: CGRect(x: 0, y: 0, width: size.width, height: h))
            r.fillColor = SKColor(white: 0.25, alpha: 1.0)
            r.strokeColor = .black
            r.lineWidth = 0
            r.position = CGPoint(x: CGFloat(i)*size.width, y: 0)
            r.name = "gv"
            
            let c = SKShapeNode(rect: CGRect(x: 0, y: h-10, width: size.width, height: 10))
            c.fillColor = .darkGray
            r.addChild(c)
            
            for j in 0...Int(size.width/60) {
                let s = SKShapeNode(rect: CGRect(x: CGFloat(j)*60+10, y: h/2-5, width: 30, height: 10))
                s.fillColor = .white
                r.addChild(s)
            }
            movingGroundContainer.addChild(r)
        }
    }
    
    func moveGround() {
        if isGameOver { return }
        movingGroundContainer.enumerateChildNodes(withName: "gv") { node, _ in
            node.position.x -= self.pipeSpeed * 0.9
            if node.position.x < -self.size.width {
                node.position.x += self.size.width * 2
            }
        }
    }
    
    // ==========================================
    // 11. التحكم والفيزياء
    // ==========================================
    func startGame() {
        isGameStarted = true
        isGameOver = false
        bird.physicsBody?.isDynamic = true
        jump()
        // ✅ بداية اللعبة: نريد أنبوباً فوراً
        startSpawningPipes(isLevelUp: false)
        updateMainThread { [weak self] in
            self?.gameStateUpdater?("PLAYING")
        }
    }
    
    func setupBird() {
        bird = BirdNode()
        bird.position = CGPoint(x: size.width * 0.3, y: size.height * 0.6)
        bird.zPosition = 20
        addChild(bird)
        bird.setupTrail(targetNode: self)
    }
    
    func jump() {
        bird.physicsBody?.velocity = CGVector(dx: 0, dy: 400)
        bird.flap()
        impactFeedback.impactOccurred()
        bird.run(SKAction.rotate(toAngle: 0.4, duration: 0.1))
        
        let p = SKShapeNode(circleOfRadius: 5)
        p.fillColor = .white.withAlphaComponent(0.5)
        p.strokeColor = .clear
        p.position = CGPoint(x: bird.position.x - 10, y: bird.position.y)
        addChild(p)
        p.run(SKAction.sequence([
            SKAction.group([
                SKAction.fadeOut(withDuration: 0.3),
                SKAction.scale(to: 2, duration: 0.3)
            ]),
            SKAction.removeFromParent()
        ]))
    }
    
    func gameOver() {
        if isGameOver { return }
        isGameOver = true
        
        if score > highScore {
            highScore = score
            UserDefaults.standard.set(highScore, forKey: "HighScoreInfinite")
            updateMainThread { [weak self] in
                guard let self = self else { return }
                self.highScoreUpdater?(self.highScore)
            }
        }
        
        heavyFeedback.impactOccurred()
        flashScreen()
        
        removeAction(forKey: "pipeSpawner")
        weatherContainer.removeAllActions()
        lightningOverlay.removeAllActions()
        lightningOverlay.alpha = 0
        removeAllActions()
        pipesContainer.removeAllActions()
        cloudsContainer.removeAllActions()
        
        bird.physicsBody?.velocity = CGVector(dx: 0, dy: -500)
        bird.physicsBody?.angularVelocity = -5
        
        updateMainThread { [weak self] in
            self?.gameStateUpdater?("GAMEOVER")
        }
    }
    
    func restartGame() {
        removeAllChildren()
        removeAllActions()
        
        isGameStarted = false
        isGameOver = false
        
        // إعادة تشغيل دورة الحياة يدوياً
        didMove(to: view!)
    }
    
    func flashScreen() {
        let f = SKShapeNode(rect: frame)
        f.fillColor = .white
        f.strokeColor = .clear
        f.zPosition = 200
        addChild(f)
        f.run(SKAction.sequence([
            SKAction.fadeOut(withDuration: 0.2),
            SKAction.removeFromParent()
        ]))
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        if isGameOver { return }
        let mask = contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask
        
        if (mask & PhysicsCategory.bird != 0) && ((mask & PhysicsCategory.obstacle != 0) || (mask & PhysicsCategory.ground != 0)) {
            combo = 0
            updateMainThread { [weak self] in self?.comboUpdater?(0) }
            gameOver()
            
        } else if (mask & PhysicsCategory.bird != 0) && (mask & PhysicsCategory.scoreGap != 0) {
            let n = (contact.bodyA.categoryBitMask == PhysicsCategory.scoreGap) ? contact.bodyA.node : contact.bodyB.node
            n?.removeFromParent()
            
            score += 1
            combo += 1
            
            updateMainThread { [weak self] in
                guard let self = self else { return }
                self.scoreUpdater?(self.score)
                self.comboUpdater?(self.combo)
            }
            checkLevelUp()
            
            if combo > 1 {
                let comboText = combo >= 5 ? "🔥 FIRE x\(combo)!" : "⚡ x\(combo)"
                showFloatingText(text: comboText, position: bird.position, color: .yellow, scale: 1.2)
            }
            
        } else if (mask & PhysicsCategory.bird != 0) && (mask & PhysicsCategory.bonus != 0) {
            let n = (contact.bodyA.categoryBitMask == PhysicsCategory.bonus) ? contact.bodyA.node : contact.bodyB.node
            if let pos = n?.position {
                showFloatingText(text: "⭐ +5", position: pos, color: .yellow)
            }
            n?.removeFromParent()
            notificationFeedback.notificationOccurred(.success)
            
            score += 5
            updateMainThread { [weak self] in self?.scoreUpdater?(self?.score ?? 0) }
            checkLevelUp()
        }
    }
    
    func showFloatingText(text: String, position: CGPoint, color: SKColor, scale: CGFloat = 1.0) {
        let l = SKLabelNode(text: text)
        l.fontSize = 28 * scale
        l.fontName = "AvenirNext-Bold"
        l.fontColor = color
        l.position = position
        l.zPosition = 100
        effectsContainer.addChild(l)
        l.run(SKAction.sequence([
            SKAction.group([
                SKAction.moveBy(x: 0, y: 60, duration: 1.0),
                SKAction.fadeOut(withDuration: 1.0)
            ]),
            SKAction.removeFromParent()
        ]))
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if !isGameStarted {
            startGame()
        } else if !isGameOver {
            jump()
        }
    }
    
    override func update(_ currentTime: TimeInterval) {
        moveGround()
        if isGameStarted && !isGameOver, let dy = bird.physicsBody?.velocity.dy {
            bird.zRotation = (dy > 0) ? min(0.5, dy*0.001) : max(-1.5, dy*0.003)
        }
    }
}

// ==========================================
// 4. واجهة المستخدم المحسّنة
// ==========================================
struct ContentView: View {
    @State private var score = 0
    @State private var highScore = 0
    @State private var gameState = "START"
    @State private var level = 1
    @State private var levelName = "النهار ☀️"
    @State private var combo = 0
    
    @State var scene: GameScene = {
        let s = GameScene(size: CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height))
        s.scaleMode = .aspectFill
        return s
    }()
    
    var body: some View {
        ZStack {
            SpriteView(scene: scene, options: [.ignoresSiblingOrder])
                .edgesIgnoringSafeArea(.all)
                .onAppear {
                    scene.scoreUpdater = { s in self.score = s }
                    scene.highScoreUpdater = { h in self.highScore = h }
                    scene.gameStateUpdater = { g in self.gameState = g }
                    scene.levelUpdater = { l, n in self.level = l; self.levelName = n }
                    scene.comboUpdater = { c in self.combo = c }
                }
            
            if gameState == "PLAYING" {
                VStack {
                    HStack {
                        Spacer()
                        VStack(alignment: .trailing, spacing: 10) {
                            Text("\(score)")
                                .font(.system(size: 60, weight: .heavy, design: .rounded))
                                .foregroundColor(.white)
                                .shadow(color: .black, radius: 4, x: 2, y: 2)
                            
                            if combo > 1 {
                                HStack(spacing: 5) {
                                    Text(combo >= 5 ? "🔥" : "⚡")
                                    Text("x\(combo)")
                                        .font(.title2.bold())
                                }
                                .foregroundColor(.yellow)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 6)
                                .background(Capsule().fill(Color.orange.opacity(0.8)))
                            }
                            
                            HStack(spacing: 5) {
                                Image(systemName: getLevelIcon(level))
                                Text(levelName)
                            }
                            .font(.caption.bold())
                            .foregroundColor(.white)
                            .padding(8)
                            .background(Material.thinMaterial)
                            .cornerRadius(12)
                        }
                        .padding(.trailing, 20)
                        .padding(.top, 50)
                    }
                    Spacer()
                }
            }
            
            if gameState == "START" {
                VStack(spacing: 25) {
                    Spacer()
                    VStack(spacing: 10) {
                        Text("Epic Bird")
                            .font(.system(size: 70, weight: .black, design: .rounded))
                            .foregroundColor(.white)
                            .shadow(color: .black, radius: 5, x: 3, y: 3)
                        Text("رحلة عبر 7 عوالم")
                            .font(.title3.bold())
                            .foregroundColor(.yellow)
                    }
                    
                    if highScore > 0 {
                        VStack(spacing: 5) {
                            Text("🏆 الرقم القياسي")
                                .font(.caption).foregroundColor(.white.opacity(0.8))
                            Text("\(highScore)")
                                .font(.system(size: 40, weight: .bold, design: .rounded)).foregroundColor(.yellow)
                        }
                        .padding().background(RoundedRectangle(cornerRadius: 15).fill(Color.black.opacity(0.5)))
                    }
                    
                    Text("👆 اضغط للبدء")
                        .font(.title2.bold()).foregroundColor(.white)
                        .padding(.horizontal, 30).padding(.vertical, 15)
                        .background(Capsule().fill(LinearGradient(colors: [.green, .blue], startPoint: .leading, endPoint: .trailing)))
                        .padding(.bottom, 120)
                }
            }
            
            if gameState == "GAMEOVER" {
                ZStack {
                    Color.black.opacity(0.7).edgesIgnoringSafeArea(.all)
                    VStack(spacing: 25) {
                        Text("Game Over")
                            .font(.system(size: 50, weight: .heavy, design: .rounded))
                            .foregroundColor(.white).shadow(radius: 5)
                        
                        VStack(spacing: 20) {
                            HStack(spacing: 40) {
                                VStack(spacing: 5) {
                                    Image(systemName: getLevelIcon(level)).font(.title).foregroundColor(.orange)
                                    Text("المرحلة").font(.caption).foregroundColor(.gray)
                                    Text("\(level)").font(.title.bold())
                                }
                                VStack(spacing: 5) {
                                    Image(systemName: "star.fill").font(.title).foregroundColor(.yellow)
                                    Text("النتيجة").font(.caption).foregroundColor(.gray)
                                    Text("\(score)").font(.title.bold())
                                }
                                if highScore > 0 {
                                    VStack(spacing: 5) {
                                        Image(systemName: "trophy.fill").font(.title).foregroundColor(.green)
                                        Text("الأفضل").font(.caption).foregroundColor(.gray)
                                        Text("\(highScore)").font(.title.bold())
                                    }
                                }
                            }
                            Divider()
                            Button(action: { withAnimation { scene.restartGame() } }) {
                                HStack(spacing: 10) {
                                    Image(systemName: "arrow.clockwise").font(.title3.bold())
                                    Text("إعادة المحاولة").font(.headline)
                                }
                                .foregroundColor(.white).padding().frame(maxWidth: .infinity)
                                .background(LinearGradient(colors: [.blue, .purple], startPoint: .leading, endPoint: .trailing))
                                .cornerRadius(15)
                            }
                        }
                        .padding(30)
                        .background(RoundedRectangle(cornerRadius: 25).fill(Color(UIColor.secondarySystemBackground)))
                        .frame(maxWidth: 350)
                    }
                }
                .transition(.opacity)
            }
        }
        .statusBar(hidden: true)
    }
    
    func getLevelIcon(_ lvl: Int) -> String {
        switch (lvl - 1) % 7 {
        case 0: return "sun.max.fill"
        case 1: return "sunset.fill"
        case 2: return "moon.stars.fill"
        case 3: return "cloud.bolt.rain.fill"
        case 4: return "cpu"
        case 5: return "snowflake"
        case 6: return "globe.americas.fill"
        default: return "star.fill"
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
