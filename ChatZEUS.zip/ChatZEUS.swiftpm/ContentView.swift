import SwiftUI
import WebKit

struct WebView: UIViewRepresentable {
    let url: URL
    
    // إنشاء Coordinator للتعامل مع أحداث الويب وتصفية الإعلانات
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    func makeUIView(context: Context) -> WKWebView {
        // إعدادات لتشغيل الجافاسكريبت والميديا
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        
        let config = WKWebViewConfiguration()
        config.defaultWebpagePreferences = prefs
        config.allowsInlineMediaPlayback = true
        
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.allowsBackForwardNavigationGestures = true
        
        // ربط المندوب (Delegate) للتحكم في النوافذ والتوجيه
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        
        return webView
    }
    
    func updateUIView(_ webView: WKWebView, context: Context) {
        // تحميل الصفحة فقط إذا لم يكن هناك رابط محمل مسبقاً
        if webView.url == nil {
            let request = URLRequest(url: url)
            webView.load(request)
        }
    }
    
    // فئة المنسق (Coordinator) للتحكم في السياسات
    class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        var parent: WebView
        
        init(_ parent: WebView) {
            self.parent = parent
        }
        
        // 1. منع النوافذ المنبثقة (Pop-ups)
        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            // إذا كان الرابط جزءاً من الموقع الأصلي أو Cloudflare، افتحه في نفس الصفحة
            if let url = navigationAction.request.url {
                let urlString = url.absoluteString
                if urlString.contains("olympustaff.com") || urlString.contains("cloudflare") {
                    webView.load(navigationAction.request)
                }
            }
            // إرجاع nil يمنع فتح النافذة الجديدة (الإعلان)
            return nil
        }
        
        // 2. فلترة الروابط (منع الخروج من الموقع باستثناء النطاقات الآمنة)
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else {
                decisionHandler(.cancel)
                return
            }
            
            // السماح بـ about:blank لأنه غالباً جزء من عملية التحميل الداخلية
            if url.absoluteString == "about:blank" {
                decisionHandler(.allow)
                return
            }
            
            // التحقق من النطاق (Host)
            if let host = url.host {
                // السماح بالموقع الأصلي + نطاقات كلاود فلير (للحماية والتحقق)
                if host.contains("olympustaff.com") || host.contains("cloudflare") {
                    decisionHandler(.allow)
                    return
                }
            }
            
            // حظر أي رابط خارجي آخر (إعلانات)
            print("تم حظر الإعلان أو الرابط الخارجي: \(url.absoluteString)")
            decisionHandler(.cancel)
        }
    }
}

struct ContentView: View {
    var body: some View {
        WebView(url: URL(string: "https://olympustaff.com")!)
            .edgesIgnoringSafeArea(.all)
    }
}
