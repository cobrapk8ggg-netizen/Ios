import SwiftUI
@preconcurrency import WebKit
import Kingfisher

// MARK: - 1. المحرك الذكي لحظر الإعلانات (The Smart Engine)

struct SmartRules {
    static let domains: Set<String> = [
        "doubleclick.net", "googleadservices.com", "googlesyndication.com",
        "google-analytics.com", "googletagmanager.com", "facebook.net",
        "scorecardresearch.com", "adnxs.com", "advertising.com",
        "adsystem.com", "admob.com", "inmobi.com", "mopub.com",
        "applovin.com", "unity3d.com", "chartbeat.com", "taboola.com",
        "outbrain.com", "popads.net", "popcash.net", "propellerads.com",
        "adcash.com", "exoclick.com", "clickadu.com", "hilltopads.net",
        "juicyads.com", "trafficjunky.com", "mgid.com", "revcontent.com",
        "criteo.com", "serving-sys.com", "spotxchange.com", "adsrvr.org",
        "pubmatic.com", "rubiconproject.com", "openx.net", "bidswitch.net",
        "casalemedia.com", "lijit.com", "sovrn.com", "ads.twitter.com",
        "amazon-adsystem.com", "smartadserver.com", "truste.com"
    ]
    
    static let allowedDomains: Set<String> = [
        "google.com", "accounts.google.com", "googleapis.com",
        "gstatic.com", "googleusercontent.com", "youtube.com",
        "cloudflare.com", "challenges.cloudflare.com", "turnstile.cloudflare.com",
        "recaptcha.net"
    ]
    
    static let cssSelectors: [String] = [
        ".ad", ".ads", ".advertisement", ".banner", "#ad", "#ads",
        "[id^='google_ads']", "[class*='adsbygoogle']",
        "[class*='popup']", "[id*='popup']", ".modal-overlay",
        "#onetrust-banner-sdk", ".cookie-banner", "#cookie-notice",
        ".fc-ab-root", "iframe[src*='doubleclick']", "iframe[src*='ads']"
    ]
}

class AdBlockManager {
    static let shared = AdBlockManager()
    
    func createContentBlockerRules() -> String {
        var rules: [[String: Any]] = []
        
        for domain in SmartRules.domains {
            rules.append([
                "trigger": [
                    "url-filter": ".*\(domain).*",
                    "resource-type": ["script", "image", "raw", "document", "popup", "style-sheet"]
                ],
                "action": [ "type": "block" ]
            ])
        }
        
        for domain in SmartRules.allowedDomains {
            rules.append([
                "trigger": [
                    "url-filter": ".*\(domain).*"
                ],
                "action": [
                    "type": "ignore-previous-rules"
                ]
            ])
        }
        
        for selector in SmartRules.cssSelectors {
            rules.append([
                "trigger": [ "url-filter": ".*" ],
                "action": [
                    "type": "css-display-none",
                    "selector": selector
                ]
            ])
        }
        
        rules.append([
            "trigger": [
                "url-filter": ".*(ad|ads|preroll|midroll).*mp4",
                "resource-type": ["media"]
            ],
            "action": [ "type": "block" ]
        ])
        
        if let jsonData = try? JSONSerialization.data(withJSONObject: rules, options: []),
           let jsonString = String(data: jsonData, encoding: .utf8) {
            return jsonString
        }
        return "[]"
    }
    
    func getSmartInjectionScript() -> String {
        return """
        (function() {
            console.log('🛡️ Smart AdBlock Engine v3.0');
            
            var whitelist = ['google.com', 'cloudflare.com', 'accounts.google.com', 'recaptcha.net'];
            if (whitelist.some(domain => window.location.hostname.includes(domain))) {
                return;
            }
        
            window.open = function() { console.log('🚫 Pop-up Killed'); return null; };
            Object.defineProperty(window, 'google_ad_status', { get: function() { return 1; } });
            window.canRunAds = true;
            window.isAdBlockActive = false;
            
            function cleanPage() {
                document.querySelectorAll('iframe').forEach(el => {
                    if (el.src.includes('ads') || el.src.includes('google') || el.offsetWidth < 10) {
                        el.remove();
                    }
                });
                document.querySelectorAll('div[style*="position: fixed"]').forEach(el => {
                    if (el.style.zIndex > 900 && el.innerHTML.length < 300) {
                        el.remove();
                    }
                });
                document.querySelectorAll('[class*="float"]').forEach(el => el.remove());
            }
            
            var observer = new MutationObserver(function(mutations) { cleanPage(); });
            observer.observe(document, { childList: true, subtree: true });
            document.addEventListener('DOMContentLoaded', cleanPage);
            setInterval(cleanPage, 3000);
        })();
        """
    }
    
    func getConsoleBridgeScript() -> String {
        return """
        (function() {
            var oldLog = console.log;
            var oldWarn = console.warn;
            var oldError = console.error;
            var oldInfo = console.info;
        
            function sendToSwift(type, args) {
                try {
                    var message = Array.from(args).map(arg => {
                        if (typeof arg === 'object') return JSON.stringify(arg);
                        return String(arg);
                    }).join(' ');
                    
                    window.webkit.messageHandlers.consoleObserver.postMessage({
                        type: type,
                        message: message
                    });
                } catch(e) {}
            }
        
            console.log = function() { sendToSwift('log', arguments); oldLog.apply(console, arguments); };
            console.warn = function() { sendToSwift('warn', arguments); oldWarn.apply(console, arguments); };
            console.error = function() { sendToSwift('error', arguments); oldError.apply(console, arguments); };
            console.info = function() { sendToSwift('info', arguments); oldInfo.apply(console, arguments); };
            
            window.onerror = function(message, source, lineno, colno, error) {
                sendToSwift('error', ['Global Error: ' + message + ' (' + lineno + ')']);
            };
        })();
        """
    }
}

// MARK: - 2. النماذج ومدراء البيانات

struct Website: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
    var url: String
    var dateAdded: Date = Date()
    
    var domain: String {
        guard let url = URL(string: url), let host = url.host else { return "" }
        return host.replacingOccurrences(of: "www.", with: "")
    }
}

class WebsitesManager: ObservableObject {
    @Published var websites: [Website] = []
    private let key = "saved_websites"
    private let lastURLKey = "last_opened_url"
    
    init() { loadWebsites() }
    
    func loadWebsites() {
        if let data = UserDefaults.standard.data(forKey: key),
           let decoded = try? JSONDecoder().decode([Website].self, from: data) {
            websites = decoded
        }
    }
    
    func saveWebsites() {
        if let encoded = try? JSONEncoder().encode(websites) {
            UserDefaults.standard.set(encoded, forKey: key)
        }
    }
    
    func addWebsite(_ website: Website) {
        websites.insert(website, at: 0)
        saveWebsites()
    }
    
    func deleteWebsite(_ website: Website) {
        websites.removeAll { $0.id == website.id }
        saveWebsites()
    }
    
    func saveLastURL(_ urlString: String) {
        UserDefaults.standard.set(urlString, forKey: lastURLKey)
    }
    
    func getAllowedDomains() -> [String] {
        return websites.map { $0.domain }
    }
}

struct HistoryItem: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    let title: String
    let url: String
    let date: Date
}

class HistoryManager: ObservableObject {
    @Published var history: [HistoryItem] = []
    private let historyKey = "browser_history_data"
    
    init() { loadHistory() }
    
    func loadHistory() {
        if let data = UserDefaults.standard.data(forKey: historyKey),
           let decoded = try? JSONDecoder().decode([HistoryItem].self, from: data) {
            history = decoded.sorted(by: { $0.date > $1.date })
        }
    }
    
    func saveHistory() {
        if let encoded = try? JSONEncoder().encode(history) {
            UserDefaults.standard.set(encoded, forKey: historyKey)
        }
    }
    
    func addToHistory(title: String, url: String) {
        if let first = history.first, first.url == url, Date().timeIntervalSince(first.date) < 60 {
            return
        }
        if url.isEmpty || url == "about:blank" || title.isEmpty { return }
        
        let newItem = HistoryItem(title: title, url: url, date: Date())
        history.insert(newItem, at: 0)
        
        if history.count > 1000 {
            history = Array(history.prefix(1000))
        }
        saveHistory()
    }
    
    func deleteItem(_ item: HistoryItem) {
        history.removeAll { $0.id == item.id }
        saveHistory()
    }
    
    func clearAll() {
        history.removeAll()
        saveHistory()
    }
}

// MARK: - NEW: مدير السكربتات ونماذج الكونسول

struct UserScript: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
    var domain: String 
    var code: String
    var isActive: Bool
    var dateCreated: Date = Date()
}

struct ConsoleLog: Identifiable, Equatable {
    var id: UUID = UUID()
    let type: String 
    let message: String
    let timestamp: Date = Date()
}

class ScriptManager: ObservableObject {
    @Published var scripts: [UserScript] = []
    private let scriptsKey = "user_custom_scripts"
    
    init() { loadScripts() }
    
    func loadScripts() {
        if let data = UserDefaults.standard.data(forKey: scriptsKey),
           let decoded = try? JSONDecoder().decode([UserScript].self, from: data) {
            scripts = decoded
        }
    }
    
    func saveScripts() {
        if let encoded = try? JSONEncoder().encode(scripts) {
            UserDefaults.standard.set(encoded, forKey: scriptsKey)
        }
    }
    
    func addOrUpdateScript(_ script: UserScript) {
        if let index = scripts.firstIndex(where: { $0.id == script.id }) {
            scripts[index] = script
        } else {
            scripts.append(script)
        }
        saveScripts()
    }
    
    func deleteScript(_ script: UserScript) {
        scripts.removeAll { $0.id == script.id }
        saveScripts()
    }
    
    func toggleScript(_ script: UserScript) {
        if let index = scripts.firstIndex(where: { $0.id == script.id }) {
            scripts[index].isActive.toggle()
            saveScripts()
        }
    }
    
    func generateInjectionCode() -> String {
        guard let jsonData = try? JSONEncoder().encode(scripts.filter { $0.isActive }),
              let jsonString = String(data: jsonData, encoding: .utf8) else { return "" }
        
        return """
        (function() {
            var scripts = \(jsonString);
            var currentHref = window.location.href;
            
            function runUserScripts() {
                scripts.forEach(function(script) {
                    if (script.domain === '*' || currentHref.includes(script.domain)) {
                        try {
                             setTimeout(function() {
                                 try {
                                     eval(script.code);
                                     console.log('✅ Executed Script: ' + script.name);
                                 } catch(e) {
                                     console.error('❌ Script Runtime Error (' + script.name + '): ' + e.message);
                                 }
                             }, 100);
                        } catch(e) {
                            console.error('❌ Script Load Error (' + script.name + '): ' + e.message);
                        }
                    }
                });
            }
        
            if (document.readyState === 'complete' || document.readyState === 'interactive') {
                runUserScripts();
            } else {
                document.addEventListener('DOMContentLoaded', runUserScripts);
            }
        })();
        """
    }
}

// MARK: - 3. هيكلية التبويبات

struct SavedTabInfo: Codable {
    let id: UUID
    let title: String
    let url: String
}

struct TabItem: Identifiable {
    let id: UUID
    var title: String
    var url: String
    var webView: WKWebView
    
    init(id: UUID = UUID(), title: String, url: String, webView: WKWebView) {
        self.id = id
        self.title = title
        self.url = url
        self.webView = webView
    }
}

class WebViewModel: ObservableObject {
    @Published var tabs: [TabItem] = []
    @Published var currentTabID: UUID
    
    @Published var isLoading: Bool = false
    @Published var canGoBack: Bool = false
    @Published var canGoForward: Bool = false
    @Published var currentURL: String = ""
    @Published var adsBlocked: Int = 0
    
    @Published var isForcedDarkMode: Bool = false
    
    @Published var consoleLogs: [ConsoleLog] = []
    
    var websitesManager: WebsitesManager?
    var historyManager: HistoryManager = HistoryManager()
    var scriptManager: ScriptManager = ScriptManager()
    
    private let savedTabsKey = "browser_saved_tabs_list"
    private let lastActiveTabKey = "browser_last_active_tab_id"
    private let forcedDarkModeKey = "browser_forced_dark_mode_key"
    
    init() {
        self.isForcedDarkMode = UserDefaults.standard.bool(forKey: forcedDarkModeKey)
        scriptManager.loadScripts()
        
        if let data = UserDefaults.standard.data(forKey: "browser_saved_tabs_list"),
           let savedTabsInfo = try? JSONDecoder().decode([SavedTabInfo].self, from: data),
           !savedTabsInfo.isEmpty {
            
            var restoredTabs: [TabItem] = []
            for info in savedTabsInfo {
                let webView = WebViewModel.createConfiguredWebView(scripts: scriptManager.generateInjectionCode())
                if let url = URL(string: info.url) {
                    webView.load(URLRequest(url: url))
                }
                let tab = TabItem(id: info.id, title: info.title, url: info.url, webView: webView)
                restoredTabs.append(tab)
            }
            
            self.tabs = restoredTabs
            
            if let lastIDString = UserDefaults.standard.string(forKey: "browser_last_active_tab_id"),
               let lastID = UUID(uuidString: lastIDString),
               restoredTabs.contains(where: { $0.id == lastID }) {
                self.currentTabID = lastID
            } else {
                self.currentTabID = restoredTabs.first!.id
            }
            
        } else {
            let initialWebView = WebViewModel.createConfiguredWebView(scripts: scriptManager.generateInjectionCode())
            let initialTab = TabItem(title: "البداية", url: "https://google.com/", webView: initialWebView)
            
            self.tabs = [initialTab]
            self.currentTabID = initialTab.id
            
            if let url = URL(string: initialTab.url) {
                initialWebView.load(URLRequest(url: url))
            }
        }
    }
    
    func toggleForcedDarkMode() {
        isForcedDarkMode.toggle()
        UserDefaults.standard.set(isForcedDarkMode, forKey: forcedDarkModeKey)
        applyDarkMode(to: currentWebView)
    }
    
    func applyDarkMode(to webView: WKWebView?) {
        let js: String
        if isForcedDarkMode {
            // هذا الكود يعكس ألوان الصفحة، ثم يعيد عكس ألوان الصور والفيديو لتبدو طبيعية
            js = """
            if (!document.getElementById('forced-dark-mode-style')) {
                var style = document.createElement('style');
                style.id = 'forced-dark-mode-style';
                style.innerHTML = 'html { filter: invert(100%) hue-rotate(180deg) !important; } img, video, iframe, canvas, svg, :not(object):not(body)>embed, object { filter: invert(100%) hue-rotate(180deg) !important; }';
                document.head.appendChild(style);
            }
            """
        } else {
            js = """
            if (document.getElementById('forced-dark-mode-style')) {
                document.getElementById('forced-dark-mode-style').remove();
            }
            """
        }
        webView?.evaluateJavaScript(js)
    }
    
    func saveTabsState() {
        let savedData = tabs.map { SavedTabInfo(id: $0.id, title: $0.title, url: $0.url) }
        if let encoded = try? JSONEncoder().encode(savedData) {
            UserDefaults.standard.set(encoded, forKey: savedTabsKey)
        }
        UserDefaults.standard.set(currentTabID.uuidString, forKey: lastActiveTabKey)
    }
    
    func executeJS(_ js: String) {
        currentWebView?.evaluateJavaScript(js) { result, error in
            if let error = error {
                self.addConsoleLog(type: "error", message: error.localizedDescription)
            } else if let result = result {
                self.addConsoleLog(type: "log", message: "Result: \(result)")
            } else {
                self.addConsoleLog(type: "log", message: "Executed")
            }
        }
    }
    
    func addConsoleLog(type: String, message: String) {
        let log = ConsoleLog(type: type, message: message)
        DispatchQueue.main.async {
            self.consoleLogs.append(log)
            if self.consoleLogs.count > 200 {
                self.consoleLogs.removeFirst()
            }
        }
    }
    
    func clearConsole() {
        consoleLogs.removeAll()
    }
    
    func reloadScriptsInCurrentTab() {
        let code = scriptManager.generateInjectionCode()
        currentWebView?.evaluateJavaScript(code)
    }
    
    static func createConfiguredWebView(scripts: String = "") -> WKWebView {
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        
        let config = WKWebViewConfiguration()
        config.defaultWebpagePreferences = prefs
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        
        let rules = AdBlockManager.shared.createContentBlockerRules()
        WKContentRuleListStore.default().compileContentRuleList(
            forIdentifier: "SmartBlockList",
            encodedContentRuleList: rules
        ) { list, error in
            if let list = list {
                DispatchQueue.main.async {
                    config.userContentController.add(list)
                }
            }
        }
        
        let scriptSource = AdBlockManager.shared.getSmartInjectionScript()
        let script = WKUserScript(source: scriptSource, injectionTime: .atDocumentStart, forMainFrameOnly: false)
        config.userContentController.addUserScript(script)
        
        let consoleBridge = AdBlockManager.shared.getConsoleBridgeScript()
        let consoleScript = WKUserScript(source: consoleBridge, injectionTime: .atDocumentStart, forMainFrameOnly: false)
        config.userContentController.addUserScript(consoleScript)
        
        if !scripts.isEmpty {
            let userScriptObj = WKUserScript(source: scripts, injectionTime: .atDocumentEnd, forMainFrameOnly: false)
            config.userContentController.addUserScript(userScriptObj)
        }
        
        let viewportScript = WKUserScript(
            source: "var meta = document.createElement('meta'); meta.name = 'viewport'; meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no'; document.getElementsByTagName('head')[0].appendChild(meta);",
            injectionTime: .atDocumentEnd,
            forMainFrameOnly: true
        )
        config.userContentController.addUserScript(viewportScript)
        
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
        webView.allowsBackForwardNavigationGestures = true
        
        webView.scrollView.showsVerticalScrollIndicator = false
        webView.scrollView.showsHorizontalScrollIndicator = false
        
        return webView
    }
    
    var currentWebView: WKWebView? {
        tabs.first(where: { $0.id == currentTabID })?.webView
    }
    
    func addNewTab(url: URL? = nil) {
        let newWebView = WebViewModel.createConfiguredWebView(scripts: scriptManager.generateInjectionCode())
        let startURL = url ?? URL(string: "https://www.google.com")!
        newWebView.load(URLRequest(url: startURL))
        
        let newTab = TabItem(title: "تبويب جديد", url: startURL.absoluteString, webView: newWebView)
        tabs.append(newTab)
        currentTabID = newTab.id
        saveTabsState()
    }
    
    func closeTab(_ id: UUID) {
        guard tabs.count > 1 else { return }
        
        if let index = tabs.firstIndex(where: { $0.id == id }) {
            if currentTabID == id {
                let newIndex = index == 0 ? 1 : index - 1
                currentTabID = tabs[newIndex].id
            }
            tabs.remove(at: index)
            saveTabsState()
        }
    }
    
    func selectTab(_ id: UUID) {
        currentTabID = id
        updateStateFromCurrentTab()
        saveTabsState()
        applyDarkMode(to: currentWebView)
        clearConsole()
    }
    
    func updateStateFromCurrentTab() {
        guard let webView = currentWebView else { return }
        self.currentURL = webView.url?.absoluteString ?? ""
        self.canGoBack = webView.canGoBack
        self.canGoForward = webView.canGoForward
        self.isLoading = webView.isLoading
    }
    
    func goBack() { currentWebView?.goBack() }
    func goForward() { currentWebView?.goForward() }
    func reload() { currentWebView?.reload() }
    func loadUrl(url: URL) {
        currentWebView?.load(URLRequest(url: url))
        websitesManager?.saveLastURL(url.absoluteString)
    }
}

// MARK: - 4. واجهة المتصفح (WebView Wrapper)

struct WebViewContainer: UIViewRepresentable {
    @ObservedObject var viewModel: WebViewModel
    
    func makeCoordinator() -> Coordinator {
        Coordinator(viewModel: viewModel)
    }
    
    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        return view
    }
    
    func updateUIView(_ uiView: UIView, context: Context) {
        guard let currentTab = viewModel.tabs.first(where: { $0.id == viewModel.currentTabID }) else { return }
        let webView = currentTab.webView
        
        webView.configuration.userContentController.removeScriptMessageHandler(forName: "consoleObserver")
        webView.configuration.userContentController.add(context.coordinator, name: "consoleObserver")
        
        if webView.superview != uiView {
            uiView.subviews.forEach { $0.removeFromSuperview() }
            webView.frame = uiView.bounds
            webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            uiView.addSubview(webView)
            webView.navigationDelegate = context.coordinator
            webView.uiDelegate = context.coordinator
        }
    }
    
    class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        var viewModel: WebViewModel
        
        init(viewModel: WebViewModel) {
            self.viewModel = viewModel
        }
        
        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            if message.name == "consoleObserver",
               let body = message.body as? [String: Any],
               let type = body["type"] as? String,
               let msg = body["message"] as? String {
                viewModel.addConsoleLog(type: type, message: msg)
            }
        }
        
        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            updateViewModel(webView)
        }
        
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            updateViewModel(webView)
            if let index = viewModel.tabs.firstIndex(where: { $0.webView === webView }) {
                viewModel.tabs[index].title = webView.title ?? "موقع"
                viewModel.tabs[index].url = webView.url?.absoluteString ?? ""
                viewModel.saveTabsState()
                
                if let urlStr = webView.url?.absoluteString, let title = webView.title {
                    viewModel.historyManager.addToHistory(title: title, url: urlStr)
                }
            }
            
            viewModel.applyDarkMode(to: webView)
        }
        
        func updateViewModel(_ webView: WKWebView) {
            if webView === viewModel.currentWebView {
                DispatchQueue.main.async {
                    self.viewModel.isLoading = webView.isLoading
                    self.viewModel.canGoBack = webView.canGoBack
                    self.viewModel.canGoForward = webView.canGoForward
                    self.viewModel.currentURL = webView.url?.absoluteString ?? ""
                }
            }
        }
        
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else { return decisionHandler(.cancel) }
            
            if ["about", "blob", "data"].contains(url.scheme) { return decisionHandler(.allow) }
            
            if let host = url.host?.lowercased() {
                if SmartRules.allowedDomains.contains(where: { host.contains($0) }) {
                    return decisionHandler(.allow)
                }
                
                if SmartRules.domains.contains(where: { host.contains($0) }) {
                    print("🛑 Blocked: \(host)")
                    DispatchQueue.main.async { self.viewModel.adsBlocked += 1 }
                    return decisionHandler(.cancel)
                }
            }
            
            if navigationAction.targetFrame == nil {
                webView.load(navigationAction.request)
                return decisionHandler(.cancel)
            }
            
            decisionHandler(.allow)
        }
        
        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if navigationAction.targetFrame == nil {
                DispatchQueue.main.async {
                    if let url = navigationAction.request.url {
                        self.viewModel.addNewTab(url: url)
                    }
                }
            }
            return nil
        }
    }
}

// MARK: - 5. واجهات المستخدم (UI)

struct TabsTrayView: View {
    @ObservedObject var viewModel: WebViewModel
    @Binding var isVisible: Bool
    @State private var tabToFavorite: TabItem?
    
    var body: some View {
        VStack(spacing: 0) {
            Capsule()
                .fill(Color.gray.opacity(0.5))
                .frame(width: 40, height: 5)
                .padding(.top, 10)
                .padding(.bottom, 20)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 15) {
                    ForEach(viewModel.tabs) { tab in
                        TabCardView(tab: tab, isSelected: viewModel.currentTabID == tab.id, action: {
                            viewModel.selectTab(tab.id)
                            withAnimation(.spring()) { isVisible = false }
                        }, closeAction: {
                            withAnimation { viewModel.closeTab(tab.id) }
                        }, favoriteAction: {
                            self.tabToFavorite = tab
                        })
                    }
                    
                    Button(action: {
                        viewModel.addNewTab()
                        withAnimation(.spring()) { isVisible = false }
                    }) {
                        VStack {
                            Image(systemName: "plus")
                                .font(.system(size: 30))
                                .foregroundColor(.white.opacity(0.8))
                        }
                        .frame(width: 140, height: 180)
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(15)
                        .overlay(
                            RoundedRectangle(cornerRadius: 15)
                                .stroke(style: StrokeStyle(lineWidth: 2, dash: [5]))
                                .foregroundColor(.white.opacity(0.3))
                        )
                    }
                }
                .padding(.horizontal, 20)
            }
            .frame(height: 200)
            
            Spacer()
        }
        .background(.ultraThinMaterial)
        .cornerRadius(30, corners: [.bottomLeft, .bottomRight])
        .shadow(color: .black.opacity(0.3), radius: 20, x: 0, y: 10)
        .frame(height: 300)
        .sheet(item: $tabToFavorite) { tab in
            if let manager = viewModel.websitesManager {
                AddWebsiteView(websitesManager: manager, name: tab.title, url: tab.url)
            }
        }
    }
}

struct TabCardView: View {
    let tab: TabItem
    let isSelected: Bool
    let action: () -> Void
    let closeAction: () -> Void
    let favoriteAction: () -> Void
    
    var body: some View {
        ZStack(alignment: .topTrailing) {
            Button(action: action) {
                VStack(spacing: 10) {
                    KFImage(URL(string: "https://www.google.com/s2/favicons?domain=\(tab.url)&sz=128"))
                        .placeholder {
                            Circle().fill(Color.gray.opacity(0.3))
                        }
                        .resizable()
                        .frame(width: 40, height: 40)
                        .clipShape(Circle())
                        .shadow(radius: 5)
                    
                    Text(tab.title)
                        .font(.caption)
                        .bold()
                        .foregroundColor(isSelected ? .black : .white)
                        .lineLimit(2)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 5)
                }
                .frame(width: 140, height: 180)
                .background(isSelected ? Color.white : Color.black.opacity(0.3))
                .cornerRadius(15)
                .overlay(
                    RoundedRectangle(cornerRadius: 15)
                        .stroke(isSelected ? Color.blue : Color.white.opacity(0.2), lineWidth: 2)
                )
            }
            .contextMenu {
                Button(action: favoriteAction) {
                    Label("إضافة للمفضلة", systemImage: "star.fill")
                }
            }
            
            Button(action: closeAction) {
                Image(systemName: "xmark.circle.fill")
                    .foregroundColor(isSelected ? .gray : .white)
                    .padding(8)
            }
        }
        .scaleEffect(isSelected ? 1.05 : 1.0)
        .animation(.spring(), value: isSelected)
    }
}

// MARK: - NEW: واجهة سجل التاريخ (History UI)

struct HistorySectionHeader: View {
    let title: String
    var body: some View {
        Text(title)
            .font(.headline)
            .foregroundColor(.white)
            .padding(.horizontal)
            .padding(.vertical, 8)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.blue.opacity(0.2))
            .cornerRadius(8)
            .padding(.horizontal)
            .padding(.top)
    }
}

struct HistoryItemView: View {
    let item: HistoryItem
    let onTap: () -> Void
    let onDelete: () -> Void
    
    var body: some View {
        HStack(spacing: 15) {
            KFImage(URL(string: "https://www.google.com/s2/favicons?domain=\(item.url)&sz=64"))
                .placeholder {
                    Circle().fill(Color.gray.opacity(0.3))
                }
                .resizable()
                .frame(width: 40, height: 40)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.white.opacity(0.1), lineWidth: 1))
            
            VStack(alignment: .leading, spacing: 4) {
                Text(item.title)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white)
                    .lineLimit(1)
                
                Text(item.url)
                    .font(.system(size: 12))
                    .foregroundColor(.white.opacity(0.6))
                    .lineLimit(1)
            }
            
            Spacer()
            
            Button(action: onDelete) {
                Image(systemName: "trash")
                    .foregroundColor(.red.opacity(0.7))
                    .padding(8)
                    .background(Color.white.opacity(0.05))
                    .clipShape(Circle())
            }
        }
        .padding()
        .background(Color.white.opacity(0.08))
        .cornerRadius(12)
        .padding(.horizontal)
        .onTapGesture { onTap() }
    }
}

struct HistoryView: View {
    @ObservedObject var viewModel: WebViewModel
    @ObservedObject var historyManager: HistoryManager
    @Binding var isVisible: Bool
    
    var groupedHistory: [(String, [HistoryItem])] {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        let yesterday = calendar.date(byAdding: .day, value: -1, to: today)!
        let weekAgo = calendar.date(byAdding: .day, value: -7, to: today)!
        let monthAgo = calendar.date(byAdding: .month, value: -1, to: today)!
        
        var todayItems: [HistoryItem] = []
        var yesterdayItems: [HistoryItem] = []
        var weekItems: [HistoryItem] = []
        var monthItems: [HistoryItem] = []
        var olderItems: [HistoryItem] = []
        
        for item in historyManager.history {
            if item.date >= today { todayItems.append(item) }
            else if item.date >= yesterday { yesterdayItems.append(item) }
            else if item.date >= weekAgo { weekItems.append(item) }
            else if item.date >= monthAgo { monthItems.append(item) }
            else { olderItems.append(item) }
        }
        
        var sections: [(String, [HistoryItem])] = []
        if !todayItems.isEmpty { sections.append(("اليوم", todayItems)) }
        if !yesterdayItems.isEmpty { sections.append(("الأمس", yesterdayItems)) }
        if !weekItems.isEmpty { sections.append(("هذا الأسبوع", weekItems)) }
        if !monthItems.isEmpty { sections.append(("هذا الشهر", monthItems)) }
        if !olderItems.isEmpty { sections.append(("أقدم", olderItems)) }
        
        return sections
    }
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button(action: { withAnimation(.spring()) { isVisible = false } }) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 28))
                        .foregroundColor(.white.opacity(0.7))
                }
                Spacer()
                Text("سجل التاريخ")
                    .font(.title2)
                    .bold()
                    .foregroundColor(.white)
                Spacer()
                Button(action: { historyManager.clearAll() }) {
                    Image(systemName: "trash.circle.fill")
                        .font(.system(size: 28))
                        .foregroundColor(.red)
                }
            }
            .padding(20)
            .background(Color.black.opacity(0.4))
            
            if historyManager.history.isEmpty {
                VStack(spacing: 20) {
                    Image(systemName: "clock.arrow.circlepath")
                        .font(.system(size: 80))
                        .foregroundColor(.white.opacity(0.2))
                    Text("السجل فارغ تماماً")
                        .font(.title3)
                        .foregroundColor(.gray)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ScrollView {
                    LazyVStack(spacing: 0) {
                        ForEach(groupedHistory, id: \.0) { section in
                            HistorySectionHeader(title: section.0)
                            ForEach(section.1) { item in
                                HistoryItemView(item: item, onTap: {
                                    if let url = URL(string: item.url) {
                                        viewModel.loadUrl(url: url)
                                        withAnimation { isVisible = false }
                                    }
                                }, onDelete: {
                                    withAnimation { historyManager.deleteItem(item) }
                                })
                                .padding(.top, 8)
                            }
                        }
                    }
                    .padding(.bottom, 50)
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(
            LinearGradient(colors: [Color(hex: "0F2027"), Color(hex: "203A43"), Color(hex: "2C5364")], startPoint: .top, endPoint: .bottom)
        )
        .edgesIgnoringSafeArea(.all)
    }
}

// MARK: - NEW: واجهة الكونسول (Console UI)

struct ConsoleView: View {
    @ObservedObject var viewModel: WebViewModel
    @Binding var isVisible: Bool
    @State private var command: String = ""
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Console (DevTools)")
                    .font(.system(.subheadline, design: .monospaced))
                    .foregroundColor(.white)
                    .bold()
                Spacer()
                Button(action: { viewModel.clearConsole() }) {
                    Image(systemName: "trash")
                        .foregroundColor(.gray)
                }
                .padding(.trailing, 15)
                
                Button(action: { isVisible = false }) {
                    Image(systemName: "xmark")
                        .foregroundColor(.white)
                }
            }
            .padding(10)
            .background(Color(hex: "1a1a1a"))
            
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 2) {
                        ForEach(viewModel.consoleLogs) { log in
                            HStack(alignment: .top, spacing: 5) {
                                Text(log.timestamp, style: .time)
                                    .font(.system(size: 10, design: .monospaced))
                                    .foregroundColor(.gray)
                                    .frame(width: 50, alignment: .leading)
                                
                                Text(log.message)
                                    .font(.system(size: 12, design: .monospaced))
                                    .foregroundColor(colorForLog(log.type))
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(bgColorForLog(log.type))
                            .id(log.id)
                        }
                    }
                }
                .onChange(of: viewModel.consoleLogs) { _ in
                    if let last = viewModel.consoleLogs.last {
                        withAnimation { proxy.scrollTo(last.id, anchor: .bottom) }
                    }
                }
            }
            .background(Color.black)
            
            HStack {
                Text(">")
                    .foregroundColor(.blue)
                    .bold()
                TextField("Run JavaScript...", text: $command)
                    .foregroundColor(.white)
                    .font(.system(.body, design: .monospaced))
                    .onSubmit {
                        if !command.isEmpty {
                            viewModel.executeJS(command)
                            command = ""
                        }
                    }
                
                Button(action: {
                    if !command.isEmpty {
                        viewModel.executeJS(command)
                        command = ""
                    }
                }) {
                    Image(systemName: "play.fill")
                        .foregroundColor(.blue)
                }
            }
            .padding(8)
            .background(Color(hex: "1a1a1a"))
        }
        .frame(height: 350)
        .background(Color.black)
        .cornerRadius(12)
        .padding()
    }
    
    func colorForLog(_ type: String) -> Color {
        switch type {
        case "error": return .red
        case "warn": return .yellow
        case "info": return .blue
        default: return .white
        }
    }
    
    func bgColorForLog(_ type: String) -> Color {
        switch type {
        case "error": return Color.red.opacity(0.1)
        case "warn": return Color.yellow.opacity(0.1)
        default: return Color.clear
        }
    }
}

// MARK: - NEW: واجهة مدير السكربتات (Script Manager UI)

struct ScriptManagerView: View {
    @ObservedObject var scriptManager: ScriptManager
    @ObservedObject var viewModel: WebViewModel
    @Binding var isVisible: Bool
    @State private var showingEditor = false
    @State private var scriptToEdit: UserScript?
    
    var body: some View {
        // تم تغيير الواجهة لتكون صفحة كاملة داخل ZStack (Custom Full Screen)
        VStack(spacing: 0) {
            // Header
            HStack {
                Button(action: { isVisible = false }) {
                    Image(systemName: "xmark")
                        .foregroundColor(.white)
                        .font(.title2)
                }
                Spacer()
                Text("مدير السكربتات")
                    .font(.headline)
                    .foregroundColor(.white)
                Spacer()
                Button(action: {
                    scriptToEdit = nil
                    showingEditor = true
                }) {
                    Image(systemName: "plus")
                        .foregroundColor(.blue)
                        .font(.title2)
                }
            }
            .padding()
            .background(Color(hex: "1a1a1a"))
            
            // List
            if scriptManager.scripts.isEmpty {
                VStack {
                    Spacer()
                    Image(systemName: "curlybraces")
                        .font(.system(size: 60))
                        .foregroundColor(.gray)
                    Text("لا توجد سكربتات مضافة")
                        .foregroundColor(.gray)
                        .padding()
                    Spacer()
                }
                .frame(maxWidth: .infinity)
                .background(Color.black)
            } else {
                List {
                    ForEach(scriptManager.scripts) { script in
                        HStack {
                            VStack(alignment: .leading) {
                                Text(script.name)
                                    .font(.headline)
                                    .foregroundColor(.white)
                                Text(script.domain)
                                    .font(.caption)
                                    .foregroundColor(.gray)
                            }
                            Spacer()
                            
                            Toggle("", isOn: Binding(
                                get: { script.isActive },
                                set: { _ in
                                    scriptManager.toggleScript(script)
                                    viewModel.reload()
                                }
                            ))
                            .labelsHidden()
                            .toggleStyle(SwitchToggleStyle(tint: .blue))
                            
                            // زر التعديل
                            Button(action: {
                                scriptToEdit = script
                                showingEditor = true
                            }) {
                                Image(systemName: "pencil")
                                    .foregroundColor(.blue)
                            }
                            .buttonStyle(BorderlessButtonStyle())
                            .padding(.leading, 10)
                            
                            // زر الحذف (جديد)
                            Button(action: {
                                scriptManager.deleteScript(script)
                                viewModel.reload()
                            }) {
                                Image(systemName: "trash")
                                    .foregroundColor(.red)
                            }
                            .buttonStyle(BorderlessButtonStyle())
                            .padding(.leading, 10)
                        }
                        .listRowBackground(Color(hex: "2a2a2a"))
                    }
                }
                .listStyle(PlainListStyle())
                .background(Color.black)
            }
        }
        .background(Color.black)
        .fullScreenCover(isPresented: $showingEditor) {
            ScriptEditorView(
                script: scriptToEdit,
                onSave: { newScript in
                    scriptManager.addOrUpdateScript(newScript)
                    viewModel.reload()
                    showingEditor = false
                }
            )
        }
    }
}

struct ScriptEditorView: View {
    @State var script: UserScript?
    var onSave: (UserScript) -> Void
    @Environment(\.dismiss) var dismiss
    
    @State private var name: String = ""
    @State private var domain: String = "*"
    @State private var code: String = "// اكتب كود جافا سكربت هنا\nconsole.log('Hello');"
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("معلومات السكربت")) {
                    TextField("الاسم", text: $name)
                    TextField("النطاق (* للكل)", text: $domain)
                        .autocapitalization(.none)
                }
                
                Section(header: Text("الكود (JavaScript)")) {
                    TextEditor(text: $code)
                        .font(.system(.body, design: .monospaced))
                        .frame(height: 300)
                }
            }
            .navigationTitle(script == nil ? "سكربت جديد" : "تعديل سكربت")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("إلغاء") { dismiss() }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("حفظ") {
                        let newScript = UserScript(
                            id: script?.id ?? UUID(),
                            name: name,
                            domain: domain,
                            code: code,
                            isActive: script?.isActive ?? true
                        )
                        onSave(newScript)
                    }
                    .disabled(name.isEmpty || code.isEmpty)
                }
            }
            .onAppear {
                if let s = script {
                    name = s.name
                    domain = s.domain
                    code = s.code
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}

struct WebsitesBarView: View {
    @ObservedObject var websitesManager: WebsitesManager
    @ObservedObject var viewModel: WebViewModel
    @Binding var isVisible: Bool
    @State private var showAddSheet = false
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button(action: { withAnimation(.spring()) { isVisible = false } }) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 24))
                        .foregroundColor(.white.opacity(0.7))
                }
                Button(action: { showAddSheet = true }) {
                    Image(systemName: "plus.circle.fill")
                        .font(.system(size: 24))
                        .foregroundColor(.blue)
                }
                Spacer()
                VStack(alignment: .trailing) {
                    Text("مواقعي").font(.headline).foregroundColor(.white)
                    if viewModel.adsBlocked > 0 {
                        Text("تم حظر \(viewModel.adsBlocked) إعلان")
                            .font(.caption2).foregroundColor(.green)
                    }
                }
            }
            .padding(15)
            Divider().background(Color.white.opacity(0.1))
            
            if websitesManager.websites.isEmpty {
                VStack(spacing: 15) {
                    Image(systemName: "globe").font(.system(size: 50)).foregroundColor(.white.opacity(0.3))
                    Text("لا توجد مواقع").foregroundColor(.gray)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ScrollView {
                    VStack(spacing: 0) {
                        ForEach(websitesManager.websites) { website in
                            WebsiteRowView(website: website, viewModel: viewModel)
                                .onTapGesture {
                                    if let url = URL(string: website.url) {
                                        viewModel.loadUrl(url: url)
                                        withAnimation(.spring()) { isVisible = false }
                                    }
                                }
                                .contextMenu {
                                    Button(role: .destructive) { websitesManager.deleteWebsite(website) } label: {
                                        Label("حذف", systemImage: "trash")
                                    }
                                }
                        }
                    }
                    .padding(.top, 5)
                }
            }
        }
        .frame(width: 280)
        .background(Color(hex: "1a1a1a"))
        .edgesIgnoringSafeArea(.bottom)
        .sheet(isPresented: $showAddSheet) {
            AddWebsiteView(websitesManager: websitesManager)
        }
    }
}

struct WebsiteRowView: View {
    let website: Website
    @ObservedObject var viewModel: WebViewModel
    
    var isCurrentSite: Bool {
        viewModel.currentURL.contains(extractDomain(from: website.url))
    }
    
    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(LinearGradient(colors: [Color.blue.opacity(0.8), Color.purple.opacity(0.6)], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 45, height: 45)
                KFImage(URL(string: "https://www.google.com/s2/favicons?domain=\(website.url)&sz=128"))
                    .placeholder {
                        Text(String(website.name.prefix(1)).uppercased())
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                    }
                    .resizable()
                    .fade(duration: 0.25)
                    .cacheOriginalImage()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 28, height: 28)
                    .clipShape(Circle())
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(website.name).font(.system(size: 15, weight: .semibold)).foregroundColor(.white).lineLimit(1)
                Text(extractDomain(from: website.url)).font(.system(size: 12)).foregroundColor(.white.opacity(0.5)).lineLimit(1)
            }
            Spacer()
            if isCurrentSite {
                Circle().fill(Color.green).frame(width: 8, height: 8)
            }
        }
        .padding(.horizontal, 15)
        .padding(.vertical, 12)
        .background(isCurrentSite ? Color.white.opacity(0.1) : Color.clear)
        .cornerRadius(10)
        .padding(.horizontal, 10)
    }
    
    func extractDomain(from urlString: String) -> String {
        guard let url = URL(string: urlString), let host = url.host else { return urlString }
        return host.replacingOccurrences(of: "www.", with: "")
    }
}

struct AddWebsiteView: View {
    @ObservedObject var websitesManager: WebsitesManager
    @Environment(\.dismiss) var dismiss
    
    @State var name: String
    @State var url: String
    
    init(websitesManager: WebsitesManager, name: String = "", url: String = "") {
        self.websitesManager = websitesManager
        _name = State(initialValue: name)
        _url = State(initialValue: url)
    }
    
    var body: some View {
        NavigationView {
            Form {
                TextField("الاسم", text: $name)
                TextField("الرابط", text: $url).keyboardType(.URL)
                Button("إضافة") {
                    let finalUrl = url.lowercased().hasPrefix("http") ? url : "https://\(url)"
                    if !name.isEmpty, URL(string: finalUrl) != nil {
                        websitesManager.addWebsite(Website(name: name, url: finalUrl))
                        dismiss()
                    }
                }
                .disabled(name.isEmpty || url.isEmpty)
            }
            .navigationTitle("إضافة موقع")
        }
    }
}

// MARK: - 6. الواجهة الرئيسية

struct ContentView: View {
    @StateObject var viewModel = WebViewModel()
    @StateObject var websitesManager = WebsitesManager()
    @State private var isToolbarHidden = true
    @State private var showWebsitesBar = false
    @State private var showTabsTray = false
    
    // متغير جديد لعرض السجل
    @State private var showHistory = false
    // متغيرات الكونسول والسكربتات
    @State private var showConsole = false
    @State private var showScripts = false
    
    var body: some View {
        ZStack(alignment: .top) {
            
            // 1. المتصفح (في الخلفية)
            ZStack(alignment: .trailing) {
                VStack(spacing: 0) {
                    if viewModel.isLoading {
                        ProgressView().progressViewStyle(LinearProgressViewStyle(tint: .blue)).frame(height: 2)
                    }
                    WebViewContainer(viewModel: viewModel)
                }
                .edgesIgnoringSafeArea(.bottom)
                .onAppear { viewModel.websitesManager = websitesManager }
                
                // شريط المواقع الجانبي
                if showWebsitesBar {
                    Color.black.opacity(0.01)
                        .edgesIgnoringSafeArea(.all)
                        .onTapGesture {
                            withAnimation(.spring()) { showWebsitesBar = false }
                        }
                        .zIndex(5)
                    
                    WebsitesBarView(websitesManager: websitesManager, viewModel: viewModel, isVisible: $showWebsitesBar)
                        .transition(.move(edge: .trailing))
                        .frame(maxWidth: .infinity, alignment: .trailing)
                        .zIndex(6)
                }
                
                // 🔥 واجهة السجل (History)
                if showHistory {
                    HistoryView(viewModel: viewModel, historyManager: viewModel.historyManager, isVisible: $showHistory)
                        .transition(.opacity)
                        .zIndex(20)
                }
                
                // 🔥 واجهة الكونسول (Console)
                if showConsole {
                    VStack {
                        Spacer()
                        ConsoleView(viewModel: viewModel, isVisible: $showConsole)
                    }
                    .transition(.move(edge: .bottom))
                    .zIndex(25)
                }
                
                // 🔥 واجهة مدير السكربتات (صفحة كاملة الآن)
                if showScripts {
                    ScriptManagerView(scriptManager: viewModel.scriptManager, viewModel: viewModel, isVisible: $showScripts)
                        .transition(.move(edge: .bottom))
                        .zIndex(30)
                }
                
                // شريط الأدوات السفلي العائم (Toolbar)
                VStack(spacing: 20) {
                    Button(action: {
                        withAnimation(.spring()) {
                            showWebsitesBar.toggle()
                            if showWebsitesBar { isToolbarHidden = true }
                        }
                    }) {
                        ZStack {
                            Image(systemName: "globe").font(.title3).foregroundColor(showWebsitesBar ? .blue : .primary)
                            if viewModel.adsBlocked > 0 {
                                Circle().fill(Color.red).frame(width: 8, height: 8).offset(x: 10, y: -10)
                            }
                        }
                    }
                    
                    // زر السجل
                    Button(action: {
                        withAnimation(.spring()) {
                            showHistory = true
                            isToolbarHidden = true
                        }
                    }) {
                        Image(systemName: "clock.arrow.circlepath")
                            .font(.title3)
                            .foregroundColor(.primary)
                    }
                    
                    // 🔥 زر الكونسول
                    Button(action: {
                        withAnimation(.spring()) {
                            showConsole.toggle()
                            isToolbarHidden = true
                        }
                    }) {
                        Image(systemName: "terminal")
                            .font(.title3)
                            .foregroundColor(.orange)
                    }
                    
                    // 🔥 زر السكربتات
                    Button(action: {
                        withAnimation(.spring()) {
                            showScripts = true
                            isToolbarHidden = true
                        }
                    }) {
                        Image(systemName: "curlybraces")
                            .font(.title3)
                            .foregroundColor(.green)
                    }
                    
                    Divider().frame(width: 30).background(Color.gray.opacity(0.3))
                    
                    Button(action: { viewModel.toggleForcedDarkMode() }) {
                        Image(systemName: "moon.stars.fill")
                            .font(.headline)
                            .foregroundColor(viewModel.isForcedDarkMode ? .yellow : .primary)
                    }
                    
                    Button(action: { viewModel.reload() }) { Image(systemName: "arrow.clockwise").font(.headline) }
                    Button(action: { viewModel.addNewTab() }) { Image(systemName: "plus").font(.title3).foregroundColor(.blue) }
                    Button(action: { viewModel.goBack() }) { Image(systemName: "chevron.backward").font(.headline) }.disabled(!viewModel.canGoBack)
                    Button(action: { viewModel.goForward() }) { Image(systemName: "chevron.forward").font(.headline) }.disabled(!viewModel.canGoForward)
                }
                .padding(15)
                .background(.ultraThinMaterial)
                .cornerRadius(20, corners: [.topLeft, .bottomLeft])
                .shadow(radius: 5)
                .offset(x: isToolbarHidden ? 80 : 0)
                .gesture(DragGesture().onChanged { if $0.translation.width > 5 { withAnimation { isToolbarHidden = true } } })
                .zIndex(4)
                
                if isToolbarHidden {
                    Color.clear.frame(width: 25).contentShape(Rectangle())
                        .gesture(DragGesture().onChanged { if $0.translation.width < -10 { withAnimation { isToolbarHidden = false } } })
                        .zIndex(10)
                }
            }
            
            // 2. منطقة استشعار السحب العلوية
            if !showTabsTray {
                Color.clear
                    .frame(height: 30)
                    .contentShape(Rectangle())
                    .ignoresSafeArea()
                    .zIndex(20)
                    .gesture(
                        DragGesture(minimumDistance: 20, coordinateSpace: .global)
                            .onEnded { value in
                                if value.translation.height > 50 && value.startLocation.y < 100 {
                                    withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                                        showTabsTray = true
                                    }
                                }
                            }
                    )
            }
            
            // 3. شريط التبويبات
            if showTabsTray {
                ZStack(alignment: .top) {
                    Color.black.opacity(0.3)
                        .ignoresSafeArea()
                        .onTapGesture {
                            withAnimation { showTabsTray = false }
                        }
                    
                    TabsTrayView(viewModel: viewModel, isVisible: $showTabsTray)
                        .transition(.move(edge: .top))
                }
                .zIndex(30)
            }
        }
    }
}

// Helpers
extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}

extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default: (a, r, g, b) = (1, 1, 1, 0)
        }
        self.init(.sRGB, red: Double(r) / 255, green: Double(g) / 255, blue: Double(b) / 255, opacity: Double(a) / 255)
    }
}
