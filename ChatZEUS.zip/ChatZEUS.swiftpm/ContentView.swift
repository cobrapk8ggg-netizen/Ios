import SwiftUI
import WebKit

// 1. هيكل المتصفح الرئيسي
struct MainWebView: UIViewRepresentable {
    let url: URL
    @Binding var showPopup: Bool
    @Binding var popupURL: URL?
    
    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
    
    func makeUIView(context: Context) -> WKWebView {
        // تفعيل الجافا سكريبت والكوكيز
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        let config = WKWebViewConfiguration()
        config.defaultWebpagePreferences = prefs
        
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator // ضروري للنوافذ المنبثقة
        webView.allowsBackForwardNavigationGestures = true
        
        // استخدام User Agent ليظهر كمتصفح طبيعي
        webView.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1"
        
        // تحميل الرابط
        webView.load(URLRequest(url: url))
        return webView
    }
    
    func updateUIView(_ webView: WKWebView, context: Context) {
        // لا نحتاج لتحديث هنا
    }
    
    class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        var parent: MainWebView
        
        init(parent: MainWebView) {
            self.parent = parent
        }
        
        // هذه الدالة تكتشف عندما يطلب الموقع فتح نافذة جديدة (مثل جوجل)
        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if let url = navigationAction.request.url {
                // نخبر التطبيق بفتح النافذة المنبثقة
                parent.popupURL = url
                parent.showPopup = true
            }
            return nil
        }
    }
}

// 2. هيكل متصفح النافذة المنبثقة (لتسجيل الدخول)
struct PopupWebView: UIViewRepresentable {
    let url: URL
    @Binding var showPopup: Bool
    
    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
    
    func makeUIView(context: Context) -> WKWebView {
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        let config = WKWebViewConfiguration()
        config.defaultWebpagePreferences = prefs
        
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1"
        
        webView.load(URLRequest(url: url))
        return webView
    }
    
    func updateUIView(_ webView: WKWebView, context: Context) {}
    
    class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        var parent: PopupWebView
        
        init(parent: PopupWebView) {
            self.parent = parent
        }
        
        // إغلاق النافذة عند الانتهاء (window.close)
        func webViewDidClose(_ webView: WKWebView) {
            parent.showPopup = false
        }
        
        // مراقبة الرابط، إذا عادت جوجل إلى موقعنا، نغلق النافذة
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if let urlStr = navigationAction.request.url?.absoluteString {
                // إذا رأينا أن الرابط عاد إلى موقعك الأصلي، فهذا يعني نجاح الدخول
                // يمكنك تغيير "zeus-2-pi" بجزء من رابط موقعك بعد الدخول
                if urlStr.contains("zeus-2-pi") && !urlStr.contains("accounts.google") {
                    // ننتظر ثانية ثم نغلق لضمان حفظ الكوكيز
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                        self.parent.showPopup = false
                    }
                }
            }
            decisionHandler(.allow)
        }
    }
}

// 3. الواجهة الرئيسية التي تجمع كل شيء
struct ContentView: View {
    @State private var showPopup = false
    @State private var popupURL: URL?
    // رابط موقعك الرئيسي
    let mainURL = URL(string: "https://zeustran.vercel.app/")!
    
    var body: some View {
        MainWebView(url: mainURL, showPopup: $showPopup, popupURL: $popupURL)
            .edgesIgnoringSafeArea(.bottom)
        // هنا يظهر المربع المنبثق عند الحاجة
            .sheet(isPresented: $showPopup) {
                if let url = popupURL {
                    PopupWebView(url: url, showPopup: $showPopup)
                } else {
                    Text("جاري التحميل...")
                }
            }
    }
}
