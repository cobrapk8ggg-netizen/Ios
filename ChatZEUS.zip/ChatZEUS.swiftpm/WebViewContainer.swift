
import SwiftUI
import WebKit

// MARK: - 4. واجهة المتصفح (WebView Wrapper)

struct WebViewContainer: UIViewRepresentable {
    @ObservedObject var viewModel: WebViewModel
    
    func makeCoordinator() -> Coordinator {
        Coordinator(viewModel: viewModel)
    }
    
    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        return view
    }
    
    func updateUIView(_ uiView: UIView, context: Context) {
        guard let currentTab = viewModel.tabs.first(where: { $0.id == viewModel.currentTabID }) else { return }
        let webView = currentTab.webView
        
        // إزالة القديم وإضافة المراقبين الجدد
        webView.configuration.userContentController.removeScriptMessageHandler(forName: "consoleObserver")
        webView.configuration.userContentController.removeScriptMessageHandler(forName: "readerObserver")
        webView.configuration.userContentController.removeScriptMessageHandler(forName: "galleryObserver")
        
        webView.configuration.userContentController.add(context.coordinator, name: "consoleObserver")
        webView.configuration.userContentController.add(context.coordinator, name: "readerObserver")
        webView.configuration.userContentController.add(context.coordinator, name: "galleryObserver")
        
        if webView.superview != uiView {
            uiView.subviews.forEach { $0.removeFromSuperview() }
            webView.frame = uiView.bounds
            webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            uiView.addSubview(webView)
            webView.navigationDelegate = context.coordinator
            webView.uiDelegate = context.coordinator
        }
    }
    
    class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        var viewModel: WebViewModel
        
        init(viewModel: WebViewModel) {
            self.viewModel = viewModel
        }
        
        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            if message.name == "consoleObserver",
               let body = message.body as? [String: Any],
               let type = body["type"] as? String,
               let msg = body["message"] as? String {
                viewModel.addConsoleLog(type: type, message: msg)
            }
            // استقبال بيانات القارئ
            else if message.name == "readerObserver",
                    let body = message.body as? [String: Any],
                    let title = body["title"] as? String,
                    let content = body["content"] as? [String] {
                DispatchQueue.main.async {
                    self.viewModel.readerContent = ReaderContent(title: title, content: content)
                    self.viewModel.showReader = true
                }
            }
            // استقبال صور المعرض
            else if message.name == "galleryObserver",
                    let body = message.body as? [String: Any],
                    let images = body["images"] as? [String] {
                DispatchQueue.main.async {
                    self.viewModel.galleryImages = images
                    self.viewModel.showGallery = true
                }
            }
        }
        
        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            updateViewModel(webView)
        }
        
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            updateViewModel(webView)
            if let index = viewModel.tabs.firstIndex(where: { $0.webView === webView }) {
                viewModel.tabs[index].title = webView.title ?? "موقع"
                viewModel.tabs[index].url = webView.url?.absoluteString ?? ""
                viewModel.saveTabsState()
                
                if let urlStr = webView.url?.absoluteString, let title = webView.title {
                    viewModel.historyManager.addToHistory(title: title, url: urlStr)
                }
            }
            
            viewModel.applyDarkMode(to: webView)
        }
        
        func updateViewModel(_ webView: WKWebView) {
            if webView === viewModel.currentWebView {
                DispatchQueue.main.async {
                    self.viewModel.isLoading = webView.isLoading
                    self.viewModel.canGoBack = webView.canGoBack
                    self.viewModel.canGoForward = webView.canGoForward
                    self.viewModel.currentURL = webView.url?.absoluteString ?? ""
                }
            }
        }
        
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else { return decisionHandler(.cancel) }
            
            if ["about", "blob", "data"].contains(url.scheme) { return decisionHandler(.allow) }
            
            if let host = url.host?.lowercased() {
                if SmartRules.allowedDomains.contains(where: { host.contains($0) }) {
                    return decisionHandler(.allow)
                }
                
                if SmartRules.domains.contains(where: { host.contains($0) }) {
                    print("🛑 Blocked: \(host)")
                    DispatchQueue.main.async { self.viewModel.adsBlocked += 1 }
                    return decisionHandler(.cancel)
                }
            }
            
            if navigationAction.targetFrame == nil {
                webView.load(navigationAction.request)
                return decisionHandler(.cancel)
            }
            
            decisionHandler(.allow)
        }
        
        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if navigationAction.targetFrame == nil {
                DispatchQueue.main.async {
                    if let url = navigationAction.request.url {
                        self.viewModel.addNewTab(url: url)
                    }
                }
            }
            return nil
        }
    }
}
