import SwiftUI
import WebKit
import AppTrackingTransparency
import AdSupport

// MARK: - 4. واجهة المتصفح (WebView Wrapper)

struct WebViewContainer: UIViewRepresentable {
    @ObservedObject var viewModel: WebViewModel
    
    func makeCoordinator() -> Coordinator {
        Coordinator(viewModel: viewModel)
    }
    
    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        
        // طلب إذن التتبع عند فتح الواجهة
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            context.coordinator.requestTrackingPermission()
        }
        
        return view
    }
    
    func updateUIView(_ uiView: UIView, context: Context) {
        guard let currentTab = viewModel.tabs.first(where: { $0.id == viewModel.currentTabID }) else { return }
        let webView = currentTab.webView
        
        // --- إعدادات متقدمة لحل مشكلة ملفات تعريف الارتباط (Cookies) لـ Firebase ---
        let config = webView.configuration
        
        // 1. استخدام مخزن بيانات افتراضي يدعم الجلسات المستمرة
        config.websiteDataStore = WKWebsiteDataStore.default()
        
        // 2. تفعيل مشاركة العمليات لضمان انتقال الكوكيز بين النطاقات الفرعية
        config.processPool = WKProcessPool()
        
        // 3. السماح لـ JavaScript بفتح النوافذ وتخزين البيانات
        config.preferences.javaScriptEnabled = true
        config.preferences.javaScriptCanOpenWindowsAutomatically = true
        
        // 4. إعدادات webpage preferences للسماح بـ JavaScript
        if #available(iOS 14.0, *) {
            let preferences = WKWebpagePreferences()
            preferences.allowsContentJavaScript = true
            config.defaultWebpagePreferences = preferences
        }
        
        // 5. إعدادات الخصوصية لملفات الارتباط (على مستوى التطبيق العام)
        HTTPCookieStorage.shared.cookieAcceptPolicy = .always
        
        // 6. مزامنة الـ cookies بين HTTPCookieStorage و WKWebView
        context.coordinator.syncCookiesToWebView(webView: webView)
        // -------------------------------------------------------
        
        // إزالة القديم وإضافة المراقبين الجدد
        webView.configuration.userContentController.removeScriptMessageHandler(forName: "consoleObserver")
        webView.configuration.userContentController.removeScriptMessageHandler(forName: "readerObserver")
        webView.configuration.userContentController.removeScriptMessageHandler(forName: "galleryObserver")
        
        webView.configuration.userContentController.add(context.coordinator, name: "consoleObserver")
        webView.configuration.userContentController.add(context.coordinator, name: "readerObserver")
        webView.configuration.userContentController.add(context.coordinator, name: "galleryObserver")
        
        if webView.superview != uiView {
            uiView.subviews.forEach { $0.removeFromSuperview() }
            webView.frame = uiView.bounds
            webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            uiView.addSubview(webView)
            webView.navigationDelegate = context.coordinator
            webView.uiDelegate = context.coordinator
            
            webView.allowsLinkPreview = true
        }
    }
    
    class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler, UIDocumentPickerDelegate, WKDownloadDelegate {
        var viewModel: WebViewModel
        
        init(viewModel: WebViewModel) {
            self.viewModel = viewModel
        }
        
        func requestTrackingPermission() {
            ATTrackingManager.requestTrackingAuthorization { status in
                switch status {
                case .authorized:
                    print("Tracking Authorized")
                case .denied:
                    print("Tracking Denied")
                case .notDetermined:
                    print("Tracking Not Determined")
                case .restricted:
                    print("Tracking Restricted")
                @unknown default:
                    break
                }
            }
        }
        
        // دالة جديدة لمزامنة الـ cookies
        func syncCookiesToWebView(webView: WKWebView) {
            let cookieStore = webView.configuration.websiteDataStore.httpCookieStore
            
            // نقل جميع الـ cookies من HTTPCookieStorage إلى WKWebView
            if let cookies = HTTPCookieStorage.shared.cookies {
                for cookie in cookies {
                    cookieStore.setCookie(cookie)
                }
            }
            
            // حقن JavaScript لقبول جميع الـ cookies
            let cookieScript = """
            (function() {
                // السماح لجميع الـ cookies بما فيها third-party
                document.cookie.split(';').forEach(function(c) {
                    document.cookie = c.trim() + '; SameSite=None; Secure';
                });
                
                // تفعيل localStorage و sessionStorage
                try {
                    localStorage.setItem('test', 'test');
                    localStorage.removeItem('test');
                } catch(e) {
                    console.log('LocalStorage not available');
                }
            })();
            """
            
            let cookieScriptObject = WKUserScript(
                source: cookieScript,
                injectionTime: .atDocumentStart,
                forMainFrameOnly: false
            )
            
            webView.configuration.userContentController.addUserScript(cookieScriptObject)
        }
        
        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            if message.name == "consoleObserver",
               let body = message.body as? [String: Any],
               let type = body["type"] as? String,
               let msg = body["message"] as? String {
                viewModel.addConsoleLog(type: type, message: msg)
            }
            else if message.name == "readerObserver",
                    let body = message.body as? [String: Any],
                    let title = body["title"] as? String,
                    let content = body["content"] as? [String] {
                DispatchQueue.main.async {
                    self.viewModel.readerContent = ReaderContent(title: title, content: content)
                    self.viewModel.showReader = true
                }
            }
            else if message.name == "galleryObserver",
                    let body = message.body as? [String: Any],
                    let images = body["images"] as? [String] {
                DispatchQueue.main.async {
                    self.viewModel.galleryImages = images
                    self.viewModel.showGallery = true
                }
            }
        }
        
        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            updateViewModel(webView)
        }
        
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            updateViewModel(webView)
            if let index = viewModel.tabs.firstIndex(where: { $0.webView === webView }) {
                viewModel.tabs[index].title = webView.title ?? "موقع"
                viewModel.tabs[index].url = webView.url?.absoluteString ?? ""
                viewModel.saveTabsState()
                
                if let urlStr = webView.url?.absoluteString, let title = webView.title {
                    viewModel.historyManager.addToHistory(title: title, url: urlStr)
                }
            }
            viewModel.applyDarkMode(to: webView)
            
            // مزامنة الـ cookies بعد تحميل الصفحة
            syncCookiesFromWebView(webView: webView)
        }
        
        // دالة جديدة لمزامنة الـ cookies من WKWebView إلى HTTPCookieStorage
        func syncCookiesFromWebView(webView: WKWebView) {
            let cookieStore = webView.configuration.websiteDataStore.httpCookieStore
            
            cookieStore.getAllCookies { cookies in
                for cookie in cookies {
                    HTTPCookieStorage.shared.setCookie(cookie)
                }
            }
        }
        
        func updateViewModel(_ webView: WKWebView) {
            if webView === viewModel.currentWebView {
                DispatchQueue.main.async {
                    self.viewModel.isLoading = webView.isLoading
                    self.viewModel.canGoBack = webView.canGoBack
                    self.viewModel.canGoForward = webView.canGoForward
                    self.viewModel.currentURL = webView.url?.absoluteString ?? ""
                }
            }
        }
        
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else { return decisionHandler(.cancel) }
            
            if navigationAction.shouldPerformDownload {
                decisionHandler(.download)
                return
            }
            
            let fileExtensions: Set<String> = ["zip", "pdf", "dmg", "pkg", "rar", "gz", "exe", "png", "jpg", "jpeg", "mp4"]
            let pathExtension = url.pathExtension.lowercased()
            
            if fileExtensions.contains(pathExtension) {
                startDownload(from: url)
                decisionHandler(.cancel)
                return
            }
            
            if ["about", "blob", "data"].contains(url.scheme) { return decisionHandler(.allow) }
            
            if let host = url.host?.lowercased() {
                if SmartRules.allowedDomains.contains(where: { host.contains($0) }) {
                    return decisionHandler(.allow)
                }
                if SmartRules.domains.contains(where: { host.contains($0) }) {
                    DispatchQueue.main.async { self.viewModel.adsBlocked += 1 }
                    return decisionHandler(.cancel)
                }
            }
            
            if navigationAction.targetFrame == nil {
                webView.load(navigationAction.request)
                return decisionHandler(.cancel)
            }
            
            decisionHandler(.allow)
        }
        
        func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {
            download.delegate = self
        }
        
        func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
            let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let destinationURL = documentsURL.appendingPathComponent(suggestedFilename)
            if FileManager.default.fileExists(atPath: destinationURL.path) {
                try? FileManager.default.removeItem(at: destinationURL)
            }
            completionHandler(destinationURL)
        }
        
        func downloadDidFinish(_ download: WKDownload) {
            if let destinationURL = download.progress.fileURL {
                DispatchQueue.main.async {
                    let picker = UIDocumentPickerViewController(forExporting: [destinationURL], asCopy: true)
                    picker.delegate = self
                    picker.overrideUserInterfaceStyle = .dark
                    self.present(picker)
                }
            }
        }
        
        func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
            let alert = createStyledAlert(title: "تنبيه", message: message)
            alert.addAction(UIAlertAction(title: "تم", style: .default) { _ in completionHandler() })
            present(alert)
        }
        
        func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
            let alert = createStyledAlert(title: "تأكيد العملية", message: message)
            alert.addAction(UIAlertAction(title: "إلغاء", style: .cancel) { _ in completionHandler(false) })
            alert.addAction(UIAlertAction(title: "موافق", style: .default) { _ in completionHandler(true) })
            present(alert)
        }
        
        func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
            let alert = createStyledAlert(title: "إدخال بيانات", message: prompt)
            alert.addTextField { textField in
                textField.text = defaultText
                textField.keyboardAppearance = .dark
                textField.textColor = .white
            }
            alert.addAction(UIAlertAction(title: "إلغاء", style: .cancel) { _ in completionHandler(nil) })
            alert.addAction(UIAlertAction(title: "إرسال", style: .default) { _ in
                completionHandler(alert.textFields?.first?.text)
            })
            present(alert)
        }
        
        private func createStyledAlert(title: String?, message: String?) -> UIAlertController {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.overrideUserInterfaceStyle = .dark
            alert.view.tintColor = .white
            return alert
        }
        
        private func present(_ viewController: UIViewController) {
            DispatchQueue.main.async {
                if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                   let rootVC = windowScene.windows.first?.rootViewController {
                    var topController = rootVC
                    while let presented = topController.presentedViewController {
                        topController = presented
                    }
                    topController.present(viewController, animated: true)
                }
            }
        }
        
        func startDownload(from url: URL) {
            let task = URLSession.shared.downloadTask(with: url) { localURL, response, error in
                guard let localURL = localURL, error == nil else { return }
                let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                let destinationURL = documentsURL.appendingPathComponent(url.lastPathComponent)
                do {
                    if FileManager.default.fileExists(atPath: destinationURL.path) {
                        try? FileManager.default.removeItem(at: destinationURL)
                    }
                    try FileManager.default.moveItem(at: localURL, to: destinationURL)
                    DispatchQueue.main.async {
                        let picker = UIDocumentPickerViewController(forExporting: [destinationURL], asCopy: true)
                        picker.delegate = self
                        picker.overrideUserInterfaceStyle = .dark
                        self.present(picker)
                    }
                } catch { print("Download Error: \(error)") }
            }
            task.resume()
        }
        
        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if navigationAction.targetFrame == nil {
                DispatchQueue.main.async {
                    if let url = navigationAction.request.url {
                        self.viewModel.addNewTab(url: url)
                    }
                }
            }
            return nil
        }
        
        func webView(_ webView: WKWebView, contextMenuConfigurationForElement elementInfo: WKContextMenuElementInfo, completionHandler: @escaping (UIContextMenuConfiguration?) -> Void) {
            guard let url = elementInfo.linkURL else {
                completionHandler(nil)
                return
            }
            let previewProvider: UIContextMenuContentPreviewProvider = {
                let previewVC = UIViewController()
                let miniWebView = WKWebView(frame: .zero)
                miniWebView.load(URLRequest(url: url))
                previewVC.view = miniWebView
                previewVC.preferredContentSize = CGSize(width: 0, height: 400)
                return previewVC
            }
            let configuration = UIContextMenuConfiguration(identifier: url as NSURL, previewProvider: previewProvider) { _ in
                let openInCurrent = UIAction(title: "فتح في النافذة الحالية", image: UIImage(systemName: "link")) { _ in
                    webView.load(URLRequest(url: url))
                }
                let openInNewTab = UIAction(title: "فتح في نافذة جديدة", image: UIImage(systemName: "plus.square.on.square")) { _ in
                    DispatchQueue.main.async { self.viewModel.addNewTab(url: url) }
                }
                let copyLink = UIAction(title: "نسخ الرابط", image: UIImage(systemName: "doc.on.doc")) { _ in
                    UIPasteboard.general.url = url
                }
                return UIMenu(title: url.absoluteString, children: [openInCurrent, openInNewTab, copyLink])
            }
            completionHandler(configuration)
        }
        
        func webView(_ webView: WKWebView, contextMenuForElement elementInfo: WKContextMenuElementInfo, willCommitWithAnimator animator: UIContextMenuInteractionCommitAnimating) {
            animator.addCompletion {
                if let url = elementInfo.linkURL {
                    webView.load(URLRequest(url: url))
                }
            }
        }
    }
}
