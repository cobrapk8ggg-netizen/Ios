import Foundation
import WebKit

// MARK: - 1. المحرك الذكي لحظر الإعلانات (The Smart Engine)

struct SmartRules {
    static let domains: Set<String> = [
        "doubleclick.net", "googleadservices.com", "googlesyndication.com",
        "google-analytics.com", "googletagmanager.com", "facebook.net",
        "scorecardresearch.com", "adnxs.com", "advertising.com",
        "adsystem.com", "admob.com", "inmobi.com", "mopub.com",
        "applovin.com", "unity3d.com", "chartbeat.com", "taboola.com",
        "outbrain.com", "popads.net", "popcash.net", "propellerads.com",
        "adcash.com", "exoclick.com", "clickadu.com", "hilltopads.net",
        "juicyads.com", "trafficjunky.com", "mgid.com", "revcontent.com",
        "criteo.com", "serving-sys.com", "spotxchange.com", "adsrvr.org",
        "pubmatic.com", "rubiconproject.com", "openx.net", "bidswitch.net",
        "casalemedia.com", "lijit.com", "sovrn.com", "ads.twitter.com",
        "amazon-adsystem.com", "smartadserver.com", "truste.com"
    ]
    
    static let allowedDomains: Set<String> = [
        "google.com", "accounts.google.com", "googleapis.com",
        "gstatic.com", "googleusercontent.com", "youtube.com",
        "cloudflare.com", "challenges.cloudflare.com", "turnstile.cloudflare.com",
        "recaptcha.net"
    ]
    
    static let cssSelectors: [String] = [
        ".ad", ".ads", ".advertisement", ".banner", "#ad", "#ads",
        "[id^='google_ads']", "[class*='adsbygoogle']",
        "[class*='popup']", "[id*='popup']", ".modal-overlay",
        "#onetrust-banner-sdk", ".cookie-banner", "#cookie-notice",
        ".fc-ab-root", "iframe[src*='doubleclick']", "iframe[src*='ads']"
    ]
}

class AdBlockManager {
    static let shared = AdBlockManager()
    
    func createContentBlockerRules() -> String {
        var rules: [[String: Any]] = []
        
        for domain in SmartRules.domains {
            rules.append([
                "trigger": [
                    "url-filter": ".*\(domain).*",
                    "resource-type": ["script", "image", "raw", "document", "popup", "style-sheet"]
                ],
                "action": [ "type": "block" ]
            ])
        }
        
        for domain in SmartRules.allowedDomains {
            rules.append([
                "trigger": [
                    "url-filter": ".*\(domain).*"
                ],
                "action": [
                    "type": "ignore-previous-rules"
                ]
            ])
        }
        
        for selector in SmartRules.cssSelectors {
            rules.append([
                "trigger": [ "url-filter": ".*" ],
                "action": [
                    "type": "css-display-none",
                    "selector": selector
                ]
            ])
        }
        
        rules.append([
            "trigger": [
                "url-filter": ".*(ad|ads|preroll|midroll).*mp4",
                "resource-type": ["media"]
            ],
            "action": [ "type": "block" ]
        ])
        
        if let jsonData = try? JSONSerialization.data(withJSONObject: rules, options: []),
           let jsonString = String(data: jsonData, encoding: .utf8) {
            return jsonString
        }
        return "[]"
    }
    
    func getSmartInjectionScript() -> String {
        return """
        (function() {
            console.log('🛡️ Smart AdBlock Engine v3.0');
            
            var whitelist = ['google.com', 'cloudflare.com', 'accounts.google.com', 'recaptcha.net'];
            if (whitelist.some(domain => window.location.hostname.includes(domain))) {
                return;
            }
        
            window.open = function() { console.log('🚫 Pop-up Killed'); return null; };
            Object.defineProperty(window, 'google_ad_status', { get: function() { return 1; } });
            window.canRunAds = true;
            window.isAdBlockActive = false;
            
            function cleanPage() {
                document.querySelectorAll('iframe').forEach(el => {
                    if (el.src.includes('ads') || el.src.includes('google') || el.offsetWidth < 10) {
                        el.remove();
                    }
                });
                document.querySelectorAll('div[style*="position: fixed"]').forEach(el => {
                    if (el.style.zIndex > 900 && el.innerHTML.length < 300) {
                        el.remove();
                    }
                });
                document.querySelectorAll('[class*="float"]').forEach(el => el.remove());
            }
            
            var observer = new MutationObserver(function(mutations) { cleanPage(); });
            observer.observe(document, { childList: true, subtree: true });
            document.addEventListener('DOMContentLoaded', cleanPage);
            setInterval(cleanPage, 3000);
        })();
        """
    }
    
    func getConsoleBridgeScript() -> String {
        return """
        (function() {
            var oldLog = console.log;
            var oldWarn = console.warn;
            var oldError = console.error;
            var oldInfo = console.info;
        
            function sendToSwift(type, args) {
                try {
                    var message = Array.from(args).map(arg => {
                        if (typeof arg === 'object') return JSON.stringify(arg);
                        return String(arg);
                    }).join(' ');
                    
                    window.webkit.messageHandlers.consoleObserver.postMessage({
                        type: type,
                        message: message
                    });
                } catch(e) {}
            }
        
            console.log = function() { sendToSwift('log', arguments); oldLog.apply(console, arguments); };
            console.warn = function() { sendToSwift('warn', arguments); oldWarn.apply(console, arguments); };
            console.error = function() { sendToSwift('error', arguments); oldError.apply(console, arguments); };
            console.info = function() { sendToSwift('info', arguments); oldInfo.apply(console, arguments); };
            
            window.onerror = function(message, source, lineno, colno, error) {
                sendToSwift('error', ['Global Error: ' + message + ' (' + lineno + ')']);
            };
        })();
        """
    }
}
