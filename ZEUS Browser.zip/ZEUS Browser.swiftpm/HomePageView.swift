import SwiftUI
import Kingfisher

struct HomePageView: View {
    @ObservedObject var viewModel: WebViewModel
    @ObservedObject var websitesManager: WebsitesManager
    
    @State private var searchText: String = ""
    @State private var showHistoryDropdown: Bool = false
    @State private var opacity: Double = 0
    @State private var showAddSheet: Bool = false
    
    let columns = [
        GridItem(.flexible(), spacing: 15),
        GridItem(.flexible(), spacing: 15),
        GridItem(.flexible(), spacing: 15),
        GridItem(.flexible(), spacing: 15)
    ]
    
    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 0) {
                Spacer().frame(height: 50)
                
                // 1. Logo Area
                VStack(spacing: 15) {
                    // MARK: - تعديل حجم الشعار من هنا
                    // غير الأرقام 120 (العرض والطول) للتحكم في حجم الصورة
                    Image("ZEUS") 
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 135, height: 135) // <--- الحجم الحالي 120x120
                        .padding(.bottom, 5)
                    
                    Text("ZEUS Browser")
                        .font(.system(size: 28, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .tracking(2)
                }
                .padding(.bottom, 40)
                .opacity(opacity)
                
                // 2. Search Bar Area
                ZStack(alignment: .top) {
                    VStack(spacing: 0) {
                        // Search Input Field
                        HStack(spacing: 12) {
                            Button(action: {
                                searchText = ""
                            }) {
                                Image(systemName: "xmark.circle.fill")
                                    .foregroundColor(.gray)
                                    .opacity(searchText.isEmpty ? 0 : 1)
                            }
                            
                            TextField("", text: $searchText, onEditingChanged: { editing in
                                withAnimation(.spring()) { 
                                    showHistoryDropdown = editing && !viewModel.searchHistory.isEmpty 
                                }
                            }, onCommit: {
                                viewModel.performSearch(searchText)
                                showHistoryDropdown = false
                            })
                            .placeholder(when: searchText.isEmpty) {
                                Text("البحث أو إدخال عنوان URL")
                                    .foregroundColor(Color(hex: "888"))
                                    .font(.system(size: 16))
                            }
                            .foregroundColor(.white)
                            .multilineTextAlignment(.trailing)
                            .submitLabel(.search)
                            .accentColor(Color(hex: viewModel.searchEngine.color))
                            
                            Image(systemName: viewModel.searchEngine.icon)
                                .font(.system(size: 18))
                                .foregroundColor(Color(hex: viewModel.searchEngine.color))
                        }
                        .padding(.horizontal, 15)
                        .frame(height: 55)
                        .background(Color(hex: "1E1E1E"))
                        .cornerRadius(28)
                        .overlay(
                            RoundedRectangle(cornerRadius: 28)
                                .stroke(Color.white.opacity(0.1), lineWidth: 1)
                        )
                        .zIndex(2)
                        
                        // --- تحسين تصميم سجل البحث السابق ---
                        if showHistoryDropdown {
                            VStack(spacing: 0) {
                                ForEach(viewModel.searchHistory.prefix(5), id: \.self) { history in
                                    Button(action: {
                                        searchText = history
                                        viewModel.performSearch(history)
                                        showHistoryDropdown = false
                                    }) {
                                        HStack {
                                            // زر الحذف
                                            Button(action: { 
                                                withAnimation {
                                                    viewModel.removeSearchHistoryItem(history) 
                                                }
                                            }) {
                                                Image(systemName: "xmark")
                                                    .font(.system(size: 12, weight: .bold))
                                                    .foregroundColor(.gray)
                                                    .padding(6)
                                                    .background(Color.white.opacity(0.05))
                                                    .clipShape(Circle())
                                            }
                                            
                                            Spacer()
                                            
                                            Text(history)
                                                .foregroundColor(.white.opacity(0.9))
                                                .font(.system(size: 15, weight: .medium))
                                            
                                            Image(systemName: "clock.arrow.2.circlepath")
                                                .foregroundColor(.blue.opacity(0.7))
                                                .font(.system(size: 14))
                                                .padding(.leading, 8)
                                        }
                                        .padding(.horizontal, 18)
                                        .padding(.vertical, 14)
                                    }
                                    
                                    if history != viewModel.searchHistory.prefix(5).last {
                                        Divider()
                                            .background(Color.white.opacity(0.05))
                                            .padding(.horizontal, 15)
                                    }
                                }
                            }
                            .background(
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(Color(hex: "1A1A1A"))
                                    .shadow(color: .black.opacity(0.5), radius: 15, x: 0, y: 10)
                            )
                            .padding(.horizontal, 8)
                            .padding(.top, 10) // تباعد بسيط لجعلها تبدو طافية (Floating)
                            .zIndex(1)
                            .transition(.asymmetric(insertion: .opacity.combined(with: .move(edge: .top)), 
                                                    removal: .opacity))
                        }
                    }
                }
                .padding(.horizontal, 20)
                .zIndex(100)
                
                // 3. Quick Links Grid
                ScrollView(showsIndicators: false) {
                    LazyVGrid(columns: columns, spacing: 25) {
                        ForEach(websitesManager.websites) { site in
                            Button(action: { viewModel.loadUrl(url: URL(string: site.url)!) }) {
                                VStack(spacing: 8) {
                                    ZStack {
                                        Circle()
                                            .fill(LinearGradient(colors: [Color(hex: "333"), Color(hex: "1A1A1A")], startPoint: .topLeading, endPoint: .bottomTrailing))
                                            .frame(width: 60, height: 60)
                                        
                                        KFImage(URL(string: "https://www.google.com/s2/favicons?domain=\(site.url)&sz=128"))
                                            .placeholder {
                                                Text(String(site.name.prefix(1)).uppercased())
                                                    .font(.title2)
                                                    .foregroundColor(.white)
                                            }
                                            .resizable()
                                            .frame(width: 32, height: 32)
                                            .clipShape(Circle())
                                    }
                                    
                                    Text(site.name)
                                        .font(.system(size: 12, weight: .medium))
                                        .foregroundColor(Color(hex: "BBB"))
                                        .lineLimit(1)
                                        .frame(width: 75)
                                }
                            }
                        }
                        
                        // Add Button
                        Button(action: { showAddSheet = true }) {
                            VStack(spacing: 8) {
                                ZStack {
                                    Circle()
                                        .stroke(style: StrokeStyle(lineWidth: 1, dash: [4]))
                                        .foregroundColor(Color(hex: "555"))
                                        .background(Circle().fill(Color(hex: "222")))
                                        .frame(width: 60, height: 60)
                                    
                                    Image(systemName: "plus")
                                        .font(.title2)
                                        .foregroundColor(.white)
                                }
                                Text("إضافة")
                                    .font(.system(size: 12))
                                    .foregroundColor(Color(hex: "999"))
                            }
                        }
                    }
                    .padding(.top, 40)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 100)
                }
            }
        }
        .onAppear {
            withAnimation(.easeIn(duration: 0.8)) {
                opacity = 1.0
            }
        }
        .sheet(isPresented: $showAddSheet) {
            AddWebsiteView(websitesManager: websitesManager)
        }
    }
}

// MARK: - Helpers
extension View {
    func placeholder<Content: View>(
        when shouldShow: Bool,
        alignment: Alignment = .trailing,
        @ViewBuilder placeholder: () -> Content) -> some View {
            
            ZStack(alignment: alignment) {
                placeholder().opacity(shouldShow ? 1 : 0)
                self
            }
        }
}
