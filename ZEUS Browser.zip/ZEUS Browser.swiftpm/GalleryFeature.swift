import SwiftUI
import Kingfisher
import UIKit
import Photos

// MARK: - مفاتيح التخزين (Storage Keys)
enum StorageKeys {
    static let imageScale = "gallery_image_scale"
    static let scrollDistance = "gallery_scroll_distance"
}

// MARK: - مدير تنزيل الصور (Image Downloader)
class ImageDownloader: NSObject {
    static let shared = ImageDownloader()
    
    func saveImages(urls: [String], completion: @escaping (Bool, Int) -> Void) {
        let group = DispatchGroup()
        var savedCount = 0
        
        // طلب الإذن للوصول للصور
        PHPhotoLibrary.requestAuthorization { status in
            guard status == .authorized || status == .limited else {
                DispatchQueue.main.async { completion(false, 0) }
                return
            }
            
            for urlString in urls {
                guard let url = URL(string: urlString) else { continue }
                group.enter()
                
                // استخدام Kingfisher لتحميل الصورة أولاً
                KingfisherManager.shared.retrieveImage(with: url) { result in
                    switch result {
                    case .success(let value):
                        PHPhotoLibrary.shared().performChanges({
                            PHAssetChangeRequest.creationRequestForAsset(from: value.image)
                        }) { success, error in
                            if success { savedCount += 1 }
                            group.leave()
                        }
                    case .failure:
                        group.leave()
                    }
                }
            }
            
            group.notify(queue: .main) {
                completion(savedCount > 0, savedCount)
            }
        }
    }
}

// MARK: - واجهة الإعدادات (Settings View)
struct GallerySettingsView: View {
    @AppStorage(StorageKeys.imageScale) var imageScale: Double = 1.0
    @AppStorage(StorageKeys.scrollDistance) var scrollDistance: Double = 300.0
    
    @Binding var isPresented: Bool
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("إعدادات وضع القراءة")) {
                    VStack(alignment: .leading) {
                        Text("عرض الصورة: \(Int(imageScale * 100))%")
                        Slider(value: $imageScale, in: 0.2...1.0, step: 0.05) {
                            Text("Image Width")
                        } minimumValueLabel: {
                            Image(systemName: "photo")
                        } maximumValueLabel: {
                            Image(systemName: "photo.fill")
                        }
                    }
                    .padding(.vertical, 5)
                    
                    VStack(alignment: .leading) {
                        Text("مسافة التمرير عند النقر: \(Int(scrollDistance)) نقطة")
                        Slider(value: $scrollDistance, in: 100...1000, step: 50) {
                            Text("Scroll Distance")
                        } minimumValueLabel: {
                            Image(systemName: "arrow.up.arrow.down")
                        } maximumValueLabel: {
                            Image(systemName: "arrow.up.arrow.down.circle.fill")
                        }
                    }
                    .padding(.vertical, 5)
                }
                
                Section(footer: Text("يتم حفظ الإعدادات تلقائياً. عند فتح صورة، سيتم إخفاء شريط الحالة لتوفير تجربة قراءة كاملة.")) {
                    EmptyView()
                }
            }
            .navigationBarTitle("إعدادات العرض", displayMode: .inline)
            .navigationBarItems(trailing: Button("إغلاق") {
                isPresented = false
            })
        }
    }
}

// MARK: - أداة الوصول للتحكم بالتمرير (Scroll Helper)
struct ScrollViewFinder: UIViewRepresentable {
    @Binding var uiScrollView: UIScrollView?
    
    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }
    
    func updateUIView(_ uiView: UIView, context: Context) {
        DispatchQueue.main.async {
            if let scrollView = uiView.superview?.superview?.superview as? UIScrollView {
                self.uiScrollView = scrollView
            } else {
                self.findScrollView(in: uiView)
            }
        }
    }
    
    private func findScrollView(in view: UIView) {
        var current: UIView? = view
        while let view = current {
            if let scrollView = view as? UIScrollView {
                self.uiScrollView = scrollView
                return
            }
            current = view.superview
        }
    }
}

// MARK: - واجهة معرض الصور (Gallery UI)
struct GalleryView: View {
    let images: [String]
    @Binding var isVisible: Bool
    
    @AppStorage(StorageKeys.imageScale) var imageScale: Double = 1.0
    @AppStorage(StorageKeys.scrollDistance) var scrollDistance: Double = 300.0
    
    @State private var showSettings = false
    @State private var uiScrollView: UIScrollView?
    @State private var selectedIndex: Int? = nil
    
    // حالات التحديد
    @State private var isSelectionMode = false
    @State private var selectedImages: Set<String> = []
    @State private var isDownloading = false
    
    @State private var isStatusBarHidden = false
    
    let columns = [
        GridItem(.flexible(), spacing: 2),
        GridItem(.flexible(), spacing: 2),
        GridItem(.flexible(), spacing: 2)
    ]
    
    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 0) {
                // Header
                HStack {
                    if isSelectionMode {
                        Button(action: {
                            withAnimation {
                                isSelectionMode = false
                                selectedImages.removeAll()
                            }
                        }) {
                            Text("إلغاء")
                                .foregroundColor(.red)
                        }
                        
                        Spacer()
                        
                        Button(action: {
                            withAnimation {
                                if selectedImages.count == images.count {
                                    selectedImages.removeAll()
                                } else {
                                    selectedImages = Set(images)
                                }
                            }
                        }) {
                            Text(selectedImages.count == images.count ? "إلغاء الكل" : "تحديد الكل")
                                .foregroundColor(.blue)
                        }
                    } else {
                        Button(action: { showSettings = true }) {
                            Image(systemName: "gearshape.fill")
                                .foregroundColor(.white)
                                .font(.title2)
                        }
                        
                        Spacer()
                        
                        Text("\(images.count) صور")
                            .foregroundColor(.white)
                            .font(.headline)
                        
                        Spacer()
                        
                        Button(action: { isSelectionMode = true }) {
                            Image(systemName: "checkmark.circle")
                                .foregroundColor(.white)
                                .font(.title2)
                        }
                    }
                    
                    if !isSelectionMode {
                        Button(action: { isVisible = false }) {
                            Image(systemName: "xmark")
                                .foregroundColor(.white)
                                .font(.title2)
                        }
                        .padding(.leading, 10)
                    }
                }
                .padding()
                .background(Color(white: 0.05))
                
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 2) {
                        ForEach(images.indices, id: \.self) { index in
                            let imageUrl = images[index]
                            let isSelected = selectedImages.contains(imageUrl)
                            
                            ZStack(alignment: .topTrailing) {
                                KFImage(URL(string: imageUrl))
                                    .placeholder { Color.gray.opacity(0.3) }
                                    .resizable()
                                    .scaledToFill()
                                    .frame(height: UIScreen.main.bounds.width / 3)
                                    .clipped()
                                    .overlay(
                                        isSelected ? Color.blue.opacity(0.4) : Color.clear
                                    )
                                    .contentShape(Rectangle()) // يجعل المنطقة قابلة للنقر بالكامل
                                    .onTapGesture {
                                        if isSelectionMode {
                                            toggleSelection(for: imageUrl)
                                        } else {
                                            selectedIndex = index
                                            withAnimation { isStatusBarHidden = true }
                                        }
                                    }
                                    .onLongPressGesture(minimumDuration: 0.5) {
                                        if !isSelectionMode {
                                            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                                            withAnimation {
                                                isSelectionMode = true
                                                toggleSelection(for: imageUrl)
                                            }
                                        }
                                    }
                                
                                if isSelectionMode {
                                    Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                                        .foregroundColor(isSelected ? .blue : .white)
                                        .background(isSelected ? Color.white.clipShape(Circle()) : Color.clear.clipShape(Circle()))
                                        .padding(8)
                                        .font(.system(size: 22))
                                        .allowsHitTesting(false) // يسمح للنقرة بالمرور للصورة خلفها
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 2)
                }
                
                // شريط التنزيل السفلي عند التحديد
                if isSelectionMode {
                    VStack {
                        Divider().background(Color.gray)
                        HStack {
                            Text("تم تحديد \(selectedImages.count) صورة")
                                .foregroundColor(.white)
                                .font(.subheadline)
                            
                            Spacer()
                            
                            Button(action: downloadSelectedImages) {
                                if isDownloading {
                                    ProgressView()
                                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                } else {
                                    HStack {
                                        Image(systemName: "square.and.arrow.down")
                                        Text("حفظ في الجهاز")
                                    }
                                    .padding(.horizontal, 15)
                                    .padding(.vertical, 8)
                                    .background(selectedImages.isEmpty ? Color.gray : Color.blue)
                                    .foregroundColor(.white)
                                    .cornerRadius(20)
                                }
                            }
                            .disabled(selectedImages.isEmpty || isDownloading)
                        }
                        .padding()
                    }
                    .background(Color(white: 0.1))
                    .transition(.move(edge: .bottom))
                }
            }
            
            // وضع القراءة (Webtoon Reader Mode)
            if let index = selectedIndex {
                ZStack {
                    Color.black.edgesIgnoringSafeArea(.all)
                    
                    GeometryReader { geometry in
                        ScrollViewReader { proxy in
                            ScrollView {
                                LazyVStack(spacing: 0) {
                                    ForEach(0..<images.count, id: \.self) { i in
                                        KFImage(URL(string: images[i]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: geometry.size.width * CGFloat(imageScale))
                                            .frame(maxWidth: .infinity)
                                            .id(i)
                                    }
                                }
                                .background(ScrollViewFinder(uiScrollView: $uiScrollView))
                            }
                            .simultaneousGesture(
                                SpatialTapGesture()
                                    .onEnded { event in
                                        let yLocation = event.location.y
                                        let screenHeight = geometry.size.height
                                        
                                        if yLocation < screenHeight / 2 {
                                            scroll(direction: -1)
                                        } else {
                                            scroll(direction: 1)
                                        }
                                    }
                            )
                            .onAppear {
                                proxy.scrollTo(index, anchor: .top)
                            }
                        }
                    }
                    
                    VStack {
                        HStack {
                            Spacer()
                            Button(action: {
                                selectedIndex = nil
                                withAnimation { isStatusBarHidden = false }
                            }) {
                                Image(systemName: "xmark.circle.fill")
                                    .font(.system(size: 35))
                                    .foregroundColor(.white.opacity(0.8))
                                    .padding()
                            }
                        }
                        Spacer()
                    }
                }
                .transition(.move(edge: .bottom))
                .zIndex(10)
            }
        }
        .statusBar(hidden: isStatusBarHidden)
        .sheet(isPresented: $showSettings) {
            GallerySettingsView(isPresented: $showSettings)
        }
    }
    
    // MARK: - الوظائف المضافة
    
    private func toggleSelection(for url: String) {
        if selectedImages.contains(url) {
            selectedImages.remove(url)
        } else {
            selectedImages.insert(url)
        }
    }
    
    private func downloadSelectedImages() {
        isDownloading = true
        let urlsToDownload = Array(selectedImages)
        
        ImageDownloader.shared.saveImages(urls: urlsToDownload) { success, count in
            isDownloading = false
            if success {
                withAnimation {
                    isSelectionMode = false
                    selectedImages.removeAll()
                }
                print("تم حفظ \(count) صورة بنجاح")
            }
        }
    }
    
    private func scroll(direction: CGFloat) {
        guard let scrollView = uiScrollView else { return }
        
        let currentOffset = scrollView.contentOffset.y
        let maxOffset = scrollView.contentSize.height - scrollView.bounds.height
        let minOffset: CGFloat = 0
        
        let newOffset = currentOffset + (direction * CGFloat(scrollDistance))
        let clampedOffset = min(max(newOffset, minOffset), maxOffset)
        
        scrollView.setContentOffset(CGPoint(x: 0, y: clampedOffset), animated: true)
    }
}

// MARK: - محرك استخراج الصور
struct GalleryEngine {
    static func getImageExtractionScript() -> String {
        return """
        (function() {
            try {
                let images = [];
                document.querySelectorAll('img').forEach(img => {
                    if (img.src && img.naturalWidth > 150 && img.naturalHeight > 150) {
                        images.push(img.src);
                    }
                });
                document.querySelectorAll('*').forEach(el => {
                    const bg = window.getComputedStyle(el).backgroundImage;
                    if (bg && bg !== 'none' && bg.startsWith('url(')) {
                        let url = bg.slice(4, -1).replace(/["']/g, "");
                        images.push(url);
                    }
                });
                const uniqueImages = [...new Set(images)];
                if (uniqueImages.length > 0) {
                    window.webkit.messageHandlers.galleryObserver.postMessage({
                        images: uniqueImages
                    });
                } else {
                    alert('لا توجد صور كبيرة في هذه الصفحة');
                }
            } catch (e) {
                console.error(e);
            }
        })();
        """
    }
}
