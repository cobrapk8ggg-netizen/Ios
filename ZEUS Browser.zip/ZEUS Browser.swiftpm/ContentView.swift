import SwiftUI

// MARK: - 6. الواجهة الرئيسية

struct ContentView: View {
    @StateObject var viewModel = WebViewModel()
    @StateObject var websitesManager = WebsitesManager()
    @State private var isToolbarHidden = true
    @State private var showWebsitesBar = false
    @State private var showTabsTray = false
    
    // متغير جديد لعرض السجل
    @State private var showHistory = false
    // متغيرات الكونسول والسكربتات
    @State private var showConsole = false
    @State private var showScripts = false
    
    // Check if current tab is Home
    var isHomeTab: Bool {
        if let current = viewModel.tabs.first(where: { $0.id == viewModel.currentTabID }) {
            return current.url == "zeus://home"
        }
        return false
    }
    
    var body: some View {
        ZStack(alignment: .top) {
            
            // 1. المحتوى الرئيسي (المتصفح أو الصفحة الرئيسية)
            ZStack(alignment: .trailing) {
                
                if isHomeTab {
                    HomePageView(viewModel: viewModel, websitesManager: websitesManager)
                        .transition(.opacity)
                        .zIndex(1)
                } else {
                    VStack(spacing: 0) {
                        
                        if viewModel.isLoading {
                            ProgressView().progressViewStyle(LinearProgressViewStyle(tint: .blue)).frame(height: 2)
                        }
                        WebViewContainer(viewModel: viewModel)
                        
                    }
                    // تم تعديل هذا الجزء ليتجاهل جميع الحواف (بما في ذلك شريط الحالة العلوي)
                    .edgesIgnoringSafeArea(.all) 
                    .transition(.opacity)
                    .zIndex(1)
                }
                
                // شريط المواقع الجانبي
                if showWebsitesBar {
                    Color.black.opacity(0.01)
                        .edgesIgnoringSafeArea(.all)
                    
                        .onTapGesture {
                            withAnimation(.spring()) { showWebsitesBar = false }
                        }
                        .zIndex(5)
                    
                    WebsitesBarView(websitesManager: websitesManager, viewModel: viewModel, isVisible: $showWebsitesBar)
                        .transition(.move(edge: .trailing))
                        .frame(maxWidth: .infinity, alignment: .trailing)
                    
                        .zIndex(6)
                }
                
                // 🔥 واجهة السجل (History)
                if showHistory {
                    
                    HistoryView(viewModel: viewModel, historyManager: viewModel.historyManager, isVisible: $showHistory)
                        .transition(.opacity)
                        .zIndex(20)
                }
                
                
                // 🔥 واجهة الكونسول (Console)
                if showConsole {
                    VStack {
                        Spacer()
                        ConsoleView(viewModel: viewModel, isVisible: $showConsole)
                        
                    }
                    .transition(.move(edge: .bottom))
                    .zIndex(25)
                }
                
                
                // 🔥 واجهة مدير السكربتات
                if showScripts {
                    ScriptManagerView(scriptManager: viewModel.scriptManager, viewModel: viewModel, isVisible: $showScripts)
                        .transition(.move(edge: .bottom))
                    
                        .zIndex(30)
                }
                
                // 🔥 قارئ النصوص (Reader Mode)
                if viewModel.showReader, let content = viewModel.readerContent {
                    ReaderView(title: content.title, content: content.content, isVisible: $viewModel.showReader)
                        .transition(.move(edge: .bottom))
                        .zIndex(35)
                }
                
                // 🔥 معرض الصور (Gallery)
                if viewModel.showGallery {
                    GalleryView(images: viewModel.galleryImages, isVisible: $viewModel.showGallery)
                        .transition(.opacity)
                        .zIndex(35)
                    
                }
                
                // شريط الأدوات السفلي العائم (Toolbar)
                // تم إزالة شرط !isHomeTab ليظهر الشريط في كل مكان
                VStack(spacing: 18) {
                    
                    // --- مجموعة التنقل (Navigation) ---
                    Group {
                        
                        Button(action: { viewModel.goBack() }) {
                            Image(systemName: "chevron.backward")
                                .font(.headline)
                                .foregroundColor(.white)
                        }.disabled(!viewModel.canGoBack)
                        
                        
                        Button(action: { viewModel.goForward() }) {
                            Image(systemName: "chevron.forward")
                                .font(.headline)
                                .foregroundColor(.white)
                        }.disabled(!viewModel.canGoForward)
                        
                        
                        Button(action: { viewModel.reload() }) {
                            Image(systemName: "arrow.clockwise")
                                .font(.headline)
                                .foregroundColor(.white)
                        }
                        
                        // زر العودة للرئيسية
                        Button(action: { viewModel.loadUrl(url: URL(string: "zeus://home")!) }) {
                            Image(systemName: "house.fill")
                                .font(.headline)
                                .foregroundColor(.white)
                        }
                    }
                    
                    Divider().frame(width: 30).background(Color.white.opacity(0.3))
                    
                    // --- مجموعة الأدوات (Tools) ---
                    Group {
                        // زر إضافة تبويب جديد
                        Button(action: { viewModel.addNewTab() }) {
                            Image(systemName: "plus")
                                .font(.title3)
                                .foregroundColor(.white)
                        }
                        
                        // زر المواقع
                        Button(action: {
                            withAnimation(.spring()) {
                                showWebsitesBar.toggle()
                                if showWebsitesBar { isToolbarHidden = true }
                            }
                        }) {
                            ZStack {
                                Image(systemName: "globe")
                                    .font(.title3)
                                    .foregroundColor(.white)
                                if viewModel.adsBlocked > 0 {
                                    Circle().fill(Color.red).frame(width: 8, height: 8).offset(x: 10, y: -10)
                                }
                            }
                        }
                        
                        // زر السجل
                        Button(action: {
                            withAnimation(.spring()) {
                                showHistory = true
                                isToolbarHidden = true
                            }
                        }) {
                            Image(systemName: "clock.arrow.circlepath")
                                .font(.title3)
                                .foregroundColor(.white)
                        }
                        
                        // زر وضع القراءة
                        Button(action: {
                            withAnimation(.spring()) {
                                viewModel.activateReaderMode()
                                isToolbarHidden = true
                            }
                        }) {
                            Image(systemName: "doc.plaintext")
                                .font(.title3)
                                .foregroundColor(.white)
                        }
                        
                        // زر استخراج الصور
                        Button(action: {
                            withAnimation(.spring()) {
                                viewModel.activateGalleryMode()
                                isToolbarHidden = true
                            }
                        }) {
                            Image(systemName: "photo.on.rectangle")
                                .font(.title3)
                                .foregroundColor(.white)
                        }
                    }
                    
                    Divider().frame(width: 30).background(Color.white.opacity(0.3))
                    
                    // --- مجموعة المطورين والإعدادات ---
                    Group {
                        // زر الكونسول
                        Button(action: {
                            withAnimation(.spring()) {
                                showConsole.toggle()
                                isToolbarHidden = true
                            }
                        }) {
                            Image(systemName: "terminal")
                                .font(.title3)
                                .foregroundColor(.white)
                        }
                        
                        // زر السكربتات
                        Button(action: {
                            withAnimation(.spring()) {
                                showScripts = true
                                isToolbarHidden = true
                            }
                        }) {
                            Image(systemName: "curlybraces")
                                .font(.title3)
                                .foregroundColor(.white)
                        }
                        
                        // زر الوضع الليلي
                        Button(action: { viewModel.toggleForcedDarkMode() }) {
                            Image(systemName: viewModel.isForcedDarkMode ? "sun.max.fill" : "moon.stars.fill")
                                .font(.headline)
                                .foregroundColor(viewModel.isForcedDarkMode ? .yellow : .white)
                        }
                    }
                }
                .padding(15)
                .background(Color.black.opacity(0.6))
                .background(.ultraThinMaterial)
                .cornerRadius(20, corners: [.topLeft, .bottomLeft])
                .shadow(radius: 5)
                .offset(x: isToolbarHidden ? 80 : 0)
                .gesture(DragGesture().onChanged { if $0.translation.width > 5 { withAnimation { isToolbarHidden = true } } })
                .zIndex(4)
                
                if isToolbarHidden {
                    Color.clear.frame(width: 25).contentShape(Rectangle())
                        .gesture(DragGesture().onChanged { if $0.translation.width < -10 { withAnimation { isToolbarHidden = false } } })
                        .zIndex(10)
                }
            }
            .onAppear { viewModel.websitesManager = websitesManager }
            
            // 2. منطقة استشعار السحب العلوية (مشتركة)
            if !showTabsTray {
                Color.clear
                    .frame(height: 30)
                    .contentShape(Rectangle())
                    .ignoresSafeArea()
                    .zIndex(20)
                    .gesture(
                        DragGesture(minimumDistance: 20, coordinateSpace: .global)
                            .onEnded { value in
                                if value.translation.height > 50 && value.startLocation.y < 100 {
                                    withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                                        showTabsTray = true
                                    }
                                }
                            }
                    )
            }
            
            // 3. شريط التبويبات (مشترك)
            if showTabsTray {
                ZStack(alignment: .top) {
                    Color.black.opacity(0.3)
                        .ignoresSafeArea()
                        .onTapGesture {
                            withAnimation { showTabsTray = false }
                        }
                    
                    TabsTrayView(viewModel: viewModel, isVisible: $showTabsTray)
                        .transition(.move(edge: .top))
                }
                .zIndex(30)
            }
        }
        // إضافة أمر إخفاء شريط الحالة (الساعة، البطارية، إلخ)
        .statusBarHidden(true)
        // التأكد من أن التطبيق يملأ كامل الشاشة حتى في وجود "النوتش"
        .ignoresSafeArea(.all)
    }
}

// MARK: - Helpers

extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}

extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default: (a, r, g, b) = (1, 1, 1, 0)
        }
        self.init(.sRGB, red: Double(r) / 255, green: Double(g) / 255, blue: Double(b) / 255, opacity: Double(a) / 255)
    }
}
